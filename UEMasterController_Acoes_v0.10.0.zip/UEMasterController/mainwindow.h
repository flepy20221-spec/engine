#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QByteArray>
#include <QHash>
#include <QJsonObject>
#include <QPixmap>
#include <QVector>

class QFrame;
class QProcess;
class QPushButton;
class QResizeEvent;
class QTcpSocket;
class QTimer;
class QTreeWidgetItem;

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow final : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

protected:
    bool eventFilter(QObject *watched, QEvent *event) override;
    void resizeEvent(QResizeEvent *event) override;

private:
    struct LogEntry { QString time; QString category; QString message; };
    void setupNavigation();
    void setupActions();
    void setupConnection();
    void setSection(int index);
    void setConnected(bool connected);
    void updateProjectPath();
    void addLog(const QString &category, const QString &message);
    void drawLog();
    bool sendCommand(const QString &id, const QString &command,
                     const QJsonObject &parameters = {});
    void requestPlay();
    void requestAction(const QString &action);
    void startPackageBuild(const QString &platform);
    void handleBuildOutput();
    void readSocket();
    void handleResponse(const QByteArray &line);
    void registerCard(QFrame *card, const QString &action);
    void refreshAssets();
    void filterAssets();
    void refreshBlueprints();
    void refreshLevel();
    void refreshMaps();
    void captureView();
    void updateCapturePreview();
    void inspectSelectedActor();
    void updateSettings();
    void openProjectFolder();

    Ui::MainWindow *ui;
    QTcpSocket *socket = nullptr;
    QTimer *retryTimer = nullptr;
    QTimer *heartbeatTimer = nullptr;
    QTimer *statusTimeoutTimer = nullptr;
    QTimer *playTimeoutTimer = nullptr;
    QTimer *actionTimeoutTimer = nullptr;
    QProcess *buildProcess = nullptr;
    QTimer *blueprintSearchTimer = nullptr;
    QTimer *captureTimeoutTimer = nullptr;
    QByteArray incoming;
    QByteArray buildLineBuffer;
    QString projectDirectory;
    QString projectName;
    QString engineDirectory;
    QString engineVersionText;
    QString bridgeVersionText;
    QString buildPlatform;
    QString lastCapturePath;
    QPixmap captureImage;
    int sceneOffset = 0;
    int sceneNextOffset = 0;
    QVector<int> scenePageHistory;
    bool capturePending = false;
    QString lastBlueprintPath;
    QString pendingActionId;
    QString pendingActionName;
    QVector<LogEntry> logs;
    QHash<QObject *, QString> cardActions;
    QVector<QPushButton *> navButtons;
    bool connected = false;
    bool incompatibleBridge = false;
    bool playRequestPending = false;
};
#endif // MAINWINDOW_H
