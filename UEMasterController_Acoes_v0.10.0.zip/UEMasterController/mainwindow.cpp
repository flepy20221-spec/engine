#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QComboBox>
#include <QDateTime>
#include <QDesktopServices>
#include <QDialog>
#include <QDialogButtonBox>
#include <QDir>
#include <QDoubleSpinBox>
#include <QEvent>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QFontMetrics>
#include <QFrame>
#include <QFormLayout>
#include <QHostAddress>
#include <QHBoxLayout>
#include <QInputDialog>
#include <QDirIterator>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QLabel>
#include <QLineEdit>
#include <QMenu>
#include <QMessageBox>
#include <QMouseEvent>
#include <QProcess>
#include <QPushButton>
#include <QResizeEvent>
#include <QSaveFile>
#include <QScrollBar>
#include <QStackedWidget>
#include <QTcpSocket>
#include <QTextEdit>
#include <QTextDocument>
#include <QTextOption>
#include <QTimer>
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QUrl>
#include <QUuid>
#include <QVersionNumber>
#include <QWindow>

namespace {
constexpr quint16 BridgePort = 17777;
constexpr int MaxLine = 64 * 1024;

QString colorFor(const QString &name)
{
    if (name == "Bridge") return "#2cead5";
    if (name == "Project") return "#9cbeff";
    if (name == "Action") return "#6cdef5";
    if (name == "Build") return "#ffba61";
    if (name == "Error") return "#ff9884";
    return "#bacbe3";
}

bool askTransform(QWidget *parent, QJsonObject &value, const QString &title)
{
    QDialog dialog(parent);
    dialog.setWindowTitle(title);
    QFormLayout form(&dialog);
    const QJsonObject location = value.value("location").toObject();
    const QJsonObject rotation = value.value("rotation").toObject();
    const QJsonObject scale = value.value("scale").toObject();
    const auto spin = [&form, &dialog](const QString &label, double initial,
                                        double low, double high) {
        auto *field = new QDoubleSpinBox(&dialog);
        field->setRange(low, high);
        field->setDecimals(3);
        field->setSingleStep(low > 0 ? 0.1 : 10.0);
        field->setValue(initial);
        form.addRow(label, field);
        return field;
    };
    auto *x = spin(QObject::tr("Posição X (cm)"), location.value("x").toDouble(), -1000000, 1000000);
    auto *y = spin(QObject::tr("Posição Y (cm)"), location.value("y").toDouble(), -1000000, 1000000);
    auto *z = spin(QObject::tr("Posição Z (cm)"), location.value("z").toDouble(), -1000000, 1000000);
    auto *pitch = spin(QObject::tr("Pitch (°)"), rotation.value("pitch").toDouble(), -3600, 3600);
    auto *yaw = spin(QObject::tr("Yaw (°)"), rotation.value("yaw").toDouble(), -3600, 3600);
    auto *roll = spin(QObject::tr("Roll (°)"), rotation.value("roll").toDouble(), -3600, 3600);
    auto *sx = spin(QObject::tr("Escala X"), scale.value("x").toDouble(1), 0.001, 10000);
    auto *sy = spin(QObject::tr("Escala Y"), scale.value("y").toDouble(1), 0.001, 10000);
    auto *sz = spin(QObject::tr("Escala Z"), scale.value("z").toDouble(1), 0.001, 10000);
    QDialogButtonBox buttons(QDialogButtonBox::Ok | QDialogButtonBox::Cancel, &dialog);
    QObject::connect(&buttons, &QDialogButtonBox::accepted, &dialog, &QDialog::accept);
    QObject::connect(&buttons, &QDialogButtonBox::rejected, &dialog, &QDialog::reject);
    form.addRow(&buttons);
    if (dialog.exec() != QDialog::Accepted) return false;
    value = {{"location", QJsonObject{{"x", x->value()}, {"y", y->value()}, {"z", z->value()}}},
             {"rotation", QJsonObject{{"pitch", pitch->value()}, {"yaw", yaw->value()}, {"roll", roll->value()}}},
             {"scale", QJsonObject{{"x", sx->value()}, {"y", sy->value()}, {"z", sz->value()}}}};
    return true;
}

}

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowFlags(Qt::Window | Qt::FramelessWindowHint);
    setAttribute(Qt::WA_TranslucentBackground);
    setMinimumSize(722, 620);
    resize(722, 620);
    ui->consoleOutput->setWordWrapMode(QTextOption::NoWrap);
    ui->logsOutput->setWordWrapMode(QTextOption::NoWrap);
    ui->buildOutput->setWordWrapMode(QTextOption::NoWrap);
    ui->buildOutput->document()->setMaximumBlockCount(1500);
    ui->levelOpenCaptureButton->setEnabled(false);
    ui->levelPrevActorsButton->setEnabled(false);
    ui->levelNextActorsButton->setEnabled(false);

    QObject *headerParts[] = {ui->topbar, ui->appLogo, ui->appTitle,
        ui->appSubtitle, ui->connectionPill, ui->connectionLabel,
        ui->connectionSubLabel};
    for (QObject *part : headerParts)
        part->installEventFilter(this);

    connect(ui->closeButton, &QPushButton::clicked, this, &QWidget::close);
    connect(ui->minButton, &QPushButton::clicked, this, &QWidget::showMinimized);
    connect(ui->pinButton, &QPushButton::clicked, this, [this] {
        const bool pinned = !(windowFlags() & Qt::WindowStaysOnTopHint);
        setWindowFlag(Qt::WindowStaysOnTopHint, pinned);
        show();
        ui->pinButton->setToolTip(pinned ? tr("Desafixar janela") : tr("Fixar janela no topo"));
    });
    ui->pinButton->setToolTip(tr("Fixar janela no topo"));

    setupNavigation();
    setupActions();
    connect(ui->clearButton, &QPushButton::clicked, this, [this] { logs.clear(); drawLog(); });
    connect(ui->logFilter, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, [this] { drawLog(); });
    connect(ui->logsClearButton, &QPushButton::clicked, this, [this] { logs.clear(); drawLog(); });
    connect(ui->logsFilter, QOverload<int>::of(&QComboBox::currentIndexChanged),
            this, [this] { drawLog(); });
    connect(ui->logsExportButton, &QPushButton::clicked, this, [this] {
        const QString path = QFileDialog::getSaveFileName(this, tr("Exportar logs"),
            QDir::home().filePath("UEMasterController.log"), tr("Arquivo de texto (*.log *.txt)"));
        if (path.isEmpty()) return;
        QSaveFile file(path);
        if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
            addLog("Error", tr("Não foi possível criar %1: %2").arg(path, file.errorString()));
            return;
        }
        for (const LogEntry &entry : logs) {
            const QByteArray line = QString("[%1] [%2] %3\n")
                .arg(entry.time, entry.category, entry.message).toUtf8();
            if (file.write(line) != line.size()) {
                addLog("Error", tr("Erro ao exportar logs: %1").arg(file.errorString()));
                file.cancelWriting();
                return;
            }
        }
        if (!file.commit()) {
            addLog("Error", tr("Erro ao salvar logs: %1").arg(file.errorString()));
            return;
        }
        addLog("Action", tr("Logs exportados: %1").arg(path));
    });
    connect(ui->filterSettings, &QPushButton::clicked, this, [this] { setSection(6); });
    connect(ui->browseButton, &QPushButton::clicked, this, &MainWindow::openProjectFolder);
    connect(ui->settingsOpenProjectButton, &QPushButton::clicked, this, &MainWindow::openProjectFolder);
    connect(ui->settingsReconnectButton, &QPushButton::clicked, this, [this] {
        addLog("Bridge", tr("Reconectando ao Unreal Editor..."));
        socket->abort();
        socket->connectToHost(QHostAddress::LocalHost, BridgePort);
    });
    addLog("Bridge", tr("Aguardando Unreal Editor em 127.0.0.1:17777..."));
    setupConnection();
}

MainWindow::~MainWindow() { delete ui; }

void MainWindow::setupNavigation()
{
    navButtons = {ui->navProject, ui->navAssets, ui->navBlueprint,
                  ui->navLevel, ui->navBuild, ui->navLogs, ui->navSettings};
    for (int i = 0; i < navButtons.size(); ++i)
        connect(navButtons[i], &QPushButton::clicked, this, [this, i] { setSection(i); });
    setSection(0);
}

void MainWindow::setSection(int index)
{
    ui->pageStack->setCurrentIndex(index);
    for (int i = 0; i < navButtons.size(); ++i) {
        auto *button = navButtons[i];
        button->setChecked(i == index);
    }
    if (index == 1) refreshAssets();
    if (index == 2) refreshBlueprints();
    if (index == 3) { refreshLevel(); refreshMaps(); captureView(); }
    if (index == 4) ui->buildProjectInfo->setText(projectName.isEmpty()
        ? tr("Aguardando projeto...") : tr("Projeto: %1.uproject").arg(projectName));
    if (index == 6) updateSettings();
}

void MainWindow::setupActions()
{
    const auto addMenu = [this](QLayout *layout, const QString &title,
                                const QStringList &items) {
        auto *button = new QPushButton(title, this);
        auto *menu = new QMenu(button);
        const QHash<QString, QString> labels = {
            {"Create Content Folder", tr("Criar pasta")},
            {"Move Asset", tr("Mover/renomear asset")},
            {"Duplicate Asset", tr("Duplicar asset")},
            {"Rename Actor", tr("Renomear Actor")},
            {"Duplicate Actor", tr("Duplicar Actor")},
            {"Delete Actor", tr("Excluir Actor")},
            {"Attach Actor", tr("Vincular ao Actor pai")},
            {"Detach Actor", tr("Separar do Actor pai")},
            {"Actor Properties", tr("Propriedades")},
            {"Add Component", tr("Adicionar componente")},
            {"Remove Component", tr("Remover componente")},
            {"Frame Actor", tr("Enquadrar Actor")},
            {"Compose Scene", tr("Montar cena com JSON")},
            {"Undo", tr("Desfazer")},
            {"Redo", tr("Refazer")}
        };
        for (const QString &item : items) {
            QAction *entry = menu->addAction(labels.value(item, item));
            connect(entry, &QAction::triggered, this, [this, item] { requestAction(item); });
        }
        button->setMenu(menu);
        layout->addWidget(button);
    };
    addMenu(ui->assetsActionRow, tr("Organizar assets"),
            {"Create Content Folder", "Move Asset", "Duplicate Asset"});
    auto *blueprintToolsRow = new QHBoxLayout;
    blueprintToolsRow->setSpacing(8);
    auto *objectButton = new QPushButton(tr("Objeto"), ui->blueprintPage);
    objectButton->setObjectName("objectBuilderButton");
    auto *objectMenu = new QMenu(objectButton);
    auto *createObject = objectMenu->addAction(tr("Criar objeto com componentes"));
    auto *inspectObject = objectMenu->addAction(tr("Inspecionar objeto selecionado"));
    connect(createObject, &QAction::triggered, this,
            [this] { requestAction("Create Object"); });
    connect(inspectObject, &QAction::triggered, this,
            [this] { requestAction("Inspect Object"); });
    objectButton->setMenu(objectMenu);
    blueprintToolsRow->addWidget(objectButton);
    auto *graphButton = new QPushButton(tr("Grafo"), ui->blueprintPage);
    graphButton->setObjectName("blueprintGraphButton");
    auto *graphMenu = new QMenu(graphButton);
    auto *createGraph = graphMenu->addAction(tr("Criar evento e lógica"));
    auto *inspectGraph = graphMenu->addAction(tr("Inspecionar evento"));
    connect(createGraph, &QAction::triggered, this,
            [this] { requestAction("Create Blueprint Logic"); });
    connect(inspectGraph, &QAction::triggered, this,
            [this] { requestAction("Inspect Blueprint Logic"); });
    graphButton->setMenu(graphMenu);
    blueprintToolsRow->addWidget(graphButton);
    auto *characterButton = new QPushButton(tr("Personagem"), ui->blueprintPage);
    characterButton->setObjectName("characterBuilderButton");
    auto *characterMenu = new QMenu(characterButton);
    auto *createCharacter = characterMenu->addAction(tr("Criar Character"));
    auto *inspectCharacter = characterMenu->addAction(tr("Inspecionar Character"));
    connect(createCharacter, &QAction::triggered, this,
            [this] { requestAction("Create Character"); });
    connect(inspectCharacter, &QAction::triggered, this,
            [this] { requestAction("Inspect Character"); });
    characterButton->setMenu(characterMenu);
    blueprintToolsRow->addWidget(characterButton);
    ui->blueprintPageLayout->addLayout(blueprintToolsRow);
    addMenu(ui->levelEditActorRow, tr("Editar Actor"),
            {"Rename Actor", "Duplicate Actor", "Delete Actor", "Attach Actor",
             "Detach Actor", "Actor Properties", "Add Component", "Remove Component",
             "Frame Actor"});
    addMenu(ui->levelMapTools, tr("Cena"),
            {"Compose Scene", "Undo", "Redo"});
    registerCard(ui->cardImport, "Import Asset");
    registerCard(ui->cardBlueprint, "Create Blueprint");
    registerCard(ui->cardCamera, "Add Third-Person Camera");
    registerCard(ui->cardCompile, "Compile");
    registerCard(ui->cardPlay, "Play");
    registerCard(ui->cardAndroid, "Build Android");

    connect(ui->assetsImportButton, &QPushButton::clicked, this,
            [this] { requestAction("Import Asset"); });
    connect(ui->assetsFolderButton, &QPushButton::clicked, this, [this] {
        const QString content = QDir(projectDirectory).filePath("Content");
        if (projectDirectory.isEmpty() || !QDir(content).exists()) {
            addLog("Error", tr("A pasta Content do projeto não está disponível."));
            return;
        }
        QDesktopServices::openUrl(QUrl::fromLocalFile(content));
    });
    connect(ui->assetsRefreshButton, &QPushButton::clicked, this, &MainWindow::refreshAssets);
    connect(ui->assetsSearch, &QLineEdit::textChanged, this, &MainWindow::filterAssets);
    connect(ui->assetsTree, &QTreeWidget::itemDoubleClicked, this,
            [this](QTreeWidgetItem *item, int) {
                QDesktopServices::openUrl(QUrl::fromLocalFile(
                    QFileInfo(item->data(0, Qt::UserRole).toString()).absolutePath()));
            });

    blueprintSearchTimer = new QTimer(this);
    blueprintSearchTimer->setSingleShot(true);
    blueprintSearchTimer->setInterval(350);
    connect(blueprintSearchTimer, &QTimer::timeout, this, &MainWindow::refreshBlueprints);
    connect(ui->blueprintSearch, &QLineEdit::textChanged, this,
            [this] { blueprintSearchTimer->start(); });
    connect(ui->blueprintRefreshButton, &QPushButton::clicked, this, &MainWindow::refreshBlueprints);
    connect(ui->blueprintCreateButton, &QPushButton::clicked, this,
            [this] { requestAction("Create Blueprint"); });
    connect(ui->blueprintCompileButton, &QPushButton::clicked, this,
            [this] { requestAction("Compile"); });
    connect(ui->blueprintCameraButton, &QPushButton::clicked, this,
            [this] { requestAction("Add Third-Person Camera"); });
    connect(ui->blueprintTree, &QTreeWidget::itemSelectionChanged, this, [this] {
        if (auto *item = ui->blueprintTree->currentItem())
            lastBlueprintPath = item->data(0, Qt::UserRole).toString();
    });

    connect(ui->levelRefreshButton, &QPushButton::clicked, this,
            [this] { refreshLevel(); refreshMaps(); });
    connect(ui->levelCaptureButton, &QPushButton::clicked, this, &MainWindow::captureView);
    connect(ui->levelOpenCaptureButton, &QPushButton::clicked, this, [this] {
        if (!lastCapturePath.isEmpty())
            QDesktopServices::openUrl(QUrl::fromLocalFile(lastCapturePath));
    });
    connect(ui->levelPrevActorsButton, &QPushButton::clicked, this, [this] {
        if (scenePageHistory.isEmpty()) return;
        sceneOffset = scenePageHistory.takeLast();
        refreshLevel();
    });
    connect(ui->levelNextActorsButton, &QPushButton::clicked, this, [this] {
        if (sceneNextOffset <= sceneOffset) return;
        scenePageHistory.append(sceneOffset);
        sceneOffset = sceneNextOffset;
        refreshLevel();
    });
    connect(ui->levelActorsTree, &QTreeWidget::itemSelectionChanged,
            this, &MainWindow::inspectSelectedActor);
    captureTimeoutTimer = new QTimer(this);
    captureTimeoutTimer->setSingleShot(true);
    captureTimeoutTimer->setInterval(30000);
    connect(captureTimeoutTimer, &QTimer::timeout, this, [this] {
        if (!capturePending) return;
        capturePending = false;
        ui->levelCaptureButton->setEnabled(true);
        ui->levelPreviewInfo->setText(tr("Captura demorou mais que 30 segundos; confira o Editor."));
        addLog("Error", tr("A ponte não respondeu à captura da cena em 30 segundos."));
    });
    connect(ui->levelCameraButton, &QPushButton::clicked, this,
            [this] { requestAction("Add Third-Person Camera"); });
    connect(ui->levelPlayButton, &QPushButton::clicked, this, &MainWindow::requestPlay);
    connect(ui->levelCreateMapButton, &QPushButton::clicked, this,
            [this] { requestAction("Create Level"); });
    connect(ui->levelDemoRoomButton, &QPushButton::clicked, this,
            [this] { requestAction("Demo Room"); });
    connect(ui->levelSaveMapButton, &QPushButton::clicked, this,
            [this] { requestAction("Save Level"); });
    connect(ui->levelOpenMapButton, &QPushButton::clicked, this,
            [this] { requestAction("Open Level"); });
    connect(ui->levelSpawnButton, &QPushButton::clicked, this,
            [this] { requestAction("Spawn Actor"); });
    connect(ui->levelTransformButton, &QPushButton::clicked, this,
            [this] { requestAction("Set Transform"); });
    connect(ui->levelMeshButton, &QPushButton::clicked, this,
            [this] { requestAction("Set Mesh"); });
    connect(ui->levelMaterialButton, &QPushButton::clicked, this,
            [this] { requestAction("Set Material"); });
    connect(ui->buildWindowsButton, &QPushButton::clicked, this,
            [this] { startPackageBuild("Win64"); });
    connect(ui->buildAndroidButton, &QPushButton::clicked, this,
            [this] { startPackageBuild("Android"); });
    connect(ui->buildClearButton, &QPushButton::clicked, ui->buildOutput, &QTextEdit::clear);
}

void MainWindow::registerCard(QFrame *card, const QString &action)
{
    cardActions.insert(card, action);
    card->installEventFilter(this);
    card->setCursor(Qt::PointingHandCursor);
    for (QWidget *child : card->findChildren<QWidget *>()) {
        cardActions.insert(child, action);
        child->installEventFilter(this);
        child->setCursor(Qt::PointingHandCursor);
    }
}

bool MainWindow::eventFilter(QObject *watched, QEvent *event)
{
    if (event->type() == QEvent::MouseButtonPress &&
        (watched == ui->topbar || watched == ui->appLogo || watched == ui->appTitle ||
         watched == ui->appSubtitle || watched == ui->connectionPill ||
         watched == ui->connectionLabel || watched == ui->connectionSubLabel)) {
        if (static_cast<QMouseEvent *>(event)->button() == Qt::LeftButton && windowHandle()) {
            windowHandle()->startSystemMove();
            return true;
        }
    }
    if (cardActions.contains(watched) && event->type() == QEvent::MouseButtonRelease &&
        static_cast<QMouseEvent *>(event)->button() == Qt::LeftButton) {
        const QString action = cardActions.value(watched);
        if (action == "Play") {
            requestPlay();
        } else requestAction(action);
        return true;
    }
    return QMainWindow::eventFilter(watched, event);
}

void MainWindow::resizeEvent(QResizeEvent *event)
{
    QMainWindow::resizeEvent(event);
    updateProjectPath();
    updateCapturePreview();
}

void MainWindow::setupConnection()
{
    socket = new QTcpSocket(this);
    retryTimer = new QTimer(this);
    retryTimer->setInterval(2500);
    connect(retryTimer, &QTimer::timeout, this, [this] {
        if (socket->state() == QAbstractSocket::UnconnectedState)
            socket->connectToHost(QHostAddress::LocalHost, BridgePort);
    });
    retryTimer->start();

    heartbeatTimer = new QTimer(this);
    heartbeatTimer->setInterval(12000);
    connect(heartbeatTimer, &QTimer::timeout, this, [this] {
        sendCommand("ping", "ping");
    });

    statusTimeoutTimer = new QTimer(this);
    statusTimeoutTimer->setSingleShot(true);
    statusTimeoutTimer->setInterval(10000);
    connect(statusTimeoutTimer, &QTimer::timeout, this, [this] {
        addLog("Error", tr("TCP conectado, mas o plugin não respondeu ao status em 10 segundos. "
                           "Confira o Output Log do Unreal e reinstale a ponte 0.10.0."));
        socket->abort();
    });

    playTimeoutTimer = new QTimer(this);
    playTimeoutTimer->setSingleShot(true);
    playTimeoutTimer->setInterval(8000);
    connect(playTimeoutTimer, &QTimer::timeout, this, [this] {
        if (!playRequestPending) return;
        playRequestPending = false;
        addLog("Error", tr("O plugin não respondeu ao Play em 8 segundos. "
                           "Confira o Output Log do Unreal."));
    });

    actionTimeoutTimer = new QTimer(this);
    actionTimeoutTimer->setSingleShot(true);
    actionTimeoutTimer->setInterval(10 * 60 * 1000);
    connect(actionTimeoutTimer, &QTimer::timeout, this, [this] {
        if (pendingActionId.isEmpty()) return;
        addLog("Error", tr("%1: o Editor não respondeu em 10 minutos; confira o Output Log.")
               .arg(pendingActionName));
        pendingActionId.clear();
        pendingActionName.clear();
    });

    connect(socket, &QTcpSocket::connected, this, [this] {
        setConnected(false);
        ui->connectionLabel->setText(tr("Verificando plugin..."));
        addLog("Bridge", tr("TCP conectado; aguardando status do plugin..."));
        if (sendCommand("status", "status")) {
            statusTimeoutTimer->start();
        } else {
            addLog("Error", tr("Não foi possível solicitar o status ao plugin."));
            socket->abort();
        }
    });
    connect(socket, &QTcpSocket::disconnected, this, [this] {
        if (connected) addLog("Error", tr("Editor desconectado. Tentando reconectar..."));
        heartbeatTimer->stop();
        statusTimeoutTimer->stop();
        playTimeoutTimer->stop();
        playRequestPending = false;
        if (!pendingActionId.isEmpty())
            addLog("Error", tr("%1: Editor desconectado durante a operação.").arg(pendingActionName));
        actionTimeoutTimer->stop();
        pendingActionId.clear();
        pendingActionName.clear();
        incoming.clear();
        setConnected(false);
    });
    connect(socket, &QTcpSocket::errorOccurred, this, [this](QAbstractSocket::SocketError) {
        if (connected || statusTimeoutTimer->isActive())
            addLog("Error", tr("Falha na conexão com o plugin: %1").arg(socket->errorString()));
    });
    connect(socket, &QTcpSocket::readyRead, this, &MainWindow::readSocket);
    QTimer::singleShot(0, this, [this] {
        socket->connectToHost(QHostAddress::LocalHost, BridgePort);
    });
}

void MainWindow::setConnected(bool value)
{
    connected = value;
    if (!value) incompatibleBridge = false;
    ui->connectionDot->setStyleSheet(value ? "color:#23ead2;" : "color:#ffb657;");
    ui->connectionLabel->setText(value ? tr("Connected to UE 5.8") : tr("Waiting for UE 5.8"));
    ui->connectionSubLabel->setText(value ? tr("Bridge online · 127.0.0.1") : "127.0.0.1:17777");
    if (!value) {
        projectDirectory.clear();
        projectName.clear();
        engineDirectory.clear();
        engineVersionText.clear();
        bridgeVersionText.clear();
        ui->projectName->setText(tr("Waiting for project..."));
        ui->projectPath->setText(tr("Connect to the UE Master Bridge"));
        ui->projectPath->setToolTip(QString());
        ui->engineVersion->setText(QStringLiteral("—"));
        ui->assetsTree->clear();
        ui->assetsCount->setText(tr("Aguardando projeto..."));
        ui->blueprintTree->clear();
        ui->blueprintCount->setText(tr("Aguardando conexão..."));
        ui->levelActorsTree->clear();
        sceneOffset = 0;
        sceneNextOffset = 0;
        scenePageHistory.clear();
        ui->levelActorDetails->clear();
        ui->levelPrevActorsButton->setEnabled(false);
        ui->levelNextActorsButton->setEnabled(false);
        if (captureTimeoutTimer) captureTimeoutTimer->stop();
        capturePending = false;
        captureImage = QPixmap();
        lastCapturePath.clear();
        ui->levelCaptureButton->setEnabled(true);
        ui->levelOpenCaptureButton->setEnabled(false);
        ui->levelPreviewInfo->setText(tr("Conecte o Editor para capturar a cena."));
        ui->levelViewportPreview->setPixmap(QPixmap());
        ui->levelViewportPreview->setText(tr("A prévia da cena aparecerá aqui."));
        ui->levelCurrentMap->setText(tr("Mapa aberto: aguardando Editor..."));
        ui->levelActorCount->setText(tr("Actors do nível aberto"));
        ui->levelMapsTree->clear();
        ui->levelMapsCount->setText(tr("Mapas salvos: aguardando projeto..."));
        ui->buildProjectInfo->setText(tr("Projeto: aguardando conexão..."));
    }
    updateSettings();
}

bool MainWindow::sendCommand(const QString &id, const QString &command,
                             const QJsonObject &parameters)
{
    if (socket->state() != QAbstractSocket::ConnectedState) return false;
    QJsonObject request = parameters;
    request.insert("id", id);
    request.insert("command", command);
    const QByteArray payload = QJsonDocument(request).toJson(QJsonDocument::Compact) + '\n';
    if (payload.size() > MaxLine) return false;
    if (socket->write(payload) != payload.size()) return false;
    socket->flush();
    return true;
}

void MainWindow::requestPlay()
{
    if (socket->state() != QAbstractSocket::ConnectedState) {
        addLog("Error", tr("Play não enviado: conecte o UE Master Bridge primeiro."));
        return;
    }
    if (!connected) {
        addLog("Error", incompatibleBridge
               ? tr("Play não enviado: instale o plugin UE Master Bridge 0.10.0 e reinicie o Editor.")
               : tr("Play não enviado: aguardando o status do plugin Unreal."));
        return;
    }
    if (!pendingActionId.isEmpty()) {
        addLog("Action", tr("Aguarde %1 terminar antes de iniciar Play.").arg(pendingActionName));
        return;
    }
    if (buildProcess && buildProcess->state() != QProcess::NotRunning) {
        addLog("Action", tr("Aguarde o empacotamento terminar antes de iniciar Play."));
        return;
    }
    if (playRequestPending) {
        addLog("Action", tr("O comando Play já está aguardando resposta do Unreal Editor."));
        return;
    }
    if (!sendCommand("play", "play")) {
        addLog("Error", tr("Não foi possível enviar o comando Play ao Unreal Editor."));
        return;
    }

    playRequestPending = true;
    playTimeoutTimer->start();
    addLog("Action", tr("Comando Play enviado ao Unreal Editor..."));
}

void MainWindow::requestAction(const QString &action)
{
    if (!connected || socket->state() != QAbstractSocket::ConnectedState) {
        addLog("Error", incompatibleBridge
                   ? tr("%1: instale a ponte UE Master Bridge 0.10.0 e reinicie o Editor.").arg(action)
                   : tr("%1: conecte o UE Master Bridge primeiro.").arg(action));
        return;
    }
    if (!pendingActionId.isEmpty()) {
        addLog("Action", tr("Aguarde o resultado de %1 antes de enviar outro comando.")
               .arg(pendingActionName));
        return;
    }
    if (buildProcess && buildProcess->state() != QProcess::NotRunning) {
        addLog("Action", tr("Aguarde o empacotamento terminar antes de editar o projeto."));
        return;
    }
    if (action == "Build Android") {
        startPackageBuild("Android");
        return;
    }

    QString command;
    QJsonObject parameters;
    if (action == "Import Asset") {
        const QStringList files = QFileDialog::getOpenFileNames(
            this, tr("Selecionar arquivos para importar"), QString(),
            tr("Arquivos 3D (*.fbx *.obj *.glb *.gltf)"));
        if (files.isEmpty()) return;
        if (files.size() > 16) {
            addLog("Error", tr("Selecione até 16 arquivos por importação."));
            return;
        }
        parameters.insert("files", QJsonArray::fromStringList(files));
        parameters.insert("destination", "/Game/Imported");
        command = "import_asset";
    } else if (action == "Create Blueprint") {
        bool accepted = false;
        const QString parentClass = QInputDialog::getItem(
            this, tr("Criar Blueprint"), tr("Classe pai:"),
            {"Character", "Pawn", "Actor"}, 0, false, &accepted);
        if (!accepted) return;
        const QString name = QInputDialog::getText(
            this, tr("Criar Blueprint"), tr("Nome em /Game/Blueprints:"),
            QLineEdit::Normal, "BP_Player", &accepted).trimmed();
        if (!accepted) return;
        if (name.isEmpty()) {
            addLog("Error", tr("Informe um nome para o novo Blueprint."));
            return;
        }
        parameters.insert("name", name);
        parameters.insert("parent_class", parentClass);
        command = "create_blueprint";
    } else if (action == "Create Object") {
        const QJsonObject example{
            {"name", "BP_Chest"},
            {"components", QJsonArray{
                QJsonObject{{"name", "StaticMesh_Chest"}, {"kind", "StaticMesh"},
                            {"mesh_path", "/Engine/BasicShapes/Cube"}},
                QJsonObject{{"name", "BoxCollision"}, {"kind", "BoxCollision"},
                            {"box_extent", QJsonObject{{"x", 60}, {"y", 60}, {"z", 60}}}},
                QJsonObject{{"name", "InteractionPoint"}, {"kind", "ScenePoint"},
                            {"location", QJsonObject{{"x", 0}, {"y", 0}, {"z", 90}}}}
            }},
            {"variables", QJsonArray{
                QJsonObject{{"name", "IsOpen"}, {"type", "bool"}, {"default", false}},
                QJsonObject{{"name", "LootAmount"}, {"type", "int"}, {"default", 3}},
                QJsonObject{{"name", "InteractionDistance"}, {"type", "float"}, {"default", 180}}
            }}
        };
        bool accepted = false;
        const QString input = QInputDialog::getMultiLineText(this, tr("Criar objeto reutilizável"),
            tr("Edite o JSON; name deve ser novo. Mesh existente em /Game ou /Engine."),
            QString::fromUtf8(QJsonDocument(example).toJson(QJsonDocument::Indented)), &accepted);
        if (!accepted) return;
        QJsonParseError parseError;
        const QJsonDocument doc = QJsonDocument::fromJson(input.toUtf8(), &parseError);
        if (parseError.error != QJsonParseError::NoError || !doc.isObject()) {
            addLog("Error", tr("JSON de objeto inválido: %1").arg(parseError.errorString()));
            return;
        }
        parameters = doc.object();
        command = "create_object";
    } else if (action == "Inspect Object") {
        bool accepted = false;
        const QString path = QInputDialog::getText(this, tr("Inspecionar objeto"),
            tr("Caminho do Blueprint em /Game/Objects/:"), QLineEdit::Normal,
            lastBlueprintPath.startsWith("/Game/Objects/") ? lastBlueprintPath
                                                          : "/Game/Objects/BP_Chest",
            &accepted).trimmed();
        if (!accepted) return;
        parameters.insert("object_path", path);
        command = "get_object_details";
    } else if (action == "Create Character") {
        const QJsonObject example{
            {"name", "BP_Hero"},
            {"camera", true},
            {"skeletal_mesh_path", "/Game/Characters/Mannequins/Meshes/SKM_Manny"},
            {"mesh_location", QJsonObject{{"x", 0}, {"y", 0}, {"z", -90}}}
        };
        bool accepted = false;
        const QString input = QInputDialog::getMultiLineText(this, tr("Criar Character"),
            tr("Edite o JSON: use uma Skeletal Mesh existente. Para um Character sem malha, remova skeletal_mesh_path e mesh_location."),
            QString::fromUtf8(QJsonDocument(example).toJson(QJsonDocument::Indented)), &accepted);
        if (!accepted) return;
        QJsonParseError parseError;
        const QJsonDocument doc = QJsonDocument::fromJson(input.toUtf8(), &parseError);
        if (parseError.error != QJsonParseError::NoError || !doc.isObject()) {
            addLog("Error", tr("JSON de personagem inválido: %1").arg(parseError.errorString()));
            return;
        }
        parameters = doc.object();
        command = "create_character";
    } else if (action == "Inspect Character") {
        bool accepted = false;
        const QString path = QInputDialog::getText(this, tr("Inspecionar Character"),
            tr("Caminho do Blueprint Character em /Game/:"), QLineEdit::Normal,
            lastBlueprintPath.startsWith("/Game/") ? lastBlueprintPath
                                                    : "/Game/Characters/BP_Hero",
            &accepted).trimmed();
        if (!accepted) return;
        parameters.insert("character_path", path);
        command = "get_character_details";
    } else if (action == "Create Blueprint Logic") {
        const QJsonObject example{
            {"blueprint_path", lastBlueprintPath.startsWith("/Game/")
                                   ? lastBlueprintPath : "/Game/Objects/BP_Chest"},
            {"event_name", "OpenChest"},
            {"condition", QJsonObject{{"variable", "IsOpen"}, {"equals", false}}},
            {"steps", QJsonArray{
                QJsonObject{{"kind", "set_variable"}, {"name", "IsOpen"}, {"value", true}},
                QJsonObject{{"kind", "print_string"}, {"message", "Chest opened"}}
            }}
        };
        bool accepted = false;
        const QString input = QInputDialog::getMultiLineText(this,
            tr("Criar lógica Blueprint"),
            tr("Edite o JSON. O evento deve ter nome livre; salve o Blueprint antes."),
            QString::fromUtf8(QJsonDocument(example).toJson(QJsonDocument::Indented)), &accepted);
        if (!accepted) return;
        QJsonParseError parseError;
        const QJsonDocument doc = QJsonDocument::fromJson(input.toUtf8(), &parseError);
        if (parseError.error != QJsonParseError::NoError || !doc.isObject()) {
            addLog("Error", tr("JSON do grafo inválido: %1").arg(parseError.errorString()));
            return;
        }
        parameters = doc.object();
        command = "create_blueprint_logic";
    } else if (action == "Inspect Blueprint Logic") {
        bool accepted = false;
        const QString path = QInputDialog::getText(this, tr("Inspecionar grafo"),
            tr("Caminho do Blueprint:"), QLineEdit::Normal,
            lastBlueprintPath.startsWith("/Game/") ? lastBlueprintPath
                                                     : "/Game/Objects/BP_Chest", &accepted).trimmed();
        if (!accepted) return;
        const QString event = QInputDialog::getText(this, tr("Inspecionar grafo"),
            tr("Nome do evento personalizado:"), QLineEdit::Normal,
            "OpenChest", &accepted).trimmed();
        if (!accepted) return;
        parameters = {{"blueprint_path", path}, {"event_name", event}};
        command = "get_blueprint_logic";
    } else if (action == "Add Third-Person Camera") {
        bool accepted = false;
        const QString path = QInputDialog::getText(
            this, tr("Câmera de terceira pessoa"),
            tr("Caminho do Blueprint Pawn/Character em /Game:"),
            QLineEdit::Normal,
            lastBlueprintPath.isEmpty() ? "/Game/Blueprints/BP_Player" : lastBlueprintPath,
            &accepted).trimmed();
        if (!accepted) return;
        if (path.isEmpty()) {
            addLog("Error", tr("Informe o caminho do Blueprint."));
            return;
        }
        parameters.insert("blueprint_path", path);
        command = "add_third_person_camera";
    } else if (action == "Compile") {
        command = "compile_blueprints";
    } else if (action == "Create Level" || action == "Demo Room") {
        bool accepted = false;
        const QString name = QInputDialog::getText(this,
            action == "Demo Room" ? tr("Montar sala jogável") : tr("Criar mapa vazio"),
            tr("Nome em /Game/UE_Master_Maps (sem sobrescrever):"),
            QLineEdit::Normal, action == "Demo Room" ? "L_SalaTeste" : "L_NovoMapa",
            &accepted).trimmed();
        if (!accepted) return;
        if (name.isEmpty()) { addLog("Error", tr("Informe o nome do mapa.")); return; }
        parameters.insert("name", name);
        command = action == "Demo Room" ? "create_demo_room" : "create_level";
    } else if (action == "Open Level") {
        QTreeWidgetItem *selected = ui->levelMapsTree->currentItem();
        if (!selected || selected->data(0, Qt::UserRole).toString().isEmpty()) {
            addLog("Error", tr("Selecione um mapa salvo na aba Mapas."));
            return;
        }
        parameters.insert("map", selected->data(0, Qt::UserRole).toString());
        command = "open_level";
    } else if (action == "Save Level") {
        command = "save_level";
    } else if (action == "Create Content Folder") {
        bool accepted = false;
        const QString folder = QInputDialog::getText(this, tr("Criar pasta"),
            tr("Caminho no Content Browser:"), QLineEdit::Normal,
            "/Game/Cenarios", &accepted).trimmed();
        if (!accepted) return;
        parameters.insert("folder", folder);
        command = "create_content_folder";
    } else if (action == "Move Asset" || action == "Duplicate Asset") {
        QTreeWidgetItem *selected = ui->assetsTree->currentItem();
        if (!selected || projectDirectory.isEmpty()) {
            addLog("Error", tr("Selecione um asset salvo na aba Assets."));
            return;
        }
        const QString content = QDir(projectDirectory).filePath("Content");
        const QString file = selected->data(0, Qt::UserRole).toString();
        QString relative = QDir::fromNativeSeparators(QDir(content).relativeFilePath(file));
        if (relative.startsWith("../") || !relative.endsWith(".uasset")) {
            addLog("Error", tr("O arquivo selecionado não é um asset do projeto."));
            return;
        }
        relative.chop(7);
        const QString source = "/Game/" + relative;
        bool accepted = false;
        const QString destination = QInputDialog::getText(this, tr("Organizar asset"),
            tr("Destino completo em /Game/:"), QLineEdit::Normal,
            action == "Duplicate Asset" ? source + "_Copy" : source, &accepted).trimmed();
        if (!accepted) return;
        parameters.insert("source", source);
        parameters.insert("destination", destination);
        command = action == "Duplicate Asset" ? "duplicate_asset" : "move_asset";
    } else if (action == "Compose Scene") {
        bool accepted = false;
        const QString example = R"({"actors":[
  {"kind":"StaticMesh","label":"Piso","mesh_path":"/Engine/BasicShapes/Cube",
   "transform":{"location":{"x":0,"y":0,"z":-50},"rotation":{"pitch":0,"yaw":0,"roll":0},
                "scale":{"x":10,"y":10,"z":1}}},
  {"kind":"PointLight","label":"Luz","transform":{"location":{"x":0,"y":0,"z":350},
    "rotation":{"pitch":0,"yaw":0,"roll":0},"scale":{"x":1,"y":1,"z":1}}}
]})";
        const QString input = QInputDialog::getMultiLineText(this, tr("Montar cena"),
            tr("JSON com 1 a 32 Actors. Insere no mapa aberto; salve o mapa após conferir."),
            example, &accepted);
        if (!accepted) return;
        QJsonParseError parseError;
        const QJsonDocument doc = QJsonDocument::fromJson(input.toUtf8(), &parseError);
        if (parseError.error != QJsonParseError::NoError || !doc.isObject() ||
            !doc.object().value("actors").isArray()) {
            addLog("Error", tr("JSON da cena inválido: %1").arg(parseError.errorString()));
            return;
        }
        parameters.insert("actors", doc.object().value("actors"));
        command = "compose_scene";
    } else if (action == "Undo" || action == "Redo") {
        command = action.toLower();
    } else if (action == "Spawn Actor") {
        bool accepted = false;
        const QString kind = QInputDialog::getItem(this, tr("Inserir Actor"),
            tr("Tipo de Actor:"),
            {"StaticMesh", "SkeletalMesh", "PointLight", "SpotLight", "DirectionalLight",
             "Camera", "TriggerBox", "Character", "DefaultPawn", "PlayerStart", "Blueprint"},
            0, false, &accepted);
        if (!accepted) return;
        parameters.insert("kind", kind);
        if (kind == "StaticMesh" || kind == "SkeletalMesh" || kind == "Blueprint") {
            const QString path = QInputDialog::getText(this, tr("Inserir Actor"),
                kind == "Blueprint" ? tr("Caminho do Blueprint em /Game/:")
                                    : kind == "SkeletalMesh" ? tr("Caminho da Skeletal Mesh:")
                                                             : tr("Caminho da Static Mesh:"),
                QLineEdit::Normal,
                kind == "Blueprint" ? (lastBlueprintPath.isEmpty()
                    ? "/Game/Blueprints/BP_Player" : lastBlueprintPath)
                    : kind == "SkeletalMesh" ? QString() : "/Engine/BasicShapes/Cube",
                &accepted).trimmed();
            if (!accepted) return;
            if (path.isEmpty()) { addLog("Error", tr("Informe o caminho do asset.")); return; }
            parameters.insert(kind == "Blueprint" ? "blueprint_path"
                               : kind == "SkeletalMesh" ? "skeletal_mesh_path" : "mesh_path", path);
        }
        const QString label = QInputDialog::getText(this, tr("Inserir Actor"),
            tr("Nome exibido no nível (opcional):"), QLineEdit::Normal,
            kind == "StaticMesh" ? "Novo_Bloco" : kind, &accepted).trimmed();
        if (!accepted) return;
        parameters.insert("label", label);
        if (kind == "DefaultPawn") parameters.insert("auto_possess_player", true);
        QJsonObject transform{{"location", QJsonObject{{"x", 0}, {"y", 0}, {"z", 100}}},
                              {"rotation", QJsonObject{{"pitch", 0}, {"yaw", 0}, {"roll", 0}}},
                              {"scale", QJsonObject{{"x", 1}, {"y", 1}, {"z", 1}}}};
        if (!askTransform(this, transform, tr("Posição, rotação e escala do Actor"))) return;
        parameters.insert("transform", transform);
        command = "spawn_actor";
    } else if (action == "Rename Actor" || action == "Duplicate Actor" ||
               action == "Delete Actor" || action == "Attach Actor" ||
               action == "Detach Actor" || action == "Actor Properties" ||
               action == "Add Component" || action == "Remove Component" ||
               action == "Frame Actor") {
        QTreeWidgetItem *selected = ui->levelActorsTree->currentItem();
        if (!selected) { addLog("Error", tr("Selecione um Actor na aba Actors.")); return; }
        parameters.insert("actor_path", selected->data(0, Qt::UserRole).toString());
        bool accepted = false;
        if (action == "Delete Actor") {
            if (QMessageBox::question(this, tr("Excluir Actor"),
                tr("Excluir %1 do mapa aberto? O mapa não será salvo automaticamente.")
                    .arg(selected->text(0))) != QMessageBox::Yes) return;
            command = "delete_actor";
        } else if (action == "Duplicate Actor") {
            parameters.insert("offset", QJsonObject{{"x", 100}, {"y", 0}, {"z", 0}});
            command = "duplicate_actor";
        } else if (action == "Rename Actor") {
            const QString label = QInputDialog::getText(this, tr("Renomear Actor"),
                tr("Novo nome no Outliner:"), QLineEdit::Normal, selected->text(0),
                &accepted).trimmed();
            if (!accepted) return;
            parameters.insert("label", label);
            command = "rename_actor";
        } else if (action == "Attach Actor") {
            const QString parent = QInputDialog::getText(this, tr("Vincular Actor"),
                tr("Path do Actor pai (copie da lista/detalhes):"), QLineEdit::Normal,
                QString(), &accepted).trimmed();
            if (!accepted) return;
            parameters.insert("parent_path", parent);
            command = "attach_actor";
        } else if (action == "Detach Actor") {
            command = "detach_actor";
        } else if (action == "Actor Properties") {
            const QString input = QInputDialog::getMultiLineText(this,
                tr("Propriedades do Actor"),
                tr("Campos: collision_enabled, simulate_physics, folder, tags, mobility, "
                   "light_intensity e attenuation_radius."),
                "{\"collision_enabled\":true}", &accepted);
            if (!accepted) return;
            QJsonParseError parseError;
            const QJsonDocument doc = QJsonDocument::fromJson(input.toUtf8(), &parseError);
            if (parseError.error != QJsonParseError::NoError || !doc.isObject()) {
                addLog("Error", tr("Propriedades JSON inválidas: %1").arg(parseError.errorString()));
                return;
            }
            const QJsonObject allowed = doc.object();
            const QStringList keys = {"collision_enabled", "simulate_physics", "folder",
                                      "tags", "mobility", "light_intensity", "attenuation_radius"};
            for (auto it = allowed.begin(); it != allowed.end(); ++it) {
                if (!keys.contains(it.key())) {
                    addLog("Error", tr("Propriedade não permitida: %1").arg(it.key()));
                    return;
                }
                parameters.insert(it.key(), it.value());
            }
            command = "set_actor_properties";
        } else if (action == "Add Component" || action == "Remove Component") {
            const QString name = QInputDialog::getText(this, tr("Componente"),
                tr("Nome do componente (Bridge_...):"), QLineEdit::Normal,
                "Bridge_01", &accepted).trimmed();
            if (!accepted) return;
            parameters.insert("component_name", name);
            if (action == "Add Component") {
                const QString kind = QInputDialog::getItem(this, tr("Componente"),
                    tr("Tipo:"), {"BoxCollision", "PointLight", "StaticMesh"},
                    0, false, &accepted);
                if (!accepted) return;
                parameters.insert("component_kind", kind);
                if (kind == "StaticMesh") {
                    const QString path = QInputDialog::getText(this, tr("Componente"),
                        tr("Static Mesh:"), QLineEdit::Normal, "/Engine/BasicShapes/Cube",
                        &accepted).trimmed();
                    if (!accepted) return;
                    parameters.insert("mesh_path", path);
                }
            }
            command = action == "Add Component" ? "add_component" : "remove_component";
        } else {
            command = "frame_actor";
        }
    } else if (action == "Set Transform" || action == "Set Mesh" || action == "Set Material") {
        QTreeWidgetItem *selected = ui->levelActorsTree->currentItem();
        if (!selected) { addLog("Error", tr("Selecione um Actor na aba Actors.")); return; }
        parameters.insert("actor_path", selected->data(0, Qt::UserRole).toString());
        if (action == "Set Transform") {
            QJsonObject transform = selected->data(0, Qt::UserRole + 1).toJsonObject();
            if (transform.isEmpty()) {
                addLog("Error", tr("Aguarde os detalhes do Actor carregarem e tente novamente."));
                return;
            }
            if (!askTransform(this, transform, tr("Editar transform de %1").arg(selected->text(0)))) return;
            parameters.insert("transform", transform);
            command = "set_actor_transform";
        } else {
            bool accepted = false;
            const QString path = QInputDialog::getText(this, tr("Editar Actor"),
                action == "Set Mesh" ? tr("Caminho da Static Mesh:")
                                     : tr("Caminho do Material:"),
                QLineEdit::Normal,
                action == "Set Mesh" ? "/Engine/BasicShapes/Cube"
                                     : "/Engine/BasicShapes/BasicShapeMaterial",
                &accepted).trimmed();
            if (!accepted) return;
            if (path.isEmpty()) { addLog("Error", tr("Informe o caminho do asset.")); return; }
            parameters.insert(action == "Set Mesh" ? "mesh_path" : "material_path", path);
            if (action == "Set Material") {
                const int slot = QInputDialog::getInt(this, tr("Material"),
                    tr("Slot de material (0 a 7):"), 0, 0, 7, 1, &accepted);
                if (!accepted) return;
                parameters.insert("slot", slot);
            }
            command = action == "Set Mesh" ? "set_actor_mesh" : "set_actor_material";
        }
    } else {
        addLog("Error", tr("Ação desconhecida: %1").arg(action));
        return;
    }

    const QString requestId = QUuid::createUuid().toString(QUuid::WithoutBraces);
    if (!sendCommand(requestId, command, parameters)) {
        addLog("Error", tr("Não foi possível enviar %1 ao Editor.").arg(action));
        return;
    }
    pendingActionId = requestId;
    pendingActionName = action;
    actionTimeoutTimer->start();
    addLog("Action", tr("%1: solicitado ao Unreal Editor...").arg(action));
}

void MainWindow::handleBuildOutput()
{
    if (!buildProcess) return;
    buildLineBuffer += buildProcess->readAllStandardOutput();
    int newline = -1;
    while ((newline = buildLineBuffer.indexOf('\n')) >= 0) {
        const QByteArray line = buildLineBuffer.left(newline).trimmed();
        buildLineBuffer.remove(0, newline + 1);
        if (!line.isEmpty()) addLog("Build", QString::fromUtf8(line));
    }
    if (buildLineBuffer.size() > 64 * 1024) {
        addLog("Build", QString::fromUtf8(buildLineBuffer.left(64 * 1024)));
        buildLineBuffer.remove(0, 64 * 1024);
    }
}

void MainWindow::startPackageBuild(const QString &platform)
{
#ifndef Q_OS_WIN
    addLog("Error", tr("O empacotamento deste projeto usa RunUAT.bat no Windows."));
    return;
#else
    if (platform != "Android" && platform != "Win64") return;
    if (!connected || projectDirectory.isEmpty() || engineDirectory.isEmpty()) {
        addLog("Error", tr("Conecte a ponte e abra um projeto antes de empacotar."));
        return;
    }
    if (!pendingActionId.isEmpty() || playRequestPending) {
        addLog("Build", tr("Aguarde o comando pendente terminar antes do empacotamento."));
        return;
    }
    if (buildProcess && buildProcess->state() != QProcess::NotRunning) {
        addLog("Build", tr("Já existe um empacotamento em execução."));
        return;
    }
    const QString project = QDir(projectDirectory).filePath(projectName + ".uproject");
    const QString runUat = QDir(engineDirectory).filePath("Build/BatchFiles/RunUAT.bat");
    if (!QFileInfo::exists(project) || !QFileInfo::exists(runUat)) {
        addLog("Error", tr("Projeto ou RunUAT.bat não encontrado: %1 | %2").arg(project, runUat));
        return;
    }
    const QString destination = QFileDialog::getExistingDirectory(
        this, tr("Escolha a pasta de saída para o pacote %1").arg(platform), projectDirectory);
    if (destination.isEmpty()) return;

    // cmd.exe expands %, ! and ^ even inside quotes; reject those paths.
    for (const QString &path : {runUat, project, destination}) {
        if (path.contains('%') || path.contains('!') || path.contains('^') ||
            path.contains('"') || path.contains('\r') || path.contains('\n')) {
            addLog("Error", tr("O caminho contém caracteres que o RunUAT.bat não aceita: %1").arg(path));
            return;
        }
    }

    if (!buildProcess) {
        buildProcess = new QProcess(this);
        buildProcess->setProcessChannelMode(QProcess::MergedChannels);
        connect(buildProcess, &QProcess::readyReadStandardOutput,
                this, &MainWindow::handleBuildOutput);
        connect(buildProcess, &QProcess::errorOccurred, this, [this](QProcess::ProcessError error) {
            if (error == QProcess::FailedToStart) {
                ui->buildStatus->setText(tr("Falha ao iniciar o empacotamento %1.").arg(buildPlatform));
                ui->buildWindowsButton->setEnabled(true);
                ui->buildAndroidButton->setEnabled(true);
                addLog("Error", tr("Não foi possível iniciar RunUAT: %1").arg(buildProcess->errorString()));
            }
        });
        connect(buildProcess, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished),
                this, [this](int exitCode, QProcess::ExitStatus status) {
            handleBuildOutput();
            if (!buildLineBuffer.trimmed().isEmpty())
                addLog("Build", QString::fromUtf8(buildLineBuffer.trimmed()));
            buildLineBuffer.clear();
            const bool success = status == QProcess::NormalExit && exitCode == 0;
            ui->buildStatus->setText(success
                ? tr("Pacote %1 concluído.").arg(buildPlatform)
                : tr("Pacote %1 falhou (código %2).").arg(buildPlatform).arg(exitCode));
            ui->buildWindowsButton->setEnabled(true);
            ui->buildAndroidButton->setEnabled(true);
            if (success)
                addLog("Build", tr("%1 empacotado com sucesso.").arg(buildPlatform));
            else
                addLog("Error", tr("Empacotamento %1 falhou (código %2). Consulte a saída do UAT.")
                       .arg(buildPlatform).arg(exitCode));
        });
    }

    buildPlatform = platform;
    buildLineBuffer.clear();
    buildProcess->setProgram("cmd.exe");
    buildProcess->setWorkingDirectory(projectDirectory);
    const QString command = QStringLiteral("/D /S /C \"\"%1\" BuildCookRun "
       "-project=\"%2\" -platform=%3 -clientconfig=%4 "
       "-build -cook -stage -pak -package -archive -archivedirectory=\"%5\" "
       "-nocompileeditor -unattended -utf8output\"")
        .arg(QDir::toNativeSeparators(runUat), QDir::toNativeSeparators(project),
             platform, ui->buildConfig->currentText(), QDir::toNativeSeparators(destination));
    buildProcess->setNativeArguments(command);
    ui->buildWindowsButton->setEnabled(false);
    ui->buildAndroidButton->setEnabled(false);
    ui->buildStatus->setText(tr("Empacotando %1 (%2)...").arg(platform, ui->buildConfig->currentText()));
    buildProcess->start();
    addLog("Build", tr("Iniciando pacote %1 de %2 em %3...")
           .arg(platform, projectName, QDir::toNativeSeparators(destination)));
#endif
}

void MainWindow::openProjectFolder()
{
    if (projectDirectory.isEmpty() || !QDir(projectDirectory).exists()) {
        addLog("Error", tr("A pasta do projeto ainda não está disponível."));
        return;
    }
    QDesktopServices::openUrl(QUrl::fromLocalFile(projectDirectory));
}

void MainWindow::refreshAssets()
{
    ui->assetsTree->clear();
    const QString content = QDir(projectDirectory).filePath("Content");
    if (projectDirectory.isEmpty() || !QDir(content).exists()) {
        ui->assetsCount->setText(tr("Aguardando pasta Content do projeto..."));
        return;
    }
    QDirIterator files(content, {"*.uasset"}, QDir::Files, QDirIterator::Subdirectories);
    int loaded = 0;
    while (files.hasNext() && loaded < 5000) {
        const QFileInfo info(files.next());
        const QString folder = QDir(content).relativeFilePath(info.absolutePath());
        auto *item = new QTreeWidgetItem(ui->assetsTree,
            {info.completeBaseName(), tr("Asset UE"), folder == "." ? "Content" : folder});
        item->setData(0, Qt::UserRole, info.absoluteFilePath());
        ++loaded;
    }
    ui->assetsTree->sortItems(0, Qt::AscendingOrder);
    filterAssets();
    if (loaded == 5000)
        ui->assetsCount->setText(tr("Mostrando até 5000 assets; consulte outras pastas em Content."));
}

void MainWindow::filterAssets()
{
    const QString query = ui->assetsSearch->text().trimmed();
    int visible = 0;
    for (int i = 0; i < ui->assetsTree->topLevelItemCount(); ++i) {
        QTreeWidgetItem *item = ui->assetsTree->topLevelItem(i);
        const bool found = query.isEmpty() || item->text(0).contains(query, Qt::CaseInsensitive) ||
                           item->text(1).contains(query, Qt::CaseInsensitive) ||
                           item->text(2).contains(query, Qt::CaseInsensitive);
        item->setHidden(!found);
        visible += found ? 1 : 0;
    }
    if (!projectDirectory.isEmpty())
        ui->assetsCount->setText(tr("%1 de %2 assets exibidos · Content do projeto")
            .arg(visible).arg(ui->assetsTree->topLevelItemCount()));
}

void MainWindow::refreshBlueprints()
{
    if (!connected) {
        ui->blueprintCount->setText(tr("Conecte o Unreal Editor para listar os Blueprints."));
        return;
    }
    const QString search = ui->blueprintSearch->text().trimmed();
    if (search.size() > 100) {
        ui->blueprintCount->setText(tr("Use no máximo 100 caracteres na busca."));
        return;
    }
    ui->blueprintCount->setText(tr("Consultando Blueprints no Editor..."));
    if (!sendCommand("blueprints", "list_blueprints", {{"search", search}}))
        ui->blueprintCount->setText(tr("Falha ao solicitar lista de Blueprints."));
}

void MainWindow::refreshLevel()
{
    if (!connected) {
        ui->levelCurrentMap->setText(tr("Mapa aberto: aguardando Editor..."));
        return;
    }
    ui->levelActorCount->setText(tr("Consultando cena do Editor..."));
    if (!sendCommand("scene_snapshot", "get_scene_snapshot", {{"offset", sceneOffset}}))
        ui->levelActorCount->setText(tr("Falha ao solicitar Actors do nível."));
}

void MainWindow::captureView()
{
    if (!connected) {
        ui->levelPreviewInfo->setText(tr("Conecte o Editor para capturar a cena."));
        return;
    }
    if (capturePending) return;
    if (!sendCommand("capture_view", "capture_view")) {
        ui->levelPreviewInfo->setText(tr("Não foi possível solicitar uma captura ao Editor."));
        return;
    }
    capturePending = true;
    ui->levelCaptureButton->setEnabled(false);
    ui->levelPreviewInfo->setText(tr("Capturando a cena a partir da câmera do viewport..."));
    captureTimeoutTimer->start();
}

void MainWindow::updateCapturePreview()
{
    if (!ui || !ui->levelViewportPreview || captureImage.isNull()) return;
    ui->levelViewportPreview->setPixmap(captureImage.scaled(
        ui->levelViewportPreview->size(), Qt::KeepAspectRatio, Qt::SmoothTransformation));
}

void MainWindow::inspectSelectedActor()
{
    QTreeWidgetItem *item = ui->levelActorsTree->currentItem();
    if (!item || !connected) {
        ui->levelActorDetails->clear();
        return;
    }
    const QString path = item->data(0, Qt::UserRole).toString();
    ui->levelActorDetails->setPlainText(tr("Consultando %1...").arg(item->text(0)));
    if (!sendCommand("actor_details", "get_actor_details", {{"actor_path", path}}))
        ui->levelActorDetails->setPlainText(tr("Falha ao consultar os detalhes do Actor."));
}

void MainWindow::refreshMaps()
{
    ui->levelMapsTree->clear();
    const QString content = QDir(projectDirectory).filePath("Content");
    if (projectDirectory.isEmpty() || !QDir(content).exists()) {
        ui->levelMapsCount->setText(tr("Mapas salvos: aguardando projeto..."));
        return;
    }
    QDirIterator maps(content, {"*.umap"}, QDir::Files, QDirIterator::Subdirectories);
    int count = 0;
    while (maps.hasNext() && count < 1000) {
        const QFileInfo info(maps.next());
        const QString folder = QDir(content).relativeFilePath(info.absolutePath());
        auto *item = new QTreeWidgetItem(ui->levelMapsTree,
            {info.completeBaseName(), folder == "." ? "Content" : folder});
        QString relative = QDir::fromNativeSeparators(
            QDir(content).relativeFilePath(info.absoluteFilePath()));
        relative.chop(5); // .umap
        item->setData(0, Qt::UserRole, "/Game/" + relative);
        ++count;
    }
    ui->levelMapsTree->sortItems(0, Qt::AscendingOrder);
    ui->levelMapsCount->setText(count == 1000
        ? tr("Mostrando até 1000 mapas salvos") : tr("Mapas salvos: %1").arg(count));
}

void MainWindow::updateSettings()
{
    ui->settingsState->setText(connected
        ? tr("Conectado ao Unreal Editor") : tr("Aguardando Unreal Editor..."));
    ui->settingsProject->setText(projectDirectory.isEmpty()
        ? tr("Projeto: aguardando conexão...")
        : tr("Projeto: %1\n%2").arg(projectName + ".uproject",
            QDir::toNativeSeparators(projectDirectory)));
    ui->settingsEngine->setText(engineDirectory.isEmpty()
        ? tr("Engine: aguardando conexão...")
        : tr("Engine %1: %2").arg(engineVersionText,
            QDir::toNativeSeparators(engineDirectory)));
    ui->settingsBridge->setText(bridgeVersionText.isEmpty()
        ? tr("UE Master Bridge: aguardando conexão...")
        : tr("UE Master Bridge %1 · protocolo 1").arg(bridgeVersionText));
}

void MainWindow::readSocket()
{
    incoming += socket->readAll();
    int separator = -1;
    while ((separator = incoming.indexOf('\n')) >= 0) {
        if (separator > MaxLine) {
            addLog("Error", tr("Resposta maior que 64 KiB."));
            socket->disconnectFromHost();
            return;
        }
        const QByteArray line = incoming.left(separator);
        incoming.remove(0, separator + 1);
        handleResponse(line);
    }
    if (incoming.size() > MaxLine) {
        addLog("Error", tr("Resposta incompleta maior que 64 KiB."));
        socket->disconnectFromHost();
    }
}

void MainWindow::handleResponse(const QByteArray &line)
{
    QJsonParseError error;
    const QJsonDocument document = QJsonDocument::fromJson(line, &error);
    if (error.error != QJsonParseError::NoError || !document.isObject()) {
        addLog("Error", tr("Resposta JSON inválida recebida."));
        if (statusTimeoutTimer->isActive()) {
            statusTimeoutTimer->stop();
            incompatibleBridge = true;
            ui->connectionLabel->setText(tr("Resposta inválida"));
        }
        return;
    }
    const QJsonObject data = document.object();
    const QString responseId = data.value("id").toString();
    const bool actionResponse = !pendingActionId.isEmpty() && responseId == pendingActionId;
    const QString actionName = actionResponse ? pendingActionName : QString();
    if (actionResponse) {
        actionTimeoutTimer->stop();
        pendingActionId.clear();
        pendingActionName.clear();
    }
    if (!data.value("ok").toBool()) {
        if (responseId == "play") {
            playTimeoutTimer->stop();
            playRequestPending = false;
        } else if (responseId == "status") {
            statusTimeoutTimer->stop();
            incompatibleBridge = true;
            ui->connectionLabel->setText(tr("Plugin indisponível"));
        }

        QString errorMessage;
        const QJsonValue errorValue = data.value("error");
        if (errorValue.isString()) {
            errorMessage = errorValue.toString();
        } else if (errorValue.isObject()) {
            errorMessage = errorValue.toObject().value("message").toString();
        }
        if (errorMessage.isEmpty()) errorMessage = tr("Erro desconhecido retornado pela ponte Unreal.");
        if (responseId == "blueprints") ui->blueprintCount->setText(errorMessage);
        if (responseId == "scene_snapshot") ui->levelActorCount->setText(errorMessage);
        if (responseId == "actor_details") ui->levelActorDetails->setPlainText(errorMessage);
        if (responseId == "capture_view") {
            captureTimeoutTimer->stop();
            capturePending = false;
            ui->levelCaptureButton->setEnabled(true);
            ui->levelPreviewInfo->setText(errorMessage);
        }
        if (actionResponse && actionName == "Import Asset") {
            const int imported = data.value("result").toObject().value("imported").toInt();
            if (imported > 0) {
                addLog("Action", tr("Importação parcial: %1 asset(s) importado(s).").arg(imported));
                if (ui->pageStack->currentWidget() == ui->assetsPage) refreshAssets();
            }
        }
        addLog("Error", responseId == "play"
                   ? tr("Play não iniciado: %1").arg(errorMessage)
                   : (actionResponse ? actionName + ": " + errorMessage : errorMessage));
        return;
    }

    if (actionResponse) {
        const QJsonObject result = data.value("result").toObject();
        if (actionName == "Create Blueprint") {
            lastBlueprintPath = result.value("asset_path").toString();
            addLog("Action", tr("Blueprint criado e salvo: %1").arg(lastBlueprintPath));
            if (ui->pageStack->currentWidget() == ui->blueprintPage) refreshBlueprints();
        } else if (actionName == "Create Object") {
            lastBlueprintPath = result.value("asset_path").toString();
            addLog("Action", tr("Objeto criado e salvo: %1 (%2 componentes, %3 variáveis).")
                .arg(lastBlueprintPath).arg(result.value("total_components").toInt())
                .arg(result.value("total_variables").toInt()));
            if (ui->pageStack->currentWidget() == ui->blueprintPage) refreshBlueprints();
        } else if (actionName == "Inspect Object") {
            addLog("Action", tr("Estrutura de %1:\n%2")
                .arg(result.value("object_path").toString(),
                     QString::fromUtf8(QJsonDocument(result).toJson(QJsonDocument::Indented))));
        } else if (actionName == "Create Character") {
            lastBlueprintPath = result.value("asset_path").toString();
            addLog("Action", tr("Character criado e salvo: %1. Malha: %2; câmera: %3.")
                .arg(lastBlueprintPath,
                     result.value("skeletal_mesh_path").toString().isEmpty()
                         ? tr("não configurada") : result.value("skeletal_mesh_path").toString(),
                     result.value("has_third_person_camera").toBool() ? tr("sim") : tr("não")));
            if (ui->pageStack->currentWidget() == ui->blueprintPage) refreshBlueprints();
        } else if (actionName == "Inspect Character") {
            addLog("Action", tr("Configuração de %1:\n%2")
                .arg(result.value("character_path").toString(),
                     QString::fromUtf8(QJsonDocument(result).toJson(QJsonDocument::Indented))));
        } else if (actionName == "Create Blueprint Logic") {
            lastBlueprintPath = result.value("blueprint_path").toString();
            addLog("Action", tr("Evento %1 criado em %2: %3 nós; Blueprint compilado e salvo.")
                .arg(result.value("event_name").toString(), lastBlueprintPath)
                .arg(result.value("created_nodes").toInt()));
        } else if (actionName == "Inspect Blueprint Logic") {
            addLog("Action", tr("Grafo do evento %1 em %2:\n%3")
                .arg(result.value("event_name").toString(),
                     result.value("blueprint_path").toString(),
                     QString::fromUtf8(QJsonDocument(result).toJson(QJsonDocument::Indented))));
        } else if (actionName == "Add Third-Person Camera") {
            addLog("Action", tr("Spring Arm e câmera adicionados a %1; Blueprint compilado e salvo.")
                   .arg(result.value("blueprint_path").toString()));
            if (ui->pageStack->currentWidget() == ui->levelPage) refreshLevel();
        } else if (actionName == "Compile") {
            addLog("Action", tr("Blueprints alterados compilados: %1 (avisos: %2).")
                   .arg(result.value("compiled").toInt()).arg(result.value("warnings").toInt()));
        } else if (actionName == "Import Asset") {
            addLog("Action", tr("Assets importados e salvos em /Game/Imported: %1.")
                   .arg(result.value("imported").toInt()));
            if (ui->pageStack->currentWidget() == ui->assetsPage) refreshAssets();
        } else if (actionName == "Create Level" || actionName == "Open Level" ||
                   actionName == "Demo Room") {
            const QString map = result.value("map").toString();
            addLog("Action", actionName == "Demo Room"
                ? tr("Sala de teste salva em %1: %2 Actors, com Pawn possuído pelo Player 0.")
                    .arg(map).arg(result.value("total").toInt())
                : actionName == "Open Level" ? tr("Mapa aberto: %1").arg(map)
                                              : tr("Mapa vazio criado e salvo: %1").arg(map));
            sceneOffset = 0;
            sceneNextOffset = 0;
            scenePageHistory.clear();
            refreshLevel();
            refreshMaps();
            captureView();
        } else if (actionName == "Save Level") {
            addLog("Action", tr("Mapa salvo: %1").arg(result.value("map").toString()));
            refreshMaps();
        } else if (actionName == "Create Content Folder" || actionName == "Move Asset" ||
                   actionName == "Duplicate Asset") {
            addLog("Action", tr("%1 concluído: %2").arg(actionName,
                result.value(actionName == "Create Content Folder" ? "folder" : "destination").toString()));
            refreshAssets();
            refreshBlueprints();
        } else if (actionName == "Spawn Actor" || actionName == "Set Transform" ||
                   actionName == "Set Mesh" || actionName == "Set Material") {
            if (actionName == "Spawn Actor" || actionName == "Set Transform") {
                const QJsonObject actor = result.value("actor").toObject();
                addLog("Action", tr("%1: %2 (%3)").arg(actionName,
                    actor.value("label").toString(), actor.value("path").toString()));
            } else {
                addLog("Action", tr("%1 atualizado: %2").arg(actionName,
                    result.value(actionName == "Set Mesh" ? "mesh_path" : "material_path").toString()));
            }
            if (actionName == "Spawn Actor") {
                sceneOffset = 0;
                scenePageHistory.clear();
            }
            refreshLevel();
            captureView();
        } else if (actionName == "Compose Scene" || actionName == "Rename Actor" ||
                   actionName == "Duplicate Actor" || actionName == "Delete Actor" ||
                   actionName == "Attach Actor" || actionName == "Detach Actor" ||
                   actionName == "Actor Properties" || actionName == "Add Component" ||
                   actionName == "Remove Component" || actionName == "Undo" ||
                   actionName == "Redo" || actionName == "Frame Actor") {
            addLog("Action", actionName == "Compose Scene"
                ? tr("Cena: %1 Actors inseridos no mapa aberto. Revise e salve o mapa.")
                    .arg(result.value("total").toInt())
                : tr("%1 concluído.").arg(actionName));
            if (actionName == "Compose Scene" || actionName == "Duplicate Actor" ||
                actionName == "Undo" || actionName == "Redo") {
                sceneOffset = 0;
                scenePageHistory.clear();
            }
            if (actionName != "Frame Actor") refreshLevel();
            captureView();
        }
        return;
    }

    if (responseId == "blueprints" && connected) {
        const QJsonObject result = data.value("result").toObject();
        const QJsonArray assets = result.value("assets").toArray();
        ui->blueprintTree->clear();
        for (const QJsonValue &value : assets) {
            const QJsonObject blueprint = value.toObject();
            const QString path = blueprint.value("path").toString();
            auto *item = new QTreeWidgetItem(ui->blueprintTree,
                {blueprint.value("name").toString(), blueprint.value("kind").toString(),
                 path.section('/', 0, -2)});
            item->setData(0, Qt::UserRole, path);
            if (path == lastBlueprintPath) ui->blueprintTree->setCurrentItem(item);
        }
        ui->blueprintTree->sortItems(0, Qt::AscendingOrder);
        ui->blueprintCount->setText(tr("Exibindo %1 de %2 Blueprints do projeto")
            .arg(assets.size()).arg(result.value("total").toInt()));
        return;
    }
    if (responseId == "scene_snapshot" && connected) {
        const QJsonObject result = data.value("result").toObject();
        if (result.value("offset").toInt() != sceneOffset) return;
        const QJsonArray actors = result.value("actors").toArray();
        const int total = result.value("total").toInt();
        if (sceneOffset > 0 && sceneOffset >= total) {
            sceneOffset = 0;
            scenePageHistory.clear();
            refreshLevel();
            return;
        }
        sceneNextOffset = result.value("next_offset").toInt();
        ui->levelCurrentMap->setText(tr("Mapa aberto: %1").arg(result.value("map").toString()));
        ui->levelActorsTree->clear();
        ui->levelActorDetails->clear();
        for (const QJsonValue &value : actors) {
            const QJsonObject actor = value.toObject();
            const QJsonObject pos = actor.value("transform").toObject().value("location").toObject();
            const QString position = QString("%1, %2, %3")
                .arg(pos.value("x").toDouble(), 0, 'f', 0)
                .arg(pos.value("y").toDouble(), 0, 'f', 0)
                .arg(pos.value("z").toDouble(), 0, 'f', 0);
            auto *item = new QTreeWidgetItem(ui->levelActorsTree,
                {actor.value("label").toString(), actor.value("class").toString(), position});
            item->setData(0, Qt::UserRole, actor.value("path").toString());
        }
        ui->levelPrevActorsButton->setEnabled(!scenePageHistory.isEmpty());
        ui->levelNextActorsButton->setEnabled(result.value("has_more").toBool());
        ui->levelActorCount->setText(tr("Actors %1–%2 de %3 no nível aberto")
            .arg(actors.isEmpty() ? 0 : sceneOffset + 1)
            .arg(sceneOffset + actors.size()).arg(total));
        return;
    }
    if (responseId == "actor_details" && connected) {
        const QJsonObject result = data.value("result").toObject();
        const QTreeWidgetItem *selected = ui->levelActorsTree->currentItem();
        if (!selected || selected->data(0, Qt::UserRole).toString() != result.value("path").toString())
            return;
        const auto coords = [](const QJsonObject &v) {
            return QString("X %1, Y %2, Z %3")
                .arg(v.value("x").toDouble(), 0, 'f', 1)
                .arg(v.value("y").toDouble(), 0, 'f', 1)
                .arg(v.value("z").toDouble(), 0, 'f', 1);
        };
        const QJsonObject transform = result.value("transform").toObject();
        ui->levelActorsTree->currentItem()->setData(0, Qt::UserRole + 1, transform);
        const QJsonObject rotation = transform.value("rotation").toObject();
        QStringList lines;
        lines << tr("%1 · %2").arg(result.value("label").toString(),
                                  result.value("class").toString());
        lines << tr("Posição: %1").arg(coords(transform.value("location").toObject()));
        lines << tr("Rotação: pitch %1, yaw %2, roll %3")
                    .arg(rotation.value("pitch").toDouble(), 0, 'f', 1)
                    .arg(rotation.value("yaw").toDouble(), 0, 'f', 1)
                    .arg(rotation.value("roll").toDouble(), 0, 'f', 1);
        lines << tr("Escala: %1").arg(coords(transform.value("scale").toObject()));
        lines << tr("Colisão: %1").arg(result.value("collision_enabled").toBool()
            ? tr("ativada") : tr("desativada"));
        lines << tr("Componentes: %1").arg(result.value("total_components").toInt());
        for (const QJsonValue &value : result.value("components").toArray()) {
            const QJsonObject component = value.toObject();
            lines << "  • " + component.value("name").toString() + " [" +
                component.value("class").toString() + "]";
            if (!component.value("mesh").toString().isEmpty())
                lines << "    Mesh: " + component.value("mesh").toString();
            for (const QJsonValue &material : component.value("materials").toArray())
                lines << "    Material: " + material.toString();
        }
        ui->levelActorDetails->setPlainText(lines.join('\n'));
        return;
    }
    if (responseId == "capture_view" && connected) {
        captureTimeoutTimer->stop();
        capturePending = false;
        ui->levelCaptureButton->setEnabled(true);
        const QJsonObject result = data.value("result").toObject();
        const QString path = QDir::cleanPath(result.value("path").toString());
        const QString allowed = QDir::cleanPath(
            QDir(projectDirectory).filePath("Saved/UEMasterBridge")) + '/';
        if (projectDirectory.isEmpty() || !QDir::isAbsolutePath(path) ||
            !path.startsWith(allowed, Qt::CaseInsensitive)) {
            ui->levelPreviewInfo->setText(tr("A ponte devolveu um caminho de captura inválido."));
            addLog("Error", tr("Captura fora da pasta Saved/UEMasterBridge do projeto."));
            return;
        }
        QPixmap fresh;
        if (!fresh.load(path)) {
            ui->levelPreviewInfo->setText(tr("PNG não encontrado ou ilegível: %1").arg(path));
            return;
        }
        lastCapturePath = path;
        captureImage = fresh;
        ui->levelViewportPreview->setText(QString());
        ui->levelOpenCaptureButton->setEnabled(true);
        updateCapturePreview();
        ui->levelPreviewInfo->setText(tr("Cena capturada: %1 × %2 · %3")
            .arg(fresh.width()).arg(fresh.height()).arg(result.value("map").toString()));
        addLog("Action", tr("Captura da cena atualizada em %1").arg(path));
        return;
    }

    if (responseId == "play") {
        playTimeoutTimer->stop();
        playRequestPending = false;

        const QJsonObject result = data.value("result").toObject();
        const QString state = result.value("state").toString();
        if (state == "already_playing") {
            addLog("Action", tr("O Unreal Editor já está executando o jogo."));
        } else if (state == "already_requested") {
            addLog("Action", tr("O Play já estava aguardando inicialização no Unreal Editor."));
        } else if (state == "requested") {
            addLog("Action", tr("Play solicitado com sucesso; o Unreal Editor está iniciando o jogo."));
        } else {
            addLog("Error", tr("O plugin retornou uma resposta Play sem estado válido."));
        }
        return;
    }

    if (responseId != "status") return;
    statusTimeoutTimer->stop();
    const QJsonObject status = data.value("result").toObject();
    const QString name = status.value("project_name").toString();
    const QString directory = status.value("project_directory").toString();
    const QString engineDir = status.value("engine_directory").toString();
    const QString version = status.value("engine_version").toString();
    if (name.isEmpty() || directory.isEmpty() || engineDir.isEmpty() || version.isEmpty()) {
        incompatibleBridge = true;
        ui->connectionLabel->setText(tr("Status inválido"));
        addLog("Error", tr("Status incompleto recebido do Unreal."));
        return;
    }
    const QString reportedBridgeVersion = status.value("bridge_version").toString();
    const QVersionNumber bridgeVersion = QVersionNumber::fromString(reportedBridgeVersion);
    if (status.value("protocol_version").toInt(-1) != 1 ||
        !status.value("supports_play").toBool() ||
        !status.value("supports_actions").toBool() ||
        !status.value("supports_browsing").toBool() ||
        !status.value("supports_vision").toBool() ||
        !status.value("supports_scene_edit").toBool() ||
        !status.value("supports_scene_authoring").toBool() ||
        !status.value("supports_object_builder").toBool() ||
        !status.value("supports_blueprint_graph").toBool() ||
        !status.value("supports_character_builder").toBool() ||
        QVersionNumber::compare(bridgeVersion, QVersionNumber(0, 10, 0)) < 0) {
        incompatibleBridge = true;
        ui->connectionLabel->setText(tr("Plugin desatualizado"));
        addLog("Error", tr("Plugin incompatível (versão: %1). Instale a ponte 0.10.0 e reinicie o Unreal Editor.")
                   .arg(reportedBridgeVersion.isEmpty() ? tr("não informada") : reportedBridgeVersion));
        return;
    }
    const QString absoluteDirectory = QDir::cleanPath(directory);
    if (!QDir::isAbsolutePath(absoluteDirectory) || !QDir::isAbsolutePath(engineDir)) {
        incompatibleBridge = true;
        ui->connectionLabel->setText(tr("Status inválido"));
        addLog("Error", tr("O plugin retornou um caminho relativo. Reinstale a ponte 0.10.0."));
        return;
    }
    setConnected(true);
    heartbeatTimer->start();
    addLog("Bridge", tr("Conectado ao Unreal Editor; plugin %1 confirmado.").arg(reportedBridgeVersion));
    projectDirectory = absoluteDirectory;
    projectName = name;
    engineDirectory = QDir::cleanPath(engineDir);
    engineVersionText = version;
    bridgeVersionText = reportedBridgeVersion;
    ui->projectName->setText(name + ".uproject");
    ui->engineVersion->setText(version.section('-', 0, 0));
    ui->engineChip->setText("UE " + version.section('.', 0, 1));
    ui->connectionLabel->setText(tr("Connected to UE %1").arg(version.section('.', 0, 1)));
    updateProjectPath();
    updateSettings();
    addLog("Project", tr("Projeto aberto: %1.uproject").arg(name));
    if (ui->pageStack->currentWidget() == ui->assetsPage) refreshAssets();
    if (ui->pageStack->currentWidget() == ui->blueprintPage) refreshBlueprints();
    if (ui->pageStack->currentWidget() == ui->levelPage) { refreshLevel(); refreshMaps(); captureView(); }
}

void MainWindow::updateProjectPath()
{
    if (!ui || !ui->projectPath || projectDirectory.isEmpty()) return;
    ui->projectPath->setToolTip(projectDirectory);
    ui->projectPath->setText(QFontMetrics(ui->projectPath->font()).elidedText(
        QDir::toNativeSeparators(projectDirectory), Qt::ElideMiddle,
        qMax(90, ui->projectTextBlock->width() - 6)));
}

void MainWindow::addLog(const QString &category, const QString &message)
{
    const QString time = QDateTime::currentDateTime().toString("HH:mm:ss");
    logs.append({time, category, message});
    if (logs.size() > 500) logs.remove(0, logs.size() - 500);
    if (category == "Build" || (category == "Error" && buildProcess &&
                               buildProcess->state() != QProcess::NotRunning)) {
        ui->buildOutput->append(QString("[%1] [%2] %3").arg(time, category, message));
        ui->buildOutput->verticalScrollBar()->setValue(ui->buildOutput->verticalScrollBar()->maximum());
    }
    drawLog();
}

void MainWindow::drawLog()
{
    const auto render = [this](QTextEdit *output, const QString &filter) {
        QString html = "<html><body style='font-family:Consolas;font-size:10px;color:#c5d3e5;'>";
        int visible = 0;
        for (const LogEntry &entry : logs) {
            if (filter == "Connection" && entry.category != "Bridge" && entry.category != "Project") continue;
            if (filter == "Actions" && entry.category != "Action" && entry.category != "Build") continue;
            if (filter == "Errors" && entry.category != "Error") continue;
            ++visible;
            html += QString("<p style='white-space:pre;margin:1px 0;'>"
                            "<span style='color:#8290a9'>[%1]</span> &nbsp;"
                            "<span style='color:%2'>[%3]</span> &nbsp;%4</p>")
                        .arg(entry.time.toHtmlEscaped(), colorFor(entry.category),
                             entry.category.toHtmlEscaped(), entry.message.toHtmlEscaped());
        }
        html += "</body></html>";
        output->setHtml(html);
        output->verticalScrollBar()->setValue(output->verticalScrollBar()->maximum());
        return visible;
    };
    render(ui->consoleOutput, ui->logFilter->currentText());
    const int count = render(ui->logsOutput, ui->logsFilter->currentText());
    ui->logsCount->setText(tr("%1 eventos exibidos · %2 no histórico")
        .arg(count).arg(logs.size()));
}
