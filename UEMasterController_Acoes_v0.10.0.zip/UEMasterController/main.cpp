#include "mainwindow.h"

#include <QApplication>
#include <QFile>
#include <QIcon>
#include <QMessageBox>
#include <QtResource>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Q_INIT_RESOURCE(resources);
    if (!QFile::exists(":/icons/unreal.png")) {
        QMessageBox::critical(nullptr, "UE Master Controller",
                              "Os ícones não foram incorporados ao executável. Reconfigure o projeto CMake e compile novamente.");
        return 1;
    }
    a.setStyle("Fusion");
    a.setApplicationDisplayName("UE Master Controller");
    a.setWindowIcon(QIcon(":/icons/unreal.png"));
    MainWindow w;
    w.show();
    return QApplication::exec();
}
