# UE Master Controller — interface Qt 6

Este projeto é a interface desktop baseada na imagem fornecida. A tela principal está no arquivo **`mainwindow.ui`**, editável no Qt Designer do Qt Creator. Os ícones estão em `icons/` e são incorporados ao executável por `resources.qrc`.

## Abrir e executar

1. Extraia o ZIP inteiro.
2. No Qt Creator, abra `UEMasterController/CMakeLists.txt` como projeto.
3. Selecione **Desktop Qt 6.11.2 MinGW 64-bit**, ou outro kit Qt 6.5+ que tenha os módulos **Widgets** e **Network**.
4. Instale e compile a ponte **UE Master Bridge 0.10.0** com o BAT do outro ZIP. Reinicie o Unreal Editor e abra o projeto.
5. Compile e execute o Qt com **Ctrl+R**.

O aplicativo se conecta automaticamente a `127.0.0.1:17777`. Ele tenta novamente quando o Editor ainda não estiver aberto. Antes de habilitar as ações, espera a resposta de `status` e confere o protocolo, a versão 0.10.0 e `supports_character_builder` do plugin. Após a confirmação, mostra projeto, caminho absoluto e versão do Engine. O botão de pasta abre o diretório do projeto. O console mostra resultados e erros reais; **Clear** e o filtro funcionam. Minimizar, fechar e fixar a janela também funcionam.

Os seis cartões mantêm o visual da referência na janela de 722 × 620 pixels:

- **Import Asset**: escolha até 16 arquivos FBX, OBJ, GLB ou GLTF. O Editor importa para `/Game/Imported`; importadores de formatos opcionais devem estar ativados no projeto. O resultado mostra quantos assets foram importados, inclusive se houve falha parcial.
- **Create Blueprint**: escolha Actor, Pawn ou Character e informe um nome. Cria, compila e salva o Blueprint em `/Game/Blueprints` sem sobrescrever outro asset.
- **Add Third-Person Camera**: informe o caminho `/Game/.../BP_Player` de um Blueprint Pawn/Character. Adiciona `UEMasterCameraBoom` (Spring Arm) e `UEMasterFollowCamera`, compila e salva. Se você acabou de criar o Blueprint pelo aplicativo, o caminho é preenchido automaticamente. O Blueprint precisa ser usado como Pawn do jogo para aparecer no Play.
- **Compile**: compila Blueprints **alterados e carregados** no Editor; mostra contagem de avisos/erros. Se todos foram salvos, retorna zero. Não salva automaticamente outras edições feitas pelo usuário.
- **Play**: preserva a sessão PIE existente e informa se foi solicitada, já estava solicitada ou executando.
- **Build Android**: peça uma pasta de saída; o Qt executa `RunUAT.bat BuildCookRun` da instalação informada pelo Editor e transmite o progresso ao console. O cartão usa a configuração escolhida na página Build (Development por padrão). Projeto e conteúdo devem estar salvos. Configure Android SDK/NDK e aceite as licenças no Unreal antes de empacotar; o comando falha com a saída do UAT se o ambiente não estiver pronto.

## Páginas laterais

- **Assets**: mostra arquivos `.uasset` salvos em `Content`, filtra por nome e pasta e permite importar arquivos ou abrir Content. O menu **Organizar assets** cria pastas e duplica ou move o asset selecionado usando a API do Unreal (caminhos `/Game/...`, sem substituir destino existente). Clique duplo abre a pasta do asset no Explorer; assets não salvos no disco não aparecem.
- **Blueprint**: lista e busca Blueprints registrados no Editor, inclusive os não carregados; selecionar um Blueprint preenche o caminho da ação Câmera. Botões Criar, Compilar e Câmera usam a ponte. No menu **Objeto**, **Criar objeto com componentes** abre um JSON preenchido com o modelo de baú (mesh, caixa de colisão, ponto de interação e três variáveis), e **Inspecionar objeto selecionado** mostra a estrutura retornada pelo Editor no console. O menu **Grafo** cria e consulta eventos. O menu **Personagem** cria um Character com malha esquelética existente opcional e câmera, e consulta malha, cápsula e movimento. Os Blueprints criados podem ser inseridos como Actors na página Level.
- **Level**: mantém as abas **Visão** (PNG da câmera do viewport), **Actors** (páginas de 20, inspeção de transform, componentes, meshes, materiais e colisão) e **Mapas** (arquivos `.umap` salvos em Content). Cria, abre e salva mapas; insere Actor, altera transform/mesh/material e permite renomear, duplicar, excluir, anexar e editar propriedades ou componentes em **Editar Actor**. O menu **Cena** monta até 32 Actors de um JSON estruturado e aciona Undo/Redo do Editor. **Enquadrar Actor** atualiza o viewport.
- **Build**: empacota para Windows (Win64) ou Android, com configurações Development ou Shipping. O Qt pede a pasta de saída e exibe a saída do RunUAT em tempo real; nenhum APK/EXE é gerado até o RunUAT finalizar com sucesso.
- **Logs**: histórico filtrável, limpar e exportar `.log`. Os filtros do painel Project e desta página são independentes.
- **Settings**: mostra a conexão local, caminhos absolutos do projeto e do Engine, versão da ponte e botões para reconectar e abrir a pasta do projeto.

As listas de Assets e mapas são atualizadas ao entrar na página; as listas de Blueprints e Actors consultam o Editor ao entrar na página ou ao clicar em Atualizar. Blueprints mostram até 120 por consulta; Actors têm páginas de 20 com contagem total. A busca da página Blueprint roda no próprio Editor. Ao entrar na página Level, o Qt solicita uma captura; **Capturar cena** renova a imagem, e **Abrir PNG** mostra o arquivo inteiro. A captura também funciona com a janela do Editor minimizada quando o Editor continua processando a renderização e a câmera do nível está disponível. A ponte salva a imagem em `Saved/UEMasterBridge/scene_latest.png` no projeto; cada nova captura substitui a anterior.

A captura mostra a **cena do nível aberto**, sem gizmos e painéis do Editor; durante Play ela continua lendo o mundo de edição, não a câmera do jogador em PIE. Para testar as respostas da ponte sem o Qt, feche o aplicativo e execute `testar_visao.bat` no kit do plugin. Esse kit ainda não contém um planejador de IA: oferece observações reais e estruturadas para a próxima etapa de automação.

As ações de edição exigem o Editor aberto e fora do Play. O empacotamento requer um projeto conectado no início para obter o caminho correto do Engine. Aguarde a conclusão de um comando antes de iniciar outro. O resultado de cada operação aparece no console; importar muitos assets pode ocupar a thread do Editor durante a execução.

## Primeiro teste da edição de cena

1. Atualize o plugin usando `compilar_instalar_ue58.bat` do novo ZIP, reinicie o Editor e execute o Qt recompilado em um diretório de build novo.
2. Na página **Level**, clique **Montar sala**, escolha um nome ainda livre (como `L_SalaTeste_1`) e veja o `.umap` aparecer em **Mapas**. A operação só acontece se os mapas anteriores estiverem salvos.
3. Em **Actors**, selecione um bloco e use **Transform**, **Mesh**, **Material** ou **Editar Actor**. Atribua um asset existente e clique **Salvar mapa** após editar. **Inserir Actor** aceita StaticMesh, SkeletalMesh, PointLight, SpotLight, DirectionalLight, Camera, TriggerBox, Character, DefaultPawn, PlayerStart e Blueprint.
4. Ajuste o enquadramento da câmera do viewport se necessário, clique **Capturar cena** em **Visão** e depois **Play**. O DefaultPawn criado na sala está configurado para Player 0; as regras de GameMode do projeto ainda podem mudar qual Pawn é possuído.

Os nomes de mapa são criados em `/Game/UE_Master_Maps/` e jamais sobrescrevem um mapa existente. **Abrir mapa selecionado** em Mapas troca o mapa aberto depois de verificar que não há alterações não salvas. A ponte 0.10.0 mantém os comandos TCP anteriores e acrescenta a criação e a inspeção de Character Blueprints. Esta versão ainda não executa prompts com IA.

No menu **Cena > Montar cena**, edite o exemplo de JSON e insira até 32 Actors no mapa aberto. A ponte valida os tipos, transforms e caminhos de mesh antes da primeira inserção. Em seguida, use **Visão > Capturar cena**, ajuste em **Actors** e salve. Para testar os novos comandos de ponta a ponta sem o Controller, feche o Qt e execute `python testar_autoria.py --write` do kit do plugin em um projeto de teste.

Para testar o **Object Builder**, feche o Controller e execute `python testar_objetos.py --write` do kit em um projeto de teste com o mapa atual salvo. O script cria um Blueprint com nome único em `/Game/Objects`, inspeciona seus componentes e variáveis, insere uma instância em um novo mapa e salva o mapa. Ao terminar, abra o Blueprint e o mapa no Unreal. O teste exige a ponte 0.10.0 recompilada e o Editor reiniciado. A fase 3 prepara dados do objeto; comportamento de interação e geração de loot exige grafos Blueprint adicionais.

Para a fase 4, abra **Blueprint > Grafo** e selecione **Criar evento e lógica**. O JSON do diálogo traz `OpenChest` como exemplo: se `IsOpen` for falso, muda a variável para verdadeiro e mostra uma mensagem. Use um Blueprint salvo com a variável `IsOpen` ou ajuste o JSON para as variáveis existentes. **Inspecionar evento** apresenta os nós, pins e conexões no console. Com o Controller fechado, execute `python testar_grafos.py --write` no kit para criar e verificar um Blueprint novo de teste. A criação do evento não liga o evento ao collider ou ao input automaticamente; veja o LEIA-ME do plugin para o contrato exato.

Para a fase 5, abra **Blueprint > Personagem > Criar Character**, ajuste `name` e o caminho `skeletal_mesh_path` no JSON (uma Skeletal Mesh já importada), ou remova `skeletal_mesh_path` e `mesh_location` para criar somente a estrutura. O novo Blueprint vai para `/Game/Characters`; use **Inspecionar Character** para ler malha, cápsula, câmera e defaults de movimento. Sem o Controller aberto, rode `python testar_personagens.py --write` no kit; acrescente `--mesh /Game/Caminho/Malha` para verificar também um modelo existente. A ação não cria animações nem configura comandos de entrada do jogador.

Se o console mostrar `TCP conectado; aguardando status` e não confirmar o plugin, confira `LogUEMasterBridge` no **Output Log** do Unreal. Para rodar `testar_play.bat` ou `testar_conexao.bat`, feche o aplicativo Qt antes; o plugin permite um cliente por vez.

## Arquivos principais

- `mainwindow.ui`: composição visual e estilo, visível no Qt Designer.
- `mainwindow.cpp` e `mainwindow.h`: conexão TCP, leitura de JSON, navegação e interações.
- `resources.qrc` e `icons/`: 20 ícones incorporados ao executável com `qt_add_resources`.
- `CMakeLists.txt`: configuração Qt Widgets + Qt Network.

Se o projeto tiver sido aberto anteriormente pelo Qt Creator, aceite a configuração de um **novo diretório de build**. O pacote não contém caches nem um executável desatualizado da máquina anterior.

## Atualização após erros de compilação do `mainwindow.ui`

Se você instalou uma versão anterior, extraia este ZIP em uma pasta nova e abra o `CMakeLists.txt` dessa pasta. Configure um diretório de build novo e use **Build > Rebuild All** no Qt Creator. Assim o `ui_mainwindow.h` será gerado a partir do `mainwindow.ui` corrigido, sem reaproveitar arquivos do build anterior.

O projeto não usa mais propriedades `selected` em `QPushButton` nem `role` em `QLabel` no arquivo `.ui`. Esses nomes faziam o `uic` gerar chamadas inválidas a `setSelected()` e `setRole()`. A navegação agora usa as propriedades nativas `checkable` e `checked` dos botões; os estilos dos títulos usam os nomes dos objetos.

Se a versão anterior abriu sem ícones, apague o diretório de build antigo ou configure um novo no Qt Creator. Esta versão compila o arquivo `resources.qrc` explicitamente; se os recursos não estiverem presentes no executável, a inicialização mostrará uma mensagem de erro em vez de abrir a janela sem ícones.
