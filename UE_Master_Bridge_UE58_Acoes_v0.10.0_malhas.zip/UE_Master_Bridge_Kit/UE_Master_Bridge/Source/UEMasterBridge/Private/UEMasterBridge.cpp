#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"

#include "Containers/Ticker.h"
#include "Containers/StringConv.h"
#include "AssetImportTask.h"
#include "AssetRegistry/ARFilter.h"
#include "AssetRegistry/AssetData.h"
#include "AssetRegistry/AssetRegistryHelpers.h"
#include "AssetRegistry/AssetRegistryModule.h"
#include "AssetRegistry/IAssetRegistry.h"
#include "AssetToolsModule.h"
#include "Camera/CameraComponent.h"
#include "Camera/CameraActor.h"
#include "Components/MeshComponent.h"
#include "Components/BoxComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/PrimitiveComponent.h"
#include "Components/SceneCaptureComponent2D.h"
#include "Components/SceneComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/PointLightComponent.h"
#include "Dom/JsonObject.h"
#include "EdGraph/EdGraph.h"
#include "EdGraph/EdGraphPin.h"
#include "EdGraphSchema_K2.h"
#include "Editor.h"
#include "Editor/EditorEngine.h"
#include "Engine/Blueprint.h"
#include "Engine/DirectionalLight.h"
#include "Engine/PointLight.h"
#include "Engine/SkeletalMesh.h"
#include "Engine/StaticMesh.h"
#include "Engine/StaticMeshActor.h"
#include "Animation/SkeletalMeshActor.h"
#include "Engine/SpotLight.h"
#include "Engine/TriggerBox.h"
#include "Engine/TextureRenderTarget2D.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "Engine/SCS_Node.h"
#include "Engine/SimpleConstructionScript.h"
#include "Factories/BlueprintFactory.h"
#include "FileHelpers.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/DefaultPawn.h"
#include "GameFramework/Pawn.h"
#include "GameFramework/PlayerStart.h"
#include "GameFramework/SpringArmComponent.h"
#include "IAssetTools.h"
#include "Interfaces/IPv4/IPv4Endpoint.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "K2Node_CallFunction.h"
#include "K2Node_CustomEvent.h"
#include "K2Node_IfThenElse.h"
#include "K2Node_VariableGet.h"
#include "K2Node_VariableSet.h"
#include "BlueprintEditorLibrary.h"
#include "Kismet2/CompilerResultsLog.h"
#include "Kismet2/KismetEditorUtilities.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Materials/MaterialInterface.h"
#include "Math/RotationMatrix.h"
#include "Misc/App.h"
#include "Misc/EngineVersion.h"
#include "HAL/FileManager.h"
#include "ImageUtils.h"
#include "Misc/DateTime.h"
#include "Misc/FileHelper.h"
#include "Misc/PackageName.h"
#include "Misc/Paths.h"
#include "ScopedTransaction.h"
#include "PlayInEditorDataTypes.h"
#include "Policies/CondensedJsonPrintPolicy.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"
#include "Serialization/JsonWriter.h"
#include "SocketSubsystem.h"
#include "Sockets.h"
#include "Subsystems/UnrealEditorSubsystem.h"
#include "Subsystems/EditorActorSubsystem.h"
#include "Subsystems/EditorAssetSubsystem.h"
#include "UObject/StrongObjectPtr.h"
#include "UObject/Package.h"
#include "UObject/UnrealType.h"
#include "UObject/UObjectIterator.h"

DEFINE_LOG_CATEGORY_STATIC(LogUEMasterBridge, Log, All);

namespace UEMasterBridge
{
    constexpr uint16 Port = 17777;
    constexpr int32 MaxRequestBytes = 64 * 1024;
    constexpr int32 MaxQueuedBytes = 256 * 1024;
    constexpr int32 MaxRequestsPerTick = 32;
    constexpr int32 MaxReadChunksPerTick = 8;

    bool IsProjectContentPath(const FString& Path)
    {
        return Path.StartsWith(TEXT("/Game/")) &&
            FPackageName::IsValidLongPackageName(Path);
    }

    bool IsContentFolder(const FString& Path)
    {
        if (!Path.StartsWith(TEXT("/Game/")) || Path.Len() > 256 ||
            Path.EndsWith(TEXT("/")) || Path.Contains(TEXT(".")) ||
            Path.Contains(TEXT("\\")) || Path.Contains(TEXT("//"))) return false;
        const FString TestPackage = Path + TEXT("/BridgePathCheck");
        return FPackageName::IsValidLongPackageName(TestPackage);
    }

    bool IsWritableAsset(const FString& Path)
    {
        return Path.Len() <= 512 && !Path.Contains(TEXT(".")) &&
            IsProjectContentPath(Path);
    }

    bool ReadActorLabel(const TSharedPtr<FJsonObject>& Request, FString& Label, FString& Error)
    {
        if (Request->HasField(TEXT("label")) &&
            (!Request->TryGetStringField(TEXT("label"), Label) || Label.Len() > 80 ||
             Label.Contains(TEXT("\n")) || Label.Contains(TEXT("\r"))))
        {
            Error = TEXT("label deve ser texto com ate 80 caracteres.");
            return false;
        }
        return true;
    }

    bool IsAssetPath(const FString& Path, bool bAllowEngine = true)
    {
        if (Path.IsEmpty() || Path.Len() > 512) return false;
        FString Package = Path;
        FString ObjectName;
        if (Path.Split(TEXT("."), &Package, &ObjectName) &&
            (ObjectName.IsEmpty() || ObjectName.Contains(TEXT("/")))) return false;
        return (IsProjectContentPath(Package) ||
            (bAllowEngine && Package.StartsWith(TEXT("/Engine/")) &&
             FPackageName::IsValidLongPackageName(Package)));
    }

    FString ObjectPath(const FString& Path)
    {
        if (Path.Contains(TEXT("."))) return Path;
        return Path + TEXT(".") + FPackageName::GetLongPackageAssetName(Path);
    }

    bool ReadNumber(const TSharedPtr<FJsonObject>& Json, const TCHAR* Key,
                    double& Value, double Minimum, double Maximum)
    {
        return Json.IsValid() && Json->TryGetNumberField(Key, Value) &&
            FMath::IsFinite(Value) && Value >= Minimum && Value <= Maximum;
    }

    bool IsIdentifier(const FString& Value)
    {
        if (Value.IsEmpty() || Value.Len() > 64 ||
            Value.Equals(TEXT("None"), ESearchCase::IgnoreCase)) return false;
        const auto Letter = [](TCHAR C) {
            return (C >= TEXT('a') && C <= TEXT('z')) ||
                   (C >= TEXT('A') && C <= TEXT('Z'));
        };
        if (!Letter(Value[0])) return false;
        for (TCHAR C : Value)
            if (!Letter(C) && (C < TEXT('0') || C > TEXT('9')) && C != TEXT('_'))
                return false;
        return true;
    }

    bool ReadVector3(const TSharedPtr<FJsonObject>& Json, FVector& Out,
                     double Minimum, double Maximum)
    {
        double X = 0, Y = 0, Z = 0;
        if (!Json.IsValid() || Json->Values.Num() != 3 ||
            !ReadNumber(Json, TEXT("x"), X, Minimum, Maximum) ||
            !ReadNumber(Json, TEXT("y"), Y, Minimum, Maximum) ||
            !ReadNumber(Json, TEXT("z"), Z, Minimum, Maximum)) return false;
        Out = FVector(X, Y, Z);
        return true;
    }

    bool ReadTransform(const TSharedPtr<FJsonObject>& Request, FTransform& Out, FString& Error)
    {
        const TSharedPtr<FJsonObject>* Transform = nullptr;
        const TSharedPtr<FJsonObject>* Location = nullptr;
        const TSharedPtr<FJsonObject>* Rotation = nullptr;
        const TSharedPtr<FJsonObject>* Scale = nullptr;
        if (!Request->TryGetObjectField(TEXT("transform"), Transform) || !Transform ||
            !(*Transform)->TryGetObjectField(TEXT("location"), Location) ||
            !(*Transform)->TryGetObjectField(TEXT("rotation"), Rotation) ||
            !(*Transform)->TryGetObjectField(TEXT("scale"), Scale))
        {
            Error = TEXT("transform deve conter location{x,y,z}, rotation{pitch,yaw,roll} e scale{x,y,z}.");
            return false;
        }
        double X, Y, Z, Pitch, Yaw, Roll, SX, SY, SZ;
        if (!ReadNumber(*Location, TEXT("x"), X, -1000000, 1000000) ||
            !ReadNumber(*Location, TEXT("y"), Y, -1000000, 1000000) ||
            !ReadNumber(*Location, TEXT("z"), Z, -1000000, 1000000) ||
            !ReadNumber(*Rotation, TEXT("pitch"), Pitch, -3600, 3600) ||
            !ReadNumber(*Rotation, TEXT("yaw"), Yaw, -3600, 3600) ||
            !ReadNumber(*Rotation, TEXT("roll"), Roll, -3600, 3600) ||
            !ReadNumber(*Scale, TEXT("x"), SX, 0.001, 10000) ||
            !ReadNumber(*Scale, TEXT("y"), SY, 0.001, 10000) ||
            !ReadNumber(*Scale, TEXT("z"), SZ, 0.001, 10000))
        {
            Error = TEXT("Transform invalido: coordenadas devem ser finitas e a escala positiva.");
            return false;
        }
        Out = FTransform(FRotator(Pitch, Yaw, Roll), FVector(X, Y, Z), FVector(SX, SY, SZ));
        return true;
    }

    bool MapName(const TSharedPtr<FJsonObject>& Request, FString& Package, FString& Error)
    {
        FString Name;
        const auto IsLetter = [](TCHAR C) {
            return (C >= TEXT('A') && C <= TEXT('Z')) ||
                   (C >= TEXT('a') && C <= TEXT('z'));
        };
        if (!Request->TryGetStringField(TEXT("name"), Name) || Name.IsEmpty() ||
            Name.Len() > 64 || !IsLetter(Name[0]))
        {
            Error = TEXT("Informe name com 1 a 64 caracteres, comecando por letra.");
            return false;
        }
        for (const TCHAR C : Name)
        {
            if (!IsLetter(C) && (C < TEXT('0') || C > TEXT('9')) && C != TEXT('_'))
            {
                Error = TEXT("O nome do mapa aceita apenas letras, numeros e underscore.");
                return false;
            }
        }
        Package = TEXT("/Game/UE_Master_Maps/") + Name;
        FString Filename;
        if (!FPackageName::TryConvertLongPackageNameToFilename(
                Package, Filename, FPackageName::GetMapPackageExtension()) ||
            IFileManager::Get().FileExists(*Filename) ||
            FPackageName::DoesPackageExist(Package, nullptr, false))
        {
            Error = TEXT("Nome de mapa ja existente ou caminho de destino invalido.");
            return false;
        }
        return true;
    }

    bool CanChangeMap(FString& Error)
    {
        TArray<UPackage*> DirtyMaps;
        UEditorLoadingAndSavingUtils::GetDirtyMapPackages(DirtyMaps);
        UWorld* World = GEditor ? GEditor->GetEditorWorldContext().World() : nullptr;
        bool bUnsavedActors = World && World->GetOutermost()->IsDirty();
        if (World && !bUnsavedActors)
            for (TActorIterator<AActor> It(World); It; ++It)
                if (It->GetPackage()->IsDirty()) { bUnsavedActors = true; break; }
        if (!DirtyMaps.IsEmpty() || bUnsavedActors)
        {
            Error = TEXT("Ha alteracoes nao salvas em mapas do Editor. Salve-as antes de trocar de nivel.");
            return false;
        }
        return true;
    }

    bool SaveAsset(UObject* Asset, FString& Error)
    {
        if (!Asset)
        {
            Error = TEXT("Asset invalido.");
            return false;
        }
        TArray<UPackage*> PackagesToSave;
        PackagesToSave.Add(Asset->GetOutermost());
        if (!UEditorLoadingAndSavingUtils::SavePackages(PackagesToSave, false))
        {
            Error = TEXT("O asset foi criado ou alterado, mas nao foi possivel grava-lo no disco.");
            return false;
        }
        return true;
    }

    TSharedRef<FJsonObject> VectorJson(const FVector& Value)
    {
        const TSharedRef<FJsonObject> Json = MakeShared<FJsonObject>();
        Json->SetNumberField(TEXT("x"), Value.X);
        Json->SetNumberField(TEXT("y"), Value.Y);
        Json->SetNumberField(TEXT("z"), Value.Z);
        return Json;
    }

    TSharedRef<FJsonObject> TransformJson(const FTransform& Value)
    {
        const TSharedRef<FJsonObject> Json = MakeShared<FJsonObject>();
        Json->SetObjectField(TEXT("location"), VectorJson(Value.GetLocation()));
        const FRotator Rotation = Value.Rotator();
        const TSharedRef<FJsonObject> RotationJson = MakeShared<FJsonObject>();
        RotationJson->SetNumberField(TEXT("pitch"), Rotation.Pitch);
        RotationJson->SetNumberField(TEXT("yaw"), Rotation.Yaw);
        RotationJson->SetNumberField(TEXT("roll"), Rotation.Roll);
        Json->SetObjectField(TEXT("rotation"), RotationJson);
        Json->SetObjectField(TEXT("scale"), VectorJson(Value.GetScale3D()));
        return Json;
    }

    TSharedRef<FJsonObject> ActorSummary(const AActor* Actor)
    {
        const TSharedRef<FJsonObject> Json = MakeShared<FJsonObject>();
        Json->SetStringField(TEXT("path"), Actor->GetPathName());
        Json->SetStringField(TEXT("label"), Actor->GetActorLabel().Left(200));
        Json->SetStringField(TEXT("class"), Actor->GetClass()->GetName());
        Json->SetStringField(TEXT("guid"), Actor->GetActorGuid().ToString());
        Json->SetObjectField(TEXT("transform"), TransformJson(Actor->GetActorTransform()));
        return Json;
    }

    int32 JsonBytes(const TSharedRef<FJsonObject>& Object)
    {
        FString Text;
        const TSharedRef<TJsonWriter<TCHAR, TCondensedJsonPrintPolicy<TCHAR>>> Writer =
            TJsonWriterFactory<TCHAR, TCondensedJsonPrintPolicy<TCHAR>>::Create(&Text);
        if (!FJsonSerializer::Serialize(Object, Writer)) return MaxRequestBytes;
        return FTCHARToUTF8(*Text).Length();
    }
}

class FUEMasterBridgeModule final : public IModuleInterface
{
public:
    virtual void StartupModule() override
    {
        // No listener is needed when UAT launches the editor as a commandlet.
        if (IsRunningCommandlet())
        {
            return;
        }

        SocketSubsystem = ISocketSubsystem::Get(PLATFORM_SOCKETSUBSYSTEM);
        if (!SocketSubsystem)
        {
            UE_LOG(LogUEMasterBridge, Error, TEXT("Socket subsystem unavailable."));
            return;
        }

        ListenSocket = SocketSubsystem->CreateSocket(NAME_Stream, TEXT("UE Master Bridge Listener"), false);
        if (!ListenSocket)
        {
            UE_LOG(LogUEMasterBridge, Error, TEXT("Could not create the TCP socket."));
            return;
        }

        const TSharedRef<FInternetAddr> Address =
            FIPv4Endpoint(FIPv4Address(127, 0, 0, 1), UEMasterBridge::Port).ToInternetAddr();

        if (!ListenSocket->Bind(*Address) || !ListenSocket->Listen(1) || !ListenSocket->SetNonBlocking(true))
        {
            UE_LOG(LogUEMasterBridge, Error,
                TEXT("Could not listen on 127.0.0.1:%u (port busy or socket error)."),
                UEMasterBridge::Port);
            CloseSocket(ListenSocket);
            return;
        }

        TickHandle = FTSTicker::GetCoreTicker().AddTicker(
            FTickerDelegate::CreateRaw(this, &FUEMasterBridgeModule::Tick), 0.05f);

        UE_LOG(LogUEMasterBridge, Display,
            TEXT("Listening on 127.0.0.1:%u; project: %s"),
            UEMasterBridge::Port, FApp::GetProjectName());
    }

    virtual void ShutdownModule() override
    {
        if (TickHandle.IsValid())
        {
            FTSTicker::GetCoreTicker().RemoveTicker(TickHandle);
            TickHandle.Reset();
        }

        CloseClient();
        CloseSocket(ListenSocket);
        SocketSubsystem = nullptr;
    }

private:
    UWorld* EditorWorld(FString& Error) const
    {
        UWorld* World = GEditor ? GEditor->GetEditorWorldContext().World() : nullptr;
        if (!World || World->WorldType != EWorldType::Editor)
            Error = TEXT("Nenhum mundo de edicao esta aberto.");
        return World && World->WorldType == EWorldType::Editor ? World : nullptr;
    }

    AActor* FindActor(const TSharedPtr<FJsonObject>& Request, FString& Error) const
    {
        FString Path;
        if (!Request->TryGetStringField(TEXT("actor_path"), Path) ||
            Path.IsEmpty() || Path.Len() > 1024)
        {
            Error = TEXT("Informe actor_path recebido de get_scene_snapshot.");
            return nullptr;
        }
        UWorld* World = EditorWorld(Error);
        if (!World) return nullptr;
        for (TActorIterator<AActor> It(World); It; ++It)
            if (It->GetPathName() == Path) return *It;
        Error = TEXT("Actor nao encontrado no mapa aberto. Atualize a lista.");
        return nullptr;
    }

    UClass* ResolveSpawnClass(const TSharedPtr<FJsonObject>& Request, FString& Error) const
    {
        FString Kind;
        if (!Request->TryGetStringField(TEXT("kind"), Kind))
        {
            Error = TEXT("Informe kind: StaticMesh, SkeletalMesh, PointLight, SpotLight, DirectionalLight, Camera, TriggerBox, Character, DefaultPawn, PlayerStart ou Blueprint.");
            return nullptr;
        }
        if (Kind == TEXT("StaticMesh")) return AStaticMeshActor::StaticClass();
        if (Kind == TEXT("SkeletalMesh")) return ASkeletalMeshActor::StaticClass();
        if (Kind == TEXT("PointLight")) return APointLight::StaticClass();
        if (Kind == TEXT("SpotLight")) return ASpotLight::StaticClass();
        if (Kind == TEXT("DirectionalLight")) return ADirectionalLight::StaticClass();
        if (Kind == TEXT("Camera")) return ACameraActor::StaticClass();
        if (Kind == TEXT("TriggerBox")) return ATriggerBox::StaticClass();
        if (Kind == TEXT("Character")) return ACharacter::StaticClass();
        if (Kind == TEXT("DefaultPawn")) return ADefaultPawn::StaticClass();
        if (Kind == TEXT("PlayerStart")) return APlayerStart::StaticClass();
        if (Kind != TEXT("Blueprint"))
        {
            Error = TEXT("kind nao permitido. Use uma classe conhecida ou um Blueprint em /Game/.");
            return nullptr;
        }
        FString Path;
        if (!Request->TryGetStringField(TEXT("blueprint_path"), Path) ||
            !UEMasterBridge::IsAssetPath(Path, false))
        {
            Error = TEXT("blueprint_path deve apontar para um Blueprint em /Game/.");
            return nullptr;
        }
        UBlueprint* Blueprint = LoadObject<UBlueprint>(nullptr, *UEMasterBridge::ObjectPath(Path));
        UClass* Class = Blueprint ? Blueprint->GeneratedClass : nullptr;
        if (!Class || !Class->IsChildOf(AActor::StaticClass()) ||
            Class->HasAnyClassFlags(CLASS_Abstract | CLASS_Deprecated))
        {
            Error = TEXT("Blueprint nao encontrado, nao compilado ou nao derivado de Actor.");
            return nullptr;
        }
        return Class;
    }

    AActor* PlaceActor(UClass* Class, const FTransform& Transform, const FString& Label,
                       UStaticMesh* StaticMesh, bool bAutoPossess, FString& Error,
                       USkeletalMesh* SkeletalMesh = nullptr)
    {
        UEditorActorSubsystem* Actors = GEditor
            ? GEditor->GetEditorSubsystem<UEditorActorSubsystem>() : nullptr;
        if (!Actors)
        {
            Error = TEXT("EditorActorSubsystem indisponivel.");
            return nullptr;
        }
        AActor* Actor = Actors->SpawnActorFromClass(Class, Transform.GetLocation(),
                                                    Transform.Rotator(), false);
        if (!Actor)
        {
            Error = TEXT("O Editor nao conseguiu inserir o Actor no nivel.");
            return nullptr;
        }
        Actor->Modify();
        Actor->SetActorScale3D(Transform.GetScale3D());
        if (!Label.IsEmpty()) Actor->SetActorLabel(Label, true);
        if (AStaticMeshActor* Static = Cast<AStaticMeshActor>(Actor))
        {
            UStaticMeshComponent* Component = Static->GetStaticMeshComponent();
            if (Component && StaticMesh)
            {
                Component->Modify();
                Component->SetStaticMesh(StaticMesh);
            }
        }
        if (ASkeletalMeshActor* Skeletal = Cast<ASkeletalMeshActor>(Actor))
        {
            USkeletalMeshComponent* Component = Skeletal->GetSkeletalMeshComponent();
            if (Component && SkeletalMesh)
            {
                Component->Modify();
                Component->SetSkeletalMeshAsset(SkeletalMesh);
            }
        }
        if (bAutoPossess)
            if (APawn* Pawn = Cast<APawn>(Actor))
                Pawn->AutoPossessPlayer = EAutoReceiveInput::Player0;
        Actor->MarkPackageDirty();
        return Actor;
    }

    UWorld* BeginNewLevel(const TSharedPtr<FJsonObject>& Request,
                          FString& Package, FString& Error)
    {
        if (!UEMasterBridge::MapName(Request, Package, Error) ||
            !UEMasterBridge::CanChangeMap(Error)) return nullptr;
        UWorld* World = UEditorLoadingAndSavingUtils::NewBlankMap(false);
        if (!World) Error = TEXT("Falha ao abrir um nivel vazio no Editor.");
        return World;
    }

    bool CreateLevel(const TSharedPtr<FJsonObject>& Request,
                     const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        FString Package;
        UWorld* World = BeginNewLevel(Request, Package, Error);
        if (!World) return false;
        if (!UEditorLoadingAndSavingUtils::SaveMap(World, Package))
        {
            Error = TEXT("Nivel vazio aberto, mas falhou ao salvar o novo mapa.");
            return false;
        }
        Result->SetStringField(TEXT("map"), Package);
        return true;
    }

    bool OpenLevel(const TSharedPtr<FJsonObject>& Request,
                   const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        FString Package;
        if (!Request->TryGetStringField(TEXT("map"), Package) ||
            !UEMasterBridge::IsProjectContentPath(Package))
        {
            Error = TEXT("Informe map como pacote /Game/... de um mapa salvo.");
            return false;
        }
        FString Filename;
        if (!FPackageName::TryConvertLongPackageNameToFilename(
                Package, Filename, FPackageName::GetMapPackageExtension()) ||
            !IFileManager::Get().FileExists(*Filename))
        {
            Error = TEXT("Arquivo .umap nao encontrado no Content do projeto.");
            return false;
        }
        if (!UEMasterBridge::CanChangeMap(Error)) return false;
        UWorld* World = UEditorLoadingAndSavingUtils::LoadMap(Package);
        if (!World)
        {
            Error = TEXT("O Editor nao conseguiu abrir esse mapa.");
            return false;
        }
        Result->SetStringField(TEXT("map"), World->GetOutermost()->GetName());
        return true;
    }

    bool SaveLevel(const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        UWorld* World = EditorWorld(Error);
        if (!World) return false;
        const FString Package = World->GetOutermost()->GetName();
        if (!UEMasterBridge::IsProjectContentPath(Package))
        {
            Error = TEXT("Nivel sem nome. Use Criar mapa antes de salvar.");
            return false;
        }
        if (!UEditorLoadingAndSavingUtils::SaveMap(World, Package))
        {
            Error = TEXT("Falha ao salvar o mapa. Verifique permissoes e controle de versao.");
            return false;
        }
        Result->SetStringField(TEXT("map"), Package);
        return true;
    }

    bool SpawnActor(const TSharedPtr<FJsonObject>& Request,
                    const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        if (!EditorWorld(Error)) return false;
        FTransform Transform;
        if (!UEMasterBridge::ReadTransform(Request, Transform, Error)) return false;
        UClass* Class = ResolveSpawnClass(Request, Error);
        if (!Class) return false;
        FString Label;
        if (Request->HasField(TEXT("label")) &&
            (!Request->TryGetStringField(TEXT("label"), Label) || Label.Len() > 80))
        {
            Error = TEXT("label deve ser texto com ate 80 caracteres.");
            return false;
        }
        UStaticMesh* Mesh = nullptr;
        USkeletalMesh* SkeletalMesh = nullptr;
        if (Class == AStaticMeshActor::StaticClass())
        {
            FString Path;
            if (!Request->TryGetStringField(TEXT("mesh_path"), Path))
                Path = TEXT("/Engine/BasicShapes/Cube");
            if (!UEMasterBridge::IsAssetPath(Path))
            {
                Error = TEXT("mesh_path deve apontar para Static Mesh em /Game/ ou /Engine/.");
                return false;
            }
            Mesh = LoadObject<UStaticMesh>(nullptr, *UEMasterBridge::ObjectPath(Path));
            if (!Mesh)
            {
                Error = TEXT("Static Mesh nao encontrada: ") + Path;
                return false;
            }
        }
        if (Class == ASkeletalMeshActor::StaticClass())
        {
            FString Path;
            if (!Request->TryGetStringField(TEXT("skeletal_mesh_path"), Path) ||
                !UEMasterBridge::IsAssetPath(Path) ||
                !(SkeletalMesh = LoadObject<USkeletalMesh>(nullptr, *UEMasterBridge::ObjectPath(Path))))
            {
                Error = TEXT("skeletal_mesh_path deve apontar para Skeletal Mesh valida.");
                return false;
            }
        }
        bool bAutoPossess = false;
        if (Request->HasField(TEXT("auto_possess_player")) &&
            !Request->TryGetBoolField(TEXT("auto_possess_player"), bAutoPossess))
        {
            Error = TEXT("auto_possess_player deve ser booleano.");
            return false;
        }
        if (bAutoPossess && !Class->IsChildOf(APawn::StaticClass()))
        {
            Error = TEXT("auto_possess_player exige uma classe Pawn.");
            return false;
        }
        const FScopedTransaction Transaction(NSLOCTEXT("UEMasterBridge", "AddActor", "Inserir Actor"));
        AActor* Actor = PlaceActor(Class, Transform, Label, Mesh, bAutoPossess, Error, SkeletalMesh);
        if (!Actor) return false;
        Result->SetObjectField(TEXT("actor"), UEMasterBridge::ActorSummary(Actor));
        return true;
    }

    bool SetActorTransform(const TSharedPtr<FJsonObject>& Request,
                           const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        AActor* Actor = FindActor(Request, Error);
        if (!Actor) return false;
        FTransform Transform;
        if (!UEMasterBridge::ReadTransform(Request, Transform, Error)) return false;
        UEditorActorSubsystem* Actors = GEditor->GetEditorSubsystem<UEditorActorSubsystem>();
        if (!Actors) { Error = TEXT("EditorActorSubsystem indisponivel."); return false; }
        const FScopedTransaction Transaction(NSLOCTEXT("UEMasterBridge", "TransformActor", "Mover Actor"));
        Actor->Modify();
        if (!Actors->SetActorTransform(Actor, Transform))
        {
            Error = TEXT("O Editor recusou a transformacao do Actor.");
            return false;
        }
        Actor->MarkPackageDirty();
        Result->SetObjectField(TEXT("actor"), UEMasterBridge::ActorSummary(Actor));
        return true;
    }

    bool SetActorMesh(const TSharedPtr<FJsonObject>& Request,
                      const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        AStaticMeshActor* Actor = Cast<AStaticMeshActor>(FindActor(Request, Error));
        if (!Actor)
        {
            if (Error.IsEmpty()) Error = TEXT("Selecione um StaticMeshActor para atribuir uma mesh.");
            return false;
        }
        FString Path;
        if (!Request->TryGetStringField(TEXT("mesh_path"), Path) ||
            !UEMasterBridge::IsAssetPath(Path))
        {
            Error = TEXT("mesh_path deve apontar para Static Mesh em /Game/ ou /Engine/.");
            return false;
        }
        UStaticMesh* Mesh = LoadObject<UStaticMesh>(nullptr, *UEMasterBridge::ObjectPath(Path));
        if (!Mesh) { Error = TEXT("Static Mesh nao encontrada: ") + Path; return false; }
        UStaticMeshComponent* Component = Actor->GetStaticMeshComponent();
        if (!Component) { Error = TEXT("Actor sem StaticMeshComponent."); return false; }
        const FScopedTransaction Transaction(NSLOCTEXT("UEMasterBridge", "MeshActor", "Definir mesh"));
        Actor->Modify();
        Component->Modify();
        Component->SetStaticMesh(Mesh);
        Component->MarkPackageDirty();
        Result->SetStringField(TEXT("actor_path"), Actor->GetPathName());
        Result->SetStringField(TEXT("mesh_path"), Mesh->GetPathName());
        return true;
    }

    bool SetActorMaterial(const TSharedPtr<FJsonObject>& Request,
                          const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        AActor* Actor = FindActor(Request, Error);
        if (!Actor) return false;
        FString Path;
        if (!Request->TryGetStringField(TEXT("material_path"), Path) ||
            !UEMasterBridge::IsAssetPath(Path))
        {
            Error = TEXT("material_path deve apontar para um Material em /Game/ ou /Engine/.");
            return false;
        }
        double Slot = 0;
        if (Request->HasField(TEXT("slot")) &&
            !UEMasterBridge::ReadNumber(Request, TEXT("slot"), Slot, 0, 7))
        {
            Error = TEXT("slot deve ser um inteiro entre 0 e 7.");
            return false;
        }
        if (FMath::FloorToInt(Slot) != Slot)
        {
            Error = TEXT("slot deve ser um numero inteiro.");
            return false;
        }
        UMaterialInterface* Material = LoadObject<UMaterialInterface>(
            nullptr, *UEMasterBridge::ObjectPath(Path));
        if (!Material) { Error = TEXT("Material nao encontrado: ") + Path; return false; }
        UMeshComponent* Component = Actor->FindComponentByClass<UMeshComponent>();
        if (!Component || static_cast<int32>(Slot) >= Component->GetNumMaterials())
        {
            Error = TEXT("Actor sem mesh ou slot de material inexistente.");
            return false;
        }
        const FScopedTransaction Transaction(NSLOCTEXT("UEMasterBridge", "MaterialActor", "Definir material"));
        Actor->Modify();
        Component->Modify();
        Component->SetMaterial(static_cast<int32>(Slot), Material);
        Component->MarkPackageDirty();
        Result->SetStringField(TEXT("actor_path"), Actor->GetPathName());
        Result->SetStringField(TEXT("material_path"), Material->GetPathName());
        Result->SetNumberField(TEXT("slot"), Slot);
        return true;
    }

    bool DeleteActor(const TSharedPtr<FJsonObject>& Request,
                     const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        AActor* Actor = FindActor(Request, Error);
        if (!Actor) return false;
        UEditorActorSubsystem* Actors = GEditor->GetEditorSubsystem<UEditorActorSubsystem>();
        if (!Actors) { Error = TEXT("EditorActorSubsystem indisponivel."); return false; }
        const FString Path = Actor->GetPathName();
        const FScopedTransaction Transaction(NSLOCTEXT("UEMasterBridge", "DeleteActor", "Excluir Actor"));
        Actor->Modify();
        if (!Actors->DestroyActor(Actor))
        {
            Error = TEXT("O Editor nao conseguiu excluir o Actor.");
            return false;
        }
        Result->SetStringField(TEXT("deleted_path"), Path);
        return true;
    }

    bool DuplicateActor(const TSharedPtr<FJsonObject>& Request,
                        const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        AActor* Source = FindActor(Request, Error);
        if (!Source) return false;
        double X = 100, Y = 0, Z = 0;
        const TSharedPtr<FJsonObject>* Offset = nullptr;
        if (Request->HasField(TEXT("offset")) &&
            (!Request->TryGetObjectField(TEXT("offset"), Offset) || !Offset ||
             !UEMasterBridge::ReadNumber(*Offset, TEXT("x"), X, -100000, 100000) ||
             !UEMasterBridge::ReadNumber(*Offset, TEXT("y"), Y, -100000, 100000) ||
             !UEMasterBridge::ReadNumber(*Offset, TEXT("z"), Z, -100000, 100000)))
        {
            Error = TEXT("offset exige x,y,z finitos em centimetros.");
            return false;
        }
        UEditorActorSubsystem* Actors = GEditor->GetEditorSubsystem<UEditorActorSubsystem>();
        if (!Actors) { Error = TEXT("EditorActorSubsystem indisponivel."); return false; }
        const FScopedTransaction Transaction(NSLOCTEXT("UEMasterBridge", "DuplicateActor", "Duplicar Actor"));
        AActor* Copy = Actors->DuplicateActor(Source, Source->GetWorld(), FVector(X, Y, Z));
        if (!Copy) { Error = TEXT("O Editor nao conseguiu duplicar o Actor."); return false; }
        Result->SetObjectField(TEXT("actor"), UEMasterBridge::ActorSummary(Copy));
        return true;
    }

    bool RenameActor(const TSharedPtr<FJsonObject>& Request,
                     const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        AActor* Actor = FindActor(Request, Error);
        if (!Actor) return false;
        FString Label;
        if (!Request->TryGetStringField(TEXT("label"), Label))
        {
            Error = TEXT("Informe label como texto.");
            return false;
        }
        Label.TrimStartAndEndInline();
        if (Label.IsEmpty() ||
            Label.Len() > 80 || Label.Contains(TEXT("\n")) || Label.Contains(TEXT("\r")))
        {
            Error = TEXT("Informe label com 1 a 80 caracteres, sem quebras de linha.");
            return false;
        }
        const FScopedTransaction Transaction(NSLOCTEXT("UEMasterBridge", "RenameActor", "Renomear Actor"));
        Actor->Modify();
        Actor->SetActorLabel(Label, true);
        Actor->MarkPackageDirty();
        Result->SetObjectField(TEXT("actor"), UEMasterBridge::ActorSummary(Actor));
        return true;
    }

    bool AttachActor(const TSharedPtr<FJsonObject>& Request,
                     const TSharedRef<FJsonObject>& Result, FString& Error, bool bDetach)
    {
        AActor* Child = FindActor(Request, Error);
        if (!Child) return false;
        AActor* Parent = nullptr;
        if (!bDetach)
        {
            const TSharedPtr<FJsonObject> ParentRequest = MakeShared<FJsonObject>();
            FString Path;
            if (!Request->TryGetStringField(TEXT("parent_path"), Path))
            {
                Error = TEXT("Informe parent_path obtido da cena.");
                return false;
            }
            ParentRequest->SetStringField(TEXT("actor_path"), Path);
            Parent = FindActor(ParentRequest, Error);
            if (!Parent) return false;
            if (Parent == Child || Parent->IsAttachedTo(Child) || !Parent->GetRootComponent() ||
                !Child->GetRootComponent())
            {
                Error = TEXT("Attachment invalido: ciclo, mesmo Actor ou RootComponent ausente.");
                return false;
            }
        }
        else if (!Child->GetAttachParentActor())
        {
            Error = TEXT("Actor nao esta anexado a outro Actor.");
            return false;
        }
        const FScopedTransaction Transaction(NSLOCTEXT("UEMasterBridge", "AttachActor", "Vincular Actors"));
        Child->Modify();
        if (USceneComponent* Root = Child->GetRootComponent()) Root->Modify();
        bool bOk = true;
        if (bDetach) Child->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
        else bOk = Child->AttachToActor(Parent, FAttachmentTransformRules::KeepWorldTransform);
        if (!bOk)
        {
            Error = TEXT("O Editor recusou a vinculacao dos Actors.");
            return false;
        }
        Child->MarkPackageDirty();
        Result->SetObjectField(TEXT("actor"), UEMasterBridge::ActorSummary(Child));
        Result->SetStringField(TEXT("parent_path"), Parent ? Parent->GetPathName() : TEXT(""));
        return true;
    }

    bool SetActorProperties(const TSharedPtr<FJsonObject>& Request,
                            const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        AActor* Actor = FindActor(Request, Error);
        if (!Actor) return false;
        bool bCollision = false, bPhysics = false;
        double Intensity = 0, Radius = 0;
        FString Folder, Mobility;
        const TArray<TSharedPtr<FJsonValue>>* Tags = nullptr;
        const bool HasCollision = Request->HasField(TEXT("collision_enabled"));
        const bool HasPhysics = Request->HasField(TEXT("simulate_physics"));
        const bool HasIntensity = Request->HasField(TEXT("light_intensity"));
        const bool HasRadius = Request->HasField(TEXT("attenuation_radius"));
        const bool HasFolder = Request->HasField(TEXT("folder"));
        const bool HasMobility = Request->HasField(TEXT("mobility"));
        const bool HasTags = Request->HasField(TEXT("tags"));
        // In UE 5.8, JSON map keys use an internal shared string type.
        // Count recognized fields instead of binding a map key to FString.
        const TCHAR* AllowedKeys[] = {
            TEXT("id"), TEXT("command"), TEXT("actor_path"),
            TEXT("collision_enabled"), TEXT("simulate_physics"),
            TEXT("light_intensity"), TEXT("attenuation_radius"),
            TEXT("folder"), TEXT("mobility"), TEXT("tags")
        };
        int32 KnownFields = 0;
        for (const TCHAR* Key : AllowedKeys)
            if (Request->HasField(Key)) ++KnownFields;
        if (Request->Values.Num() != KnownFields)
        {
            Error = TEXT("Pedido contem uma propriedade nao permitida.");
            return false;
        }
        UPointLightComponent* PointLight = Actor->FindComponentByClass<UPointLightComponent>();
        UPrimitiveComponent* Primitive = Cast<UPrimitiveComponent>(Actor->GetRootComponent());
        if (HasCollision && !Request->TryGetBoolField(TEXT("collision_enabled"), bCollision))
            { Error = TEXT("collision_enabled deve ser booleano."); return false; }
        if (HasPhysics && (!Request->TryGetBoolField(TEXT("simulate_physics"), bPhysics) ||
            !Cast<UMeshComponent>(Primitive)))
            { Error = TEXT("simulate_physics exige booleano e mesh como componente raiz."); return false; }
        if (HasIntensity && (!PointLight ||
            !UEMasterBridge::ReadNumber(Request, TEXT("light_intensity"), Intensity, 0, 10000000)))
            { Error = TEXT("light_intensity exige PointLight e valor de 0 a 10000000."); return false; }
        if (HasRadius && (!PointLight ||
            !UEMasterBridge::ReadNumber(Request, TEXT("attenuation_radius"), Radius, 1, 1000000)))
            { Error = TEXT("attenuation_radius exige PointLight e valor de 1 a 1000000."); return false; }
        if (HasFolder && (!Request->TryGetStringField(TEXT("folder"), Folder) ||
            Folder.Len() > 120 || Folder.Contains(TEXT("..")) || Folder.Contains(TEXT("\\")) ||
            Folder.Contains(TEXT("\n")) || Folder.Contains(TEXT("\r"))))
            { Error = TEXT("folder deve ter ate 120 caracteres, sem caminho relativo."); return false; }
        if (HasMobility && (!Request->TryGetStringField(TEXT("mobility"), Mobility) ||
            !Actor->GetRootComponent() ||
            (Mobility != TEXT("Static") && Mobility != TEXT("Stationary") && Mobility != TEXT("Movable"))))
            { Error = TEXT("mobility deve ser Static, Stationary ou Movable."); return false; }
        TArray<FName> NewTags;
        if (HasTags)
        {
            if (!Request->TryGetArrayField(TEXT("tags"), Tags) || Tags->Num() > 16)
                { Error = TEXT("tags exige lista de ate 16 textos."); return false; }
            for (const TSharedPtr<FJsonValue>& Tag : *Tags)
            {
                if (!Tag.IsValid() || Tag->Type != EJson::String || Tag->AsString().IsEmpty() ||
                    Tag->AsString().Len() > 64)
                    { Error = TEXT("Cada tag deve conter de 1 a 64 caracteres."); return false; }
                NewTags.Add(FName(*Tag->AsString()));
            }
        }
        if (!(HasCollision || HasPhysics || HasIntensity || HasRadius || HasFolder || HasMobility || HasTags))
            { Error = TEXT("Informe pelo menos uma propriedade permitida."); return false; }
        if (HasPhysics && bPhysics && HasCollision && !bCollision)
            { Error = TEXT("Nao e possivel ativar fisica e desativar colisao no mesmo pedido."); return false; }
        if (HasPhysics && bPhysics &&
            (HasMobility ? Mobility != TEXT("Movable") : Primitive->GetMobility() != EComponentMobility::Movable))
            { Error = TEXT("Fisica exige mobility Movable; envie mobility: Movable no pedido."); return false; }
        const FScopedTransaction Transaction(NSLOCTEXT("UEMasterBridge", "ActorProperties", "Editar propriedades do Actor"));
        Actor->Modify();
        if (Primitive && (HasPhysics || HasMobility)) Primitive->Modify();
        if (PointLight && (HasIntensity || HasRadius)) PointLight->Modify();
        if (HasCollision) Actor->SetActorEnableCollision(bCollision);
        if (HasFolder) Actor->SetFolderPath(FName(*Folder));
        if (HasTags) Actor->Tags = NewTags;
        if (HasMobility)
        {
            USceneComponent* Root = Actor->GetRootComponent();
            Root->Modify();
            Root->SetMobility(Mobility == TEXT("Static") ? EComponentMobility::Static :
                (Mobility == TEXT("Stationary") ? EComponentMobility::Stationary : EComponentMobility::Movable));
        }
        if (HasPhysics) Primitive->SetSimulatePhysics(bPhysics);
        if (HasIntensity) PointLight->SetIntensity(static_cast<float>(Intensity));
        if (HasRadius) PointLight->SetAttenuationRadius(static_cast<float>(Radius));
        Actor->MarkPackageDirty();
        Result->SetObjectField(TEXT("actor"), UEMasterBridge::ActorSummary(Actor));
        return true;
    }

    bool EditComponent(const TSharedPtr<FJsonObject>& Request,
                       const TSharedRef<FJsonObject>& Result, FString& Error, bool bRemove)
    {
        AActor* Actor = FindActor(Request, Error);
        if (!Actor) return false;
        FString Name;
        if (!Request->TryGetStringField(TEXT("component_name"), Name) ||
            Name.IsEmpty() || Name.Len() > 64 ||
            !Name.StartsWith(TEXT("Bridge_")) || Name.Contains(TEXT("/")) || Name.Contains(TEXT(".")))
        {
            Error = TEXT("component_name deve comecar com Bridge_ e ter ate 64 caracteres.");
            return false;
        }
        for (const TCHAR C : Name)
            if (!FChar::IsAlnum(C) && C != TEXT('_'))
            {
                Error = TEXT("component_name aceita apenas letras, numeros e underscore.");
                return false;
            }
        UActorComponent* Existing = nullptr;
        for (UActorComponent* Component : Actor->GetComponents())
            if (Component && Component->GetName() == Name) { Existing = Component; break; }
        if (bRemove)
        {
            if (!Existing || Existing == Actor->GetRootComponent() ||
                Existing->CreationMethod != EComponentCreationMethod::Instance ||
                !Existing->ComponentHasTag(FName(TEXT("UEMasterBridge"))))
            {
                Error = TEXT("Apenas componentes de instancia criados pela ponte podem ser removidos.");
                return false;
            }
            const FScopedTransaction Transaction(NSLOCTEXT("UEMasterBridge", "RemoveComponent", "Remover componente"));
            Actor->Modify();
            Existing->Modify();
            Actor->RemoveInstanceComponent(Existing);
            Existing->DestroyComponent();
        }
        else
        {
            FString Kind;
            if (Existing || !Actor->GetRootComponent() ||
                !Request->TryGetStringField(TEXT("component_kind"), Kind) ||
                (Kind != TEXT("BoxCollision") && Kind != TEXT("PointLight") && Kind != TEXT("StaticMesh")))
            {
                Error = TEXT("Componente existente, raiz ausente ou component_kind invalido.");
                return false;
            }
            UStaticMesh* Mesh = nullptr;
            if (Kind == TEXT("StaticMesh"))
            {
                FString Path;
                if (!Request->TryGetStringField(TEXT("mesh_path"), Path) ||
                    !UEMasterBridge::IsAssetPath(Path) ||
                    !(Mesh = LoadObject<UStaticMesh>(nullptr, *UEMasterBridge::ObjectPath(Path))))
                {
                    Error = TEXT("mesh_path deve identificar uma StaticMesh valida.");
                    return false;
                }
            }
            const FScopedTransaction Transaction(NSLOCTEXT("UEMasterBridge", "AddComponent", "Adicionar componente"));
            Actor->Modify();
            UClass* Class = Kind == TEXT("BoxCollision") ? UBoxComponent::StaticClass() :
                Kind == TEXT("PointLight") ? UPointLightComponent::StaticClass() : UStaticMeshComponent::StaticClass();
            USceneComponent* Added = NewObject<USceneComponent>(Actor, Class, FName(*Name), RF_Transactional);
            if (!Added) { Error = TEXT("Falha ao criar componente."); return false; }
            Added->CreationMethod = EComponentCreationMethod::Instance;
            Added->ComponentTags.Add(FName(TEXT("UEMasterBridge")));
            Added->SetupAttachment(Actor->GetRootComponent());
            if (UStaticMeshComponent* Static = Cast<UStaticMeshComponent>(Added)) Static->SetStaticMesh(Mesh);
            Actor->AddInstanceComponent(Added);
            Added->OnComponentCreated();
            Added->RegisterComponent();
        }
        Actor->MarkPackageDirty();
        Result->SetObjectField(TEXT("actor"), UEMasterBridge::ActorSummary(Actor));
        Result->SetStringField(TEXT("component_name"), Name);
        return true;
    }

    bool CreateContentFolder(const TSharedPtr<FJsonObject>& Request,
                             const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        FString Folder;
        if (!Request->TryGetStringField(TEXT("folder"), Folder) ||
            !UEMasterBridge::IsContentFolder(Folder))
        {
            Error = TEXT("folder deve ser pasta valida abaixo de /Game/, sem ponto ou barra final.");
            return false;
        }
        UEditorAssetSubsystem* Assets = GEditor->GetEditorSubsystem<UEditorAssetSubsystem>();
        if (!Assets || (!Assets->DoesDirectoryExist(Folder) && !Assets->MakeDirectory(Folder)))
        {
            Error = TEXT("Nao foi possivel criar pasta no Content Browser.");
            return false;
        }
        Result->SetStringField(TEXT("folder"), Folder);
        return true;
    }

    bool EditAsset(const TSharedPtr<FJsonObject>& Request,
                   const TSharedRef<FJsonObject>& Result, FString& Error, bool bDuplicate)
    {
        FString Source, Destination;
        if (!Request->TryGetStringField(TEXT("source"), Source) ||
            !Request->TryGetStringField(TEXT("destination"), Destination) ||
            !UEMasterBridge::IsWritableAsset(Source) ||
            !UEMasterBridge::IsWritableAsset(Destination) || Source == Destination)
        {
            Error = TEXT("source e destination devem ser assets diferentes em /Game/, sem sufixo .Objeto.");
            return false;
        }
        UEditorAssetSubsystem* Assets = GEditor->GetEditorSubsystem<UEditorAssetSubsystem>();
        if (!Assets || !Assets->DoesAssetExist(Source) || Assets->DoesAssetExist(Destination) ||
            FPackageName::DoesPackageExist(Destination, nullptr, false))
        {
            Error = TEXT("Asset de origem inexistente ou destino ja ocupado.");
            return false;
        }
        UObject* Existing = Assets->LoadAsset(Source);
        if (!Existing || Existing->IsA<UWorld>() || Existing->GetOutermost()->GetName() != Source)
        {
            Error = TEXT("Origem nao carregavel, redirector ou mapa; selecione um asset real.");
            return false;
        }
        const FString Folder = FPackageName::GetLongPackagePath(Destination);
        if ((Folder != TEXT("/Game") && !UEMasterBridge::IsContentFolder(Folder)) ||
            (Folder != TEXT("/Game") && !Assets->DoesDirectoryExist(Folder) &&
             !Assets->MakeDirectory(Folder)))
        {
            Error = TEXT("Pasta de destino invalida ou nao pode ser criada.");
            return false;
        }
        // Asset renames may create Unreal redirectors. The Editor performs reference updates.
        const bool bOk = bDuplicate
            ? Assets->DuplicateAsset(Source, Destination) != nullptr
            : Assets->RenameAsset(Source, Destination);
        if (!bOk)
        {
            Error = TEXT("Falha ao alterar asset. Consulte o Output Log e o controle de versao.");
            return false;
        }
        if (!Assets->SaveAsset(Destination, false))
        {
            Error = TEXT("Asset alterado no Editor, mas nao salvo no disco.");
            Result->SetStringField(TEXT("destination"), Destination);
            return false;
        }
        Result->SetStringField(TEXT("source"), Source);
        Result->SetStringField(TEXT("destination"), Destination);
        return true;
    }

    bool ComposeScene(const TSharedPtr<FJsonObject>& Request,
                      const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        UWorld* World = EditorWorld(Error);
        if (!World) return false;
        const TArray<TSharedPtr<FJsonValue>>* Entries = nullptr;
        if (!Request->TryGetArrayField(TEXT("actors"), Entries) ||
            Entries->IsEmpty() || Entries->Num() > 32)
        {
            Error = TEXT("actors exige lista de 1 a 32 objetos.");
            return false;
        }
        struct FPlacement
        {
            UClass* Class = nullptr;
            FTransform Transform;
            FString Label;
            UStaticMesh* Mesh = nullptr;
            USkeletalMesh* SkeletalMesh = nullptr;
            bool bAutoPossess = false;
        };
        TArray<FPlacement> Placements;
        for (const TSharedPtr<FJsonValue>& Value : *Entries)
        {
            if (!Value.IsValid() || Value->Type != EJson::Object)
            {
                Error = TEXT("Cada elemento de actors deve ser objeto JSON.");
                return false;
            }
            const TSharedPtr<FJsonObject> Entry = Value->AsObject();
            FPlacement Placement;
            Placement.Class = ResolveSpawnClass(Entry, Error);
            if (!Placement.Class || !UEMasterBridge::ReadTransform(Entry, Placement.Transform, Error) ||
                !UEMasterBridge::ReadActorLabel(Entry, Placement.Label, Error)) return false;
            if (Placement.Class == AStaticMeshActor::StaticClass())
            {
                FString Path;
                if (!Entry->TryGetStringField(TEXT("mesh_path"), Path))
                    Path = TEXT("/Engine/BasicShapes/Cube");
                if (!UEMasterBridge::IsAssetPath(Path) ||
                    !(Placement.Mesh = LoadObject<UStaticMesh>(nullptr, *UEMasterBridge::ObjectPath(Path))))
                {
                    Error = TEXT("StaticMesh invalida no lote: ") + Path;
                    return false;
                }
            }
            if (Placement.Class == ASkeletalMeshActor::StaticClass())
            {
                FString Path;
                if (!Entry->TryGetStringField(TEXT("skeletal_mesh_path"), Path) ||
                    !UEMasterBridge::IsAssetPath(Path) ||
                    !(Placement.SkeletalMesh = LoadObject<USkeletalMesh>(nullptr, *UEMasterBridge::ObjectPath(Path))))
                {
                    Error = TEXT("SkeletalMesh invalida no lote.");
                    return false;
                }
            }
            if (Entry->HasField(TEXT("auto_possess_player")) &&
                !Entry->TryGetBoolField(TEXT("auto_possess_player"), Placement.bAutoPossess))
            {
                Error = TEXT("auto_possess_player deve ser booleano.");
                return false;
            }
            if (Placement.bAutoPossess && !Placement.Class->IsChildOf(APawn::StaticClass()))
            {
                Error = TEXT("auto_possess_player exige Pawn.");
                return false;
            }
            Placements.Add(MoveTemp(Placement));
        }
        // Validate all input and assets before touching the level. Undo is one Editor operation.
        const FScopedTransaction Transaction(NSLOCTEXT("UEMasterBridge", "ComposeScene", "Montar cena"));
        TArray<AActor*> Created;
        TArray<TSharedPtr<FJsonValue>> Summaries;
        for (const FPlacement& Placement : Placements)
        {
            AActor* Actor = PlaceActor(Placement.Class, Placement.Transform,
                Placement.Label, Placement.Mesh, Placement.bAutoPossess, Error, Placement.SkeletalMesh);
            if (!Actor)
            {
                UEditorActorSubsystem* Actors = GEditor->GetEditorSubsystem<UEditorActorSubsystem>();
                if (Actors)
                    for (AActor* ToRemove : Created) Actors->DestroyActor(ToRemove);
                Error += TEXT(" Os Actors criados neste lote foram removidos; confira o mapa antes de salvar.");
                return false;
            }
            Created.Add(Actor);
            if (Summaries.Num() < 12)
                Summaries.Add(MakeShared<FJsonValueObject>(UEMasterBridge::ActorSummary(Actor)));
        }
        Result->SetStringField(TEXT("map"), World->GetOutermost()->GetName());
        Result->SetNumberField(TEXT("total"), Created.Num());
        Result->SetNumberField(TEXT("actors_returned"), Summaries.Num());
        Result->SetArrayField(TEXT("actors"), Summaries);
        return true;
    }

    bool FrameActor(const TSharedPtr<FJsonObject>& Request,
                    const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        AActor* Actor = FindActor(Request, Error);
        if (!Actor) return false;
        UUnrealEditorSubsystem* Editor = GEditor->GetEditorSubsystem<UUnrealEditorSubsystem>();
        if (!Editor) { Error = TEXT("Viewport de nivel indisponivel."); return false; }
        FVector Origin, Extent;
        Actor->GetActorBounds(false, Origin, Extent);
        const double Distance = FMath::Max(350.0, Extent.GetMax() * 3.0);
        const FVector Camera = Origin + FVector(-Distance, -Distance, Distance * 0.65);
        Editor->SetLevelViewportCameraInfo(Camera, FRotationMatrix::MakeFromX(Origin - Camera).Rotator());
        Result->SetStringField(TEXT("actor_path"), Actor->GetPathName());
        Result->SetObjectField(TEXT("camera_location"), UEMasterBridge::VectorJson(Camera));
        return true;
    }

    bool CreateDemoRoom(const TSharedPtr<FJsonObject>& Request,
                        const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        // Validate resources before replacing the currently open map.
        UStaticMesh* Cube = LoadObject<UStaticMesh>(nullptr, TEXT("/Engine/BasicShapes/Cube.Cube"));
        if (!Cube) { Error = TEXT("Mesh padrao /Engine/BasicShapes/Cube indisponivel."); return false; }
        FString Package;
        UWorld* World = BeginNewLevel(Request, Package, Error);
        if (!World) return false;
        UEditorActorSubsystem* Actors = GEditor->GetEditorSubsystem<UEditorActorSubsystem>();
        if (!Actors) { Error = TEXT("EditorActorSubsystem indisponivel."); return false; }

        struct FWall { const TCHAR* Label; FVector Location; FVector Scale; };
        const FWall Walls[] = {
            { TEXT("Piso"), FVector(0, 0, -50), FVector(10, 10, 1) },
            { TEXT("Parede_Norte"), FVector(0, 500, 150), FVector(10, 0.25, 4) },
            { TEXT("Parede_Sul"), FVector(0, -500, 150), FVector(10, 0.25, 4) },
            { TEXT("Parede_Leste"), FVector(500, 0, 150), FVector(0.25, 10, 4) },
            { TEXT("Parede_Oeste"), FVector(-500, 0, 150), FVector(0.25, 10, 4) }
        };
        TArray<TSharedPtr<FJsonValue>> Placed;
        for (const FWall& Wall : Walls)
        {
            const FTransform Transform(FRotator::ZeroRotator, Wall.Location, Wall.Scale);
            AActor* Actor = PlaceActor(AStaticMeshActor::StaticClass(), Transform,
                Wall.Label, Cube, false, Error);
            if (!Actor) return false;
            Placed.Add(MakeShared<FJsonValueObject>(UEMasterBridge::ActorSummary(Actor)));
        }
        APointLight* Light = Cast<APointLight>(PlaceActor(APointLight::StaticClass(),
            FTransform(FRotator::ZeroRotator, FVector(0, 0, 290)),
            TEXT("Luz_Sala"), nullptr, false, Error));
        if (!Light) return false;
        if (UPointLightComponent* Component = Light->FindComponentByClass<UPointLightComponent>())
        {
            Component->Modify();
            Component->SetIntensity(8000.f);
            Component->SetAttenuationRadius(2000.f);
        }
        Placed.Add(MakeShared<FJsonValueObject>(UEMasterBridge::ActorSummary(Light)));

        AActor* Pawn = PlaceActor(ADefaultPawn::StaticClass(),
            FTransform(FRotator::ZeroRotator, FVector(-220, 0, 170)),
            TEXT("Jogador_Sala"), nullptr, true, Error);
        if (!Pawn) return false;
        Placed.Add(MakeShared<FJsonValueObject>(UEMasterBridge::ActorSummary(Pawn)));
        if (!UEditorLoadingAndSavingUtils::SaveMap(World, Package))
        {
            Error = TEXT("Sala criada no Editor, mas o mapa nao foi salvo. Salve pelo Editor.");
            return false;
        }
        if (UUnrealEditorSubsystem* Editor = GEditor->GetEditorSubsystem<UUnrealEditorSubsystem>())
        {
            const FVector Camera(-280, -260, 270);
            const FVector Focus(0, 0, 120);
            Editor->SetLevelViewportCameraInfo(Camera,
                FRotationMatrix::MakeFromX(Focus - Camera).Rotator());
        }
        Result->SetStringField(TEXT("map"), Package);
        Result->SetArrayField(TEXT("actors"), Placed);
        Result->SetNumberField(TEXT("total"), Placed.Num());
        return true;
    }

    bool CreateBlueprint(const TSharedPtr<FJsonObject>& Request,
                         const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        FString AssetName;
        FString ParentName;
        if (!Request->TryGetStringField(TEXT("name"), AssetName) ||
            !Request->TryGetStringField(TEXT("parent_class"), ParentName))
        {
            Error = TEXT("Informe name e parent_class (Actor, Pawn ou Character).");
            return false;
        }

        // Keep the destination fixed in /Game; names cannot contain slashes or dots.
        const FString PackageName = TEXT("/Game/Blueprints/") + AssetName;
        if (AssetName.IsEmpty() || AssetName.Contains(TEXT("/")) ||
            AssetName.Contains(TEXT(".")) || !UEMasterBridge::IsProjectContentPath(PackageName))
        {
            Error = TEXT("Nome de Blueprint invalido. Use um nome simples, como BP_Player.");
            return false;
        }
        if (FPackageName::DoesPackageExist(PackageName, nullptr, false) ||
            FindObject<UObject>(nullptr, *(PackageName + TEXT(".") + AssetName)))
        {
            Error = TEXT("Ja existe um asset com esse nome em /Game/Blueprints.");
            return false;
        }

        UClass* Parent = nullptr;
        if (ParentName == TEXT("Actor")) Parent = AActor::StaticClass();
        else if (ParentName == TEXT("Pawn")) Parent = APawn::StaticClass();
        else if (ParentName == TEXT("Character")) Parent = ACharacter::StaticClass();
        else
        {
            Error = TEXT("Classe pai invalida: escolha Actor, Pawn ou Character.");
            return false;
        }

        TStrongObjectPtr<UBlueprintFactory> Factory(NewObject<UBlueprintFactory>());
        Factory->ParentClass = Parent;
        Factory->bSkipClassPicker = true;
        UBlueprint* Blueprint = Cast<UBlueprint>(FAssetToolsModule::GetModule().Get().CreateAsset(
            AssetName, TEXT("/Game/Blueprints"), UBlueprint::StaticClass(), Factory.Get(),
            FName(TEXT("UEMasterBridge")), false));
        if (!Blueprint)
        {
            Error = TEXT("O Unreal nao conseguiu criar o Blueprint. Verifique o Output Log.");
            return false;
        }

        FCompilerResultsLog CompileLog(false);
        FKismetEditorUtilities::CompileBlueprint(Blueprint, EBlueprintCompileOptions::None, &CompileLog);
        if (CompileLog.NumErrors > 0 || Blueprint->Status == BS_Error)
        {
            Error = FString::Printf(TEXT("Blueprint %s criado, mas a compilacao falhou (%d erros)."),
                *AssetName, CompileLog.NumErrors);
            return false;
        }
        if (!UEMasterBridge::SaveAsset(Blueprint, Error)) return false;
        Result->SetStringField(TEXT("asset_path"), PackageName);
        Result->SetStringField(TEXT("parent_class"), ParentName);
        Result->SetNumberField(TEXT("warnings"), CompileLog.NumWarnings);
        return true;
    }

    bool CharacterDetails(const TSharedPtr<FJsonObject>& Request,
                          const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        FString Path;
        if (!Request->TryGetStringField(TEXT("character_path"), Path) ||
            !UEMasterBridge::IsWritableAsset(Path))
        {
            Error = TEXT("Informe character_path de um Blueprint em /Game/, sem sufixo .uasset.");
            return false;
        }
        UBlueprint* Blueprint = LoadObject<UBlueprint>(
            nullptr, *UEMasterBridge::ObjectPath(Path));
        ACharacter* Defaults = Blueprint && Blueprint->GeneratedClass &&
            Blueprint->ParentClass && Blueprint->ParentClass->IsChildOf(ACharacter::StaticClass())
            ? Cast<ACharacter>(Blueprint->GeneratedClass->GetDefaultObject()) : nullptr;
        if (!Defaults || !Defaults->GetMesh() || !Defaults->GetCapsuleComponent() ||
            !Defaults->GetCharacterMovement())
        {
            Error = TEXT("Blueprint Character compilado nao encontrado: ") + Path;
            return false;
        }
        const USkeletalMeshComponent* Mesh = Defaults->GetMesh();
        const UCapsuleComponent* Capsule = Defaults->GetCapsuleComponent();
        const UCharacterMovementComponent* Movement = Defaults->GetCharacterMovement();
        USimpleConstructionScript* SCS = Blueprint->SimpleConstructionScript;
        const bool bHasCamera = SCS &&
            SCS->FindSCSNode(FName(TEXT("UEMasterCameraBoom"))) &&
            SCS->FindSCSNode(FName(TEXT("UEMasterFollowCamera")));
        Result->SetStringField(TEXT("character_path"), Path);
        Result->SetBoolField(TEXT("compiled"), Blueprint->Status == BS_UpToDate ||
            Blueprint->Status == BS_UpToDateWithWarnings);
        Result->SetStringField(TEXT("parent_class"), Blueprint->ParentClass->GetName());
        Result->SetStringField(TEXT("skeletal_mesh_path"),
            Mesh->GetSkeletalMeshAsset() ? Mesh->GetSkeletalMeshAsset()->GetPathName() : TEXT(""));
        Result->SetObjectField(TEXT("mesh_location"),
            UEMasterBridge::VectorJson(Mesh->GetRelativeLocation()));
        Result->SetNumberField(TEXT("capsule_radius"), Capsule->GetUnscaledCapsuleRadius());
        Result->SetNumberField(TEXT("capsule_half_height"), Capsule->GetUnscaledCapsuleHalfHeight());
        Result->SetNumberField(TEXT("max_walk_speed"), Movement->MaxWalkSpeed);
        Result->SetNumberField(TEXT("jump_z_velocity"), Movement->JumpZVelocity);
        Result->SetBoolField(TEXT("has_third_person_camera"), bHasCamera);
        return true;
    }

    bool CreateCharacter(const TSharedPtr<FJsonObject>& Request,
                         const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        FString Name;
        if (!Request->TryGetStringField(TEXT("name"), Name) ||
            !UEMasterBridge::IsIdentifier(Name))
        {
            Error = TEXT("Informe name valido para /Game/Characters/.");
            return false;
        }
        const FString Path = TEXT("/Game/Characters/") + Name;
        if (FPackageName::DoesPackageExist(Path, nullptr, false) ||
            FindObject<UObject>(nullptr, *UEMasterBridge::ObjectPath(Path)))
        {
            Error = TEXT("Ja existe um asset com esse nome: ") + Path;
            return false;
        }
        bool bCamera = true;
        if (Request->HasField(TEXT("camera")) &&
            !Request->TryGetBoolField(TEXT("camera"), bCamera))
        {
            Error = TEXT("camera deve ser booleano.");
            return false;
        }
        FString MeshPath;
        USkeletalMesh* Asset = nullptr;
        if (Request->HasField(TEXT("skeletal_mesh_path")))
        {
            if (!Request->TryGetStringField(TEXT("skeletal_mesh_path"), MeshPath))
            {
                Error = TEXT("skeletal_mesh_path deve ser um caminho de Skeletal Mesh.");
                return false;
            }
            const FString ReferencePrefix = TEXT("SkeletalMesh'");
            if (MeshPath.StartsWith(ReferencePrefix) && MeshPath.EndsWith(TEXT("'")))
                MeshPath = MeshPath.Mid(ReferencePrefix.Len(), MeshPath.Len() - ReferencePrefix.Len() - 1);
            if (!UEMasterBridge::IsAssetPath(MeshPath))
            {
                Error = TEXT("skeletal_mesh_path deve estar em /Game ou /Engine; use Copy Reference numa Skeletal Mesh.");
                return false;
            }
            Asset = LoadObject<USkeletalMesh>(nullptr, *UEMasterBridge::ObjectPath(MeshPath));
            if (!Asset)
            {
                Error = TEXT("Skeletal Mesh nao encontrada (ou asset de outro tipo): ") + MeshPath +
                    TEXT(". Consulte list_skeletal_meshes para obter caminhos existentes no projeto.");
                return false;
            }
        }
        FVector MeshLocation = FVector::ZeroVector;
        const TSharedPtr<FJsonObject>* Location = nullptr;
        if (Request->HasField(TEXT("mesh_location")) &&
            (!Asset || !Request->TryGetObjectField(TEXT("mesh_location"), Location) ||
             !Location || !UEMasterBridge::ReadVector3(
                 *Location, MeshLocation, -100000, 100000)))
        {
            Error = TEXT("mesh_location requer skeletal_mesh_path e {x,y,z} finitos em cm.");
            return false;
        }
        const int32 ExpectedFields = 2 + (Request->HasField(TEXT("id")) ? 1 : 0) +
            (Request->HasField(TEXT("camera")) ? 1 : 0) +
            (Request->HasField(TEXT("skeletal_mesh_path")) ? 1 : 0) +
            (Request->HasField(TEXT("mesh_location")) ? 1 : 0);
        if (Request->Values.Num() != ExpectedFields)
        {
            Error = TEXT("create_character aceita name, camera, skeletal_mesh_path e mesh_location.");
            return false;
        }
        TStrongObjectPtr<UBlueprintFactory> Factory(NewObject<UBlueprintFactory>());
        Factory->ParentClass = ACharacter::StaticClass();
        Factory->bSkipClassPicker = true;
        UBlueprint* Blueprint = Cast<UBlueprint>(FAssetToolsModule::GetModule().Get().CreateAsset(
            Name, TEXT("/Game/Characters"), UBlueprint::StaticClass(), Factory.Get(),
            FName(TEXT("UEMasterBridge")), false));
        if (!Blueprint || !Blueprint->SimpleConstructionScript)
        {
            Error = TEXT("Falha ao criar Blueprint Character em ") + Path +
                TEXT("; inspecione o Content Browser antes de repetir.");
            return false;
        }
        if (bCamera)
        {
            USimpleConstructionScript* SCS = Blueprint->SimpleConstructionScript;
            USCS_Node* Boom = SCS->CreateNode(
                USpringArmComponent::StaticClass(), FName(TEXT("UEMasterCameraBoom")));
            USCS_Node* Camera = SCS->CreateNode(
                UCameraComponent::StaticClass(), FName(TEXT("UEMasterFollowCamera")));
            if (!Boom || !Camera)
            {
                Error = TEXT("Falha ao criar camera em ") + Path +
                    TEXT("; asset ainda nao foi salvo.");
                return false;
            }
            USpringArmComponent* BoomTemplate = CastChecked<USpringArmComponent>(
                Boom->ComponentTemplate);
            UCameraComponent* CameraTemplate = CastChecked<UCameraComponent>(
                Camera->ComponentTemplate);
            BoomTemplate->TargetArmLength = 300.0f;
            BoomTemplate->bUsePawnControlRotation = true;
            BoomTemplate->SetRelativeLocation(FVector(0, 0, 60));
            CameraTemplate->bUsePawnControlRotation = false;
            CameraTemplate->SetAutoActivate(true);
            Camera->AttachToName = USpringArmComponent::SocketName;
            SCS->AddNode(Boom); // Character's native capsule is the root.
            Boom->AddChildNode(Camera, true);
            FBlueprintEditorUtils::MarkBlueprintAsStructurallyModified(Blueprint);
        }
        FCompilerResultsLog CompileLog(false);
        FKismetEditorUtilities::CompileBlueprint(Blueprint, EBlueprintCompileOptions::None, &CompileLog);
        ACharacter* Defaults = Blueprint->GeneratedClass
            ? Cast<ACharacter>(Blueprint->GeneratedClass->GetDefaultObject()) : nullptr;
        if (CompileLog.NumErrors > 0 ||
            (Blueprint->Status != BS_UpToDate && Blueprint->Status != BS_UpToDateWithWarnings) ||
            !Defaults || !Defaults->GetMesh() || !Defaults->GetCapsuleComponent() ||
            !Defaults->GetCharacterMovement())
        {
            Error = FString::Printf(TEXT("Character %s criado, mas compilacao ou componentes nativos falharam (%d erros); inspecione o asset."),
                *Path, CompileLog.NumErrors);
            return false;
        }
        if (Asset)
        {
            USkeletalMeshComponent* Mesh = Defaults->GetMesh();
            Defaults->Modify();
            Mesh->Modify();
            Mesh->SetSkeletalMeshAsset(Asset);
            if (Request->HasField(TEXT("mesh_location")))
                Mesh->SetRelativeLocation(MeshLocation);
            if (Mesh->GetSkeletalMeshAsset() != Asset)
            {
                Error = TEXT("Malha do Character nao foi atribuida em ") + Path;
                return false;
            }
            Blueprint->MarkPackageDirty();
        }
        if (!UEMasterBridge::SaveAsset(Blueprint, Error))
        { Error += TEXT(" Character em memoria: ") + Path; return false; }
        Result->SetStringField(TEXT("asset_path"), Path);
        Result->SetStringField(TEXT("skeletal_mesh_path"),
            Asset ? Asset->GetPathName() : TEXT(""));
        Result->SetBoolField(TEXT("has_third_person_camera"), bCamera);
        Result->SetNumberField(TEXT("warnings"), CompileLog.NumWarnings);
        return true;
    }

    struct FObjectComponentSpec
    {
        FString Name;
        FString Kind;
        FVector Location = FVector::ZeroVector;
        FVector Extent = FVector(50, 50, 50);
        UStaticMesh* Mesh = nullptr;
        double Intensity = 1000.0;
    };

    struct FObjectVariableSpec
    {
        FString Name;
        FString Type;
        FString DefaultValue;
        bool bInstanceEditable = true;
    };

    bool ReadObjectVariableDefault(const UBlueprint* Blueprint, const FName VariableName,
                                   FString& Value)
    {
        UClass* GeneratedClass = Blueprint ? Blueprint->GeneratedClass : nullptr;
        const UObject* Defaults = GeneratedClass ? GeneratedClass->GetDefaultObject() : nullptr;
        const FProperty* Property = GeneratedClass
            ? GeneratedClass->FindPropertyByName(VariableName) : nullptr;
        if (!Defaults || !Property) return false;

        if (const FBoolProperty* Bool = CastField<FBoolProperty>(Property))
            Value = Bool->GetPropertyValue_InContainer(Defaults) ? TEXT("true") : TEXT("false");
        else if (const FIntProperty* Integer = CastField<FIntProperty>(Property))
            Value = FString::FromInt(Integer->GetPropertyValue_InContainer(Defaults));
        else if (const FFloatProperty* Float = CastField<FFloatProperty>(Property))
            Value = FString::SanitizeFloat(Float->GetPropertyValue_InContainer(Defaults));
        else if (const FStrProperty* String = CastField<FStrProperty>(Property))
            Value = String->GetPropertyValue_InContainer(Defaults);
        else
            return false;
        return true;
    }

    bool WriteObjectVariableDefault(UBlueprint* Blueprint, const FObjectVariableSpec& Spec)
    {
        UClass* GeneratedClass = Blueprint ? Blueprint->GeneratedClass : nullptr;
        UObject* Defaults = GeneratedClass ? GeneratedClass->GetDefaultObject() : nullptr;
        FProperty* Property = GeneratedClass
            ? GeneratedClass->FindPropertyByName(FName(*Spec.Name)) : nullptr;
        if (!Defaults || !Property) return false;

        if (Spec.Type == TEXT("bool"))
        {
            FBoolProperty* Bool = CastField<FBoolProperty>(Property);
            if (!Bool) return false;
            Bool->SetPropertyValue_InContainer(Defaults, Spec.DefaultValue == TEXT("true"));
        }
        else if (Spec.Type == TEXT("int"))
        {
            FIntProperty* Integer = CastField<FIntProperty>(Property);
            if (!Integer) return false;
            Integer->SetPropertyValue_InContainer(Defaults, FCString::Atoi(*Spec.DefaultValue));
        }
        else if (Spec.Type == TEXT("float"))
        {
            FFloatProperty* Float = CastField<FFloatProperty>(Property);
            if (!Float) return false;
            Float->SetPropertyValue_InContainer(Defaults, FCString::Atof(*Spec.DefaultValue));
        }
        else if (Spec.Type == TEXT("string"))
        {
            FStrProperty* String = CastField<FStrProperty>(Property);
            if (!String) return false;
            String->SetPropertyValue_InContainer(Defaults, Spec.DefaultValue);
        }
        else
            return false;
        return true;
    }

    bool ObjectDetails(const TSharedPtr<FJsonObject>& Request,
                       const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        FString Path;
        if (!Request->TryGetStringField(TEXT("object_path"), Path) ||
            !Path.StartsWith(TEXT("/Game/Objects/")) ||
            !UEMasterBridge::IsProjectContentPath(Path) || Path.Contains(TEXT(".")))
        {
            Error = TEXT("Informe object_path em /Game/Objects/, sem sufixo .uasset.");
            return false;
        }
        UBlueprint* Blueprint = LoadObject<UBlueprint>(nullptr, *UEMasterBridge::ObjectPath(Path));
        if (!Blueprint || !Blueprint->ParentClass ||
            !Blueprint->ParentClass->IsChildOf(AActor::StaticClass()) ||
            !Blueprint->SimpleConstructionScript)
        {
            Error = TEXT("Blueprint de Actor nao encontrado: ") + Path;
            return false;
        }

        TArray<TSharedPtr<FJsonValue>> Components;
        for (USCS_Node* Node : Blueprint->SimpleConstructionScript->GetAllNodes())
        {
            if (!Node || !Node->ComponentTemplate || Components.Num() >= 24) continue;
            const TSharedRef<FJsonObject> Entry = MakeShared<FJsonObject>();
            Entry->SetStringField(TEXT("name"), Node->GetVariableName().ToString());
            Entry->SetStringField(TEXT("class"), Node->ComponentTemplate->GetClass()->GetName());
            Entry->SetBoolField(TEXT("is_root"), Node->IsRootNode());
            if (const USceneComponent* Scene = Cast<USceneComponent>(Node->ComponentTemplate))
                Entry->SetObjectField(TEXT("location"), UEMasterBridge::VectorJson(Scene->GetRelativeLocation()));
            if (const UStaticMeshComponent* Static = Cast<UStaticMeshComponent>(Node->ComponentTemplate))
                if (const UStaticMesh* Mesh = Static->GetStaticMesh())
                    Entry->SetStringField(TEXT("mesh_path"), Mesh->GetPathName());
            if (const UBoxComponent* Box = Cast<UBoxComponent>(Node->ComponentTemplate))
                Entry->SetObjectField(TEXT("box_extent"), UEMasterBridge::VectorJson(Box->GetUnscaledBoxExtent()));
            Components.Add(MakeShared<FJsonValueObject>(Entry));
        }
        TArray<TSharedPtr<FJsonValue>> Variables;
        for (const FBPVariableDescription& Variable : Blueprint->NewVariables)
        {
            if (Variables.Num() >= 24) break;
            const TSharedRef<FJsonObject> Entry = MakeShared<FJsonObject>();
            Entry->SetStringField(TEXT("name"), Variable.VarName.ToString());
            Entry->SetStringField(TEXT("type"), Variable.VarType.PinCategory.ToString());
            FString DefaultValue;
            const bool bReadClassDefault = ReadObjectVariableDefault(
                Blueprint, Variable.VarName, DefaultValue);
            Entry->SetStringField(TEXT("default"),
                bReadClassDefault ? DefaultValue : Variable.DefaultValue);
            Entry->SetStringField(TEXT("default_source"),
                bReadClassDefault ? TEXT("class_default") : TEXT("description"));
            Entry->SetBoolField(TEXT("instance_editable"),
                (Variable.PropertyFlags & CPF_DisableEditOnInstance) == 0);
            Variables.Add(MakeShared<FJsonValueObject>(Entry));
        }
        Result->SetStringField(TEXT("object_path"), Path);
        Result->SetBoolField(TEXT("compiled"), Blueprint->Status == BS_UpToDate ||
            Blueprint->Status == BS_UpToDateWithWarnings);
        Result->SetArrayField(TEXT("components"), Components);
        Result->SetArrayField(TEXT("variables"), Variables);
        return true;
    }

    bool CreateObject(const TSharedPtr<FJsonObject>& Request,
                      const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        FString Name;
        const TArray<TSharedPtr<FJsonValue>>* Components = nullptr;
        const TArray<TSharedPtr<FJsonValue>>* Variables = nullptr;
        if (!Request->TryGetStringField(TEXT("name"), Name) ||
            !UEMasterBridge::IsIdentifier(Name) ||
            !Request->TryGetArrayField(TEXT("components"), Components) ||
            !Components || Components->IsEmpty() || Components->Num() > 12 ||
            !Request->TryGetArrayField(TEXT("variables"), Variables) ||
            !Variables || Variables->Num() > 16)
        {
            Error = TEXT("Informe name valido, components (1 a 12) e variables (0 a 16).");
            return false;
        }
        if (Request->Values.Num() != 4 + (Request->HasField(TEXT("id")) ? 1 : 0))
        {
            Error = TEXT("create_object aceita somente name, components e variables.");
            return false;
        }
        const FString Path = TEXT("/Game/Objects/") + Name;
        if (!UEMasterBridge::IsWritableAsset(Path) ||
            FPackageName::DoesPackageExist(Path, nullptr, false) ||
            FindObject<UObject>(nullptr, *UEMasterBridge::ObjectPath(Path)))
        {
            Error = TEXT("Destino ocupado ou invalido em /Game/Objects/: ") + Path;
            return false;
        }

        TSet<FName> UsedNames;
        UsedNames.Add(FName(TEXT("SceneRoot")));
        TArray<FObjectComponentSpec> ComponentSpecs;
        for (const TSharedPtr<FJsonValue>& Value : *Components)
        {
            const TSharedPtr<FJsonObject> Entry = Value.IsValid() && Value->Type == EJson::Object
                ? Value->AsObject() : nullptr;
            FObjectComponentSpec Spec;
            if (!Entry.IsValid() ||
                !Entry->TryGetStringField(TEXT("name"), Spec.Name) ||
                !UEMasterBridge::IsIdentifier(Spec.Name) || UsedNames.Contains(FName(*Spec.Name)) ||
                AActor::StaticClass()->FindPropertyByName(FName(*Spec.Name)) ||
                !Entry->TryGetStringField(TEXT("kind"), Spec.Kind))
            {
                Error = TEXT("Cada componente precisa de name exclusivo e kind valido.");
                return false;
            }
            const TSharedPtr<FJsonObject>* Position = nullptr;
            if (Entry->HasField(TEXT("location")) &&
                (!Entry->TryGetObjectField(TEXT("location"), Position) || !Position ||
                 !UEMasterBridge::ReadVector3(*Position, Spec.Location, -100000, 100000)))
            {
                Error = TEXT("location requer x, y e z finitos em centimetros.");
                return false;
            }
            if (Spec.Kind == TEXT("StaticMesh"))
            {
                FString MeshPath;
                if (!Entry->TryGetStringField(TEXT("mesh_path"), MeshPath) ||
                    !UEMasterBridge::IsAssetPath(MeshPath) ||
                    !(Spec.Mesh = LoadObject<UStaticMesh>(nullptr, *UEMasterBridge::ObjectPath(MeshPath))))
                {
                    Error = TEXT("StaticMesh requer mesh_path existente em /Game ou /Engine.");
                    return false;
                }
            }
            else if (Spec.Kind == TEXT("BoxCollision"))
            {
                const TSharedPtr<FJsonObject>* Extent = nullptr;
                if (Entry->HasField(TEXT("box_extent")) &&
                    (!Entry->TryGetObjectField(TEXT("box_extent"), Extent) || !Extent ||
                     !UEMasterBridge::ReadVector3(*Extent, Spec.Extent, 0.1, 100000)))
                {
                    Error = TEXT("box_extent requer x, y e z positivos em centimetros.");
                    return false;
                }
            }
            else if (Spec.Kind == TEXT("PointLight"))
            {
                if (Entry->HasField(TEXT("intensity")) &&
                    !UEMasterBridge::ReadNumber(Entry, TEXT("intensity"), Spec.Intensity, 0, 1000000))
                {
                    Error = TEXT("intensity deve ser um numero finito entre 0 e 1000000.");
                    return false;
                }
            }
            else if (Spec.Kind != TEXT("ScenePoint"))
            {
                Error = TEXT("kind aceita StaticMesh, BoxCollision, ScenePoint ou PointLight.");
                return false;
            }
            int32 AllowedFields = 2 + (Entry->HasField(TEXT("location")) ? 1 : 0);
            if (Spec.Kind == TEXT("StaticMesh")) ++AllowedFields;
            if (Spec.Kind == TEXT("BoxCollision") && Entry->HasField(TEXT("box_extent"))) ++AllowedFields;
            if (Spec.Kind == TEXT("PointLight") && Entry->HasField(TEXT("intensity"))) ++AllowedFields;
            if (Entry->Values.Num() != AllowedFields)
            {
                Error = TEXT("Componente contem campos nao suportados para o kind selecionado.");
                return false;
            }
            UsedNames.Add(FName(*Spec.Name));
            ComponentSpecs.Add(Spec);
        }

        TArray<FObjectVariableSpec> VariableSpecs;
        for (const TSharedPtr<FJsonValue>& Value : *Variables)
        {
            const TSharedPtr<FJsonObject> Entry = Value.IsValid() && Value->Type == EJson::Object
                ? Value->AsObject() : nullptr;
            FObjectVariableSpec Spec;
            if (!Entry.IsValid() || !Entry->TryGetStringField(TEXT("name"), Spec.Name) ||
                !UEMasterBridge::IsIdentifier(Spec.Name) || UsedNames.Contains(FName(*Spec.Name)) ||
                AActor::StaticClass()->FindPropertyByName(FName(*Spec.Name)) ||
                !Entry->TryGetStringField(TEXT("type"), Spec.Type) ||
                !Entry->HasField(TEXT("default")) || Entry->Values.Num() !=
                    3 + (Entry->HasField(TEXT("instance_editable")) ? 1 : 0))
            {
                Error = TEXT("Variavel requer name exclusivo, type, default e opcional instance_editable.");
                return false;
            }
            if (Entry->HasField(TEXT("instance_editable")) &&
                !Entry->TryGetBoolField(TEXT("instance_editable"), Spec.bInstanceEditable))
            {
                Error = TEXT("instance_editable deve ser booleano.");
                return false;
            }
            if (Spec.Type == TEXT("bool"))
            {
                bool Default = false;
                if (!Entry->TryGetBoolField(TEXT("default"), Default))
                { Error = TEXT("default de bool deve ser booleano."); return false; }
                Spec.DefaultValue = Default ? TEXT("true") : TEXT("false");
            }
            else if (Spec.Type == TEXT("int") || Spec.Type == TEXT("float"))
            {
                double Default = 0;
                if (!UEMasterBridge::ReadNumber(Entry, TEXT("default"), Default, -1000000, 1000000) ||
                    (Spec.Type == TEXT("int") && Default != static_cast<double>(static_cast<int32>(Default))))
                { Error = TEXT("default numerico invalido (int inteiro; float finito)."); return false; }
                Spec.DefaultValue = Spec.Type == TEXT("int")
                    ? FString::FromInt(static_cast<int32>(Default)) : FString::SanitizeFloat(Default);
            }
            else if (Spec.Type == TEXT("string"))
            {
                if (!Entry->TryGetStringField(TEXT("default"), Spec.DefaultValue) ||
                    Spec.DefaultValue.Len() > 256)
                { Error = TEXT("default de string deve ter ate 256 caracteres."); return false; }
            }
            else
            { Error = TEXT("type aceita bool, int, float ou string."); return false; }
            UsedNames.Add(FName(*Spec.Name));
            VariableSpecs.Add(Spec);
        }

        TStrongObjectPtr<UBlueprintFactory> Factory(NewObject<UBlueprintFactory>());
        Factory->ParentClass = AActor::StaticClass();
        Factory->bSkipClassPicker = true;
        UBlueprint* Blueprint = Cast<UBlueprint>(FAssetToolsModule::GetModule().Get().CreateAsset(
            Name, TEXT("/Game/Objects"), UBlueprint::StaticClass(), Factory.Get(),
            FName(TEXT("UEMasterBridge")), false));
        if (!Blueprint || !Blueprint->SimpleConstructionScript)
        {
            Error = TEXT("Falha ao criar o Blueprint de objeto. Confira /Game/Objects no Editor.");
            return false;
        }
        USimpleConstructionScript* SCS = Blueprint->SimpleConstructionScript;
        Blueprint->Modify();
        SCS->Modify();
        USCS_Node* Root = nullptr;
        const FName RootName(TEXT("SceneRoot"));
        // BlueprintFactory may initialize the Actor Blueprint with a default SCS root.
        // Reuse that root so the object has exactly one scene root in either case.
        if (SCS->GetRootNodes().Num() == 1)
        {
            Root = SCS->GetRootNodes()[0];
            if (!Root || !Cast<USceneComponent>(Root->ComponentTemplate) ||
                !Root->GetChildNodes().IsEmpty())
            {
                Error = TEXT("Blueprint criado com raiz nao reutilizavel em ") + Path +
                    TEXT("; inspecione o Blueprint no Editor.");
                return false;
            }
            Root->Modify();
            Root->ComponentTemplate->Modify();
            if (Root->GetVariableName() != RootName)
            {
                Root->SetVariableName(RootName, true);
                if (Root->GetVariableName() != RootName)
                {
                    Error = TEXT("Falha ao nomear a raiz SceneRoot em ") + Path;
                    return false;
                }
            }
        }
        else if (SCS->GetRootNodes().IsEmpty())
        {
            Root = SCS->CreateNode(USceneComponent::StaticClass(), RootName);
            if (!Root)
            { Error = TEXT("Falha ao criar SceneRoot em ") + Path; return false; }
            SCS->AddNode(Root);
        }
        else
        {
            Error = TEXT("Blueprint criado com mais de uma raiz em ") + Path;
            return false;
        }
        for (const FObjectComponentSpec& Spec : ComponentSpecs)
        {
            UClass* Class = Spec.Kind == TEXT("StaticMesh") ? UStaticMeshComponent::StaticClass() :
                Spec.Kind == TEXT("BoxCollision") ? UBoxComponent::StaticClass() :
                Spec.Kind == TEXT("PointLight") ? UPointLightComponent::StaticClass() :
                USceneComponent::StaticClass();
            USCS_Node* Node = SCS->CreateNode(Class, FName(*Spec.Name));
            USceneComponent* Template = Node ? Cast<USceneComponent>(Node->ComponentTemplate) : nullptr;
            if (!Template)
            { Error = TEXT("Falha ao criar componente em ") + Path + TEXT(": ") + Spec.Name; return false; }
            Template->SetRelativeLocation(Spec.Location);
            if (UStaticMeshComponent* Static = Cast<UStaticMeshComponent>(Template))
                Static->SetStaticMesh(Spec.Mesh);
            if (UBoxComponent* Box = Cast<UBoxComponent>(Template))
            {
                Box->SetBoxExtent(Spec.Extent);
                Box->SetCollisionProfileName(FName(TEXT("Trigger")));
            }
            if (UPointLightComponent* Light = Cast<UPointLightComponent>(Template))
                Light->SetIntensity(Spec.Intensity);
            Root->AddChildNode(Node, true);
        }
        for (const FObjectVariableSpec& Spec : VariableSpecs)
        {
            FEdGraphPinType Pin;
            if (Spec.Type == TEXT("bool")) Pin.PinCategory = UEdGraphSchema_K2::PC_Boolean;
            else if (Spec.Type == TEXT("int")) Pin.PinCategory = UEdGraphSchema_K2::PC_Int;
            else if (Spec.Type == TEXT("string")) Pin.PinCategory = UEdGraphSchema_K2::PC_String;
            else
            {
                Pin.PinCategory = UEdGraphSchema_K2::PC_Real;
                Pin.PinSubCategory = UEdGraphSchema_K2::PC_Float;
            }
            if (!FBlueprintEditorUtils::AddMemberVariable(Blueprint, FName(*Spec.Name),
                    Pin, Spec.DefaultValue))
            { Error = TEXT("Falha ao criar variavel em ") + Path + TEXT(": ") + Spec.Name; return false; }
            UBlueprintEditorLibrary::SetBlueprintVariableInstanceEditable(
                Blueprint, FName(*Spec.Name), Spec.bInstanceEditable);
        }
        // The editor may compile when changing instance editability. Reapply the
        // requested defaults to the variable descriptions before the final compile.
        for (const FObjectVariableSpec& Spec : VariableSpecs)
        {
            FBPVariableDescription* Description = Blueprint->NewVariables.FindByPredicate(
                [&Spec](const FBPVariableDescription& Variable) {
                    return Variable.VarName == FName(*Spec.Name);
                });
            if (!Description)
            {
                Error = TEXT("Variavel criada sem descricao em ") + Path + TEXT(": ") + Spec.Name;
                return false;
            }
            Description->DefaultValue = Spec.DefaultValue;
        }
        FBlueprintEditorUtils::MarkBlueprintAsStructurallyModified(Blueprint);
        FCompilerResultsLog CompileLog(false);
        FKismetEditorUtilities::CompileBlueprint(Blueprint, EBlueprintCompileOptions::None, &CompileLog);
        if (CompileLog.NumErrors > 0 ||
            (Blueprint->Status != BS_UpToDate && Blueprint->Status != BS_UpToDateWithWarnings))
        {
            Error = FString::Printf(TEXT("Falha ao compilar %s (%d erros); inspecione o asset no Editor."),
                *Path, CompileLog.NumErrors);
            return false;
        }
        UObject* Defaults = Blueprint->GeneratedClass
            ? Blueprint->GeneratedClass->GetDefaultObject() : nullptr;
        if (VariableSpecs.Num() > 0 && !Defaults)
        {
            Error = TEXT("Blueprint sem valores padrao compilados em ") + Path;
            return false;
        }
        if (Defaults) Defaults->Modify();
        for (const FObjectVariableSpec& Spec : VariableSpecs)
        {
            if (!WriteObjectVariableDefault(Blueprint, Spec))
            {
                Error = TEXT("Falha ao gravar valor padrao em ") + Path + TEXT(": ") + Spec.Name;
                return false;
            }
            FString Actual;
            if (!ReadObjectVariableDefault(Blueprint, FName(*Spec.Name), Actual) ||
                (Spec.Type == TEXT("float")
                    ? !FMath::IsNearlyEqual(FCString::Atof(*Actual),
                        FCString::Atof(*Spec.DefaultValue), 0.0001f)
                    : Actual != Spec.DefaultValue))
            {
                Error = TEXT("Valor padrao compilado divergente em ") + Path +
                    TEXT(": ") + Spec.Name;
                return false;
            }
        }
        if (Defaults && VariableSpecs.Num() > 0) Defaults->MarkPackageDirty();
        if (!UEMasterBridge::SaveAsset(Blueprint, Error))
        { Error += TEXT(" Caminho: ") + Path; return false; }
        Result->SetStringField(TEXT("asset_path"), Path);
        Result->SetNumberField(TEXT("warnings"), CompileLog.NumWarnings);
        Result->SetNumberField(TEXT("total_components"), ComponentSpecs.Num() + 1);
        Result->SetNumberField(TEXT("total_variables"), VariableSpecs.Num());
        return true;
    }

    struct FGraphLogicStep
    {
        FString Kind;
        FString Variable;
        FString DefaultValue;
        FString Message;
    };

    bool ReadGraphVariable(UBlueprint* Blueprint, const TSharedPtr<FJsonObject>& Json,
                           const FString& Variable, FString& DefaultValue, FString& Error)
    {
        if (!UEMasterBridge::IsIdentifier(Variable) || !Blueprint->NewVariables.ContainsByPredicate(
                [&Variable](const FBPVariableDescription& Item) {
                    return Item.VarName == FName(*Variable);
                }))
        {
            Error = TEXT("Variavel local nao encontrada no Blueprint: ") + Variable;
            return false;
        }
        const FProperty* Property = Blueprint->GeneratedClass
            ? Blueprint->GeneratedClass->FindPropertyByName(FName(*Variable)) : nullptr;
        if (CastField<FBoolProperty>(Property))
        {
            bool Value = false;
            if (!Json->TryGetBoolField(TEXT("value"), Value))
            { Error = TEXT("value precisa ser bool em ") + Variable; return false; }
            DefaultValue = Value ? TEXT("true") : TEXT("false");
        }
        else if (CastField<FIntProperty>(Property) || CastField<FFloatProperty>(Property))
        {
            double Value = 0;
            if (!UEMasterBridge::ReadNumber(Json, TEXT("value"), Value, -1000000, 1000000) ||
                (CastField<FIntProperty>(Property) &&
                 Value != static_cast<double>(static_cast<int32>(Value))))
            { Error = TEXT("value numerico invalido em ") + Variable; return false; }
            DefaultValue = CastField<FIntProperty>(Property)
                ? FString::FromInt(static_cast<int32>(Value)) : FString::SanitizeFloat(Value);
        }
        else if (CastField<FStrProperty>(Property))
        {
            if (!Json->TryGetStringField(TEXT("value"), DefaultValue) ||
                DefaultValue.Len() > 256)
            { Error = TEXT("value precisa ser string de ate 256 caracteres em ") + Variable; return false; }
        }
        else
        {
            Error = TEXT("Tipo de variavel nao suportado no grafo: ") + Variable;
            return false;
        }
        return true;
    }

    bool GetBlueprintLogic(const TSharedPtr<FJsonObject>& Request,
                           const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        FString Path, EventName;
        if (!Request->TryGetStringField(TEXT("blueprint_path"), Path) ||
            !UEMasterBridge::IsProjectContentPath(Path) || Path.Contains(TEXT(".")) ||
            !Request->TryGetStringField(TEXT("event_name"), EventName) ||
            !UEMasterBridge::IsIdentifier(EventName) ||
            Request->Values.Num() != 3 + (Request->HasField(TEXT("id")) ? 1 : 0))
        {
            Error = TEXT("Informe blueprint_path em /Game/ e event_name valido.");
            return false;
        }
        UBlueprint* Blueprint = LoadObject<UBlueprint>(nullptr, *UEMasterBridge::ObjectPath(Path));
        UEdGraph* Graph = Blueprint ? FBlueprintEditorUtils::FindEventGraph(Blueprint) : nullptr;
        UK2Node_Event* Event = Blueprint
            ? FBlueprintEditorUtils::FindCustomEventNode(Blueprint, FName(*EventName)) : nullptr;
        if (!Graph || !Event || Event->GetGraph() != Graph)
        { Error = TEXT("Evento personalizado nao encontrado em ") + Path + TEXT(": ") + EventName; return false; }

        TArray<UEdGraphNode*> Queue;
        TSet<UEdGraphNode*> Seen;
        Queue.Add(Event);
        Seen.Add(Event);
        TArray<TSharedPtr<FJsonValue>> Nodes;
        for (int32 Index = 0; Index < Queue.Num(); ++Index)
        {
            UEdGraphNode* Node = Queue[Index];
            const TSharedRef<FJsonObject> Entry = MakeShared<FJsonObject>();
            Entry->SetStringField(TEXT("id"), Node->NodeGuid.ToString());
            Entry->SetStringField(TEXT("kind"), Node->GetClass()->GetName());
            if (const UK2Node_Variable* Variable = Cast<UK2Node_Variable>(Node))
                Entry->SetStringField(TEXT("variable"), Variable->VariableReference.GetMemberName().ToString());
            if (const UK2Node_Event* Custom = Cast<UK2Node_Event>(Node))
                Entry->SetStringField(TEXT("event_name"), Custom->GetFunctionName().ToString());
            TArray<TSharedPtr<FJsonValue>> Pins;
            for (const UEdGraphPin* Pin : Node->Pins)
            {
                if (!Pin) continue;
                const TSharedRef<FJsonObject> PinEntry = MakeShared<FJsonObject>();
                PinEntry->SetStringField(TEXT("name"), Pin->PinName.ToString());
                PinEntry->SetStringField(TEXT("direction"),
                    Pin->Direction == EGPD_Input ? TEXT("input") : TEXT("output"));
                PinEntry->SetStringField(TEXT("type"), Pin->PinType.PinCategory.ToString());
                if (Pin->Direction == EGPD_Input && Pin->LinkedTo.IsEmpty())
                    PinEntry->SetStringField(TEXT("default"), Pin->DefaultValue);
                TArray<TSharedPtr<FJsonValue>> Links;
                for (const UEdGraphPin* Linked : Pin->LinkedTo)
                {
                    UEdGraphNode* LinkedNode = Linked ? Linked->GetOwningNode() : nullptr;
                    if (!LinkedNode || LinkedNode->GetGraph() != Graph) continue;
                    const TSharedRef<FJsonObject> Target = MakeShared<FJsonObject>();
                    Target->SetStringField(TEXT("node"), LinkedNode->NodeGuid.ToString());
                    Target->SetStringField(TEXT("pin"), Linked->PinName.ToString());
                    Links.Add(MakeShared<FJsonValueObject>(Target));
                    if (!Seen.Contains(LinkedNode))
                    {
                        if (Queue.Num() >= 24)
                        { Error = TEXT("Evento excede 24 nos; inspecione diretamente no Editor."); return false; }
                        Seen.Add(LinkedNode);
                        Queue.Add(LinkedNode);
                    }
                }
                PinEntry->SetArrayField(TEXT("links"), Links);
                Pins.Add(MakeShared<FJsonValueObject>(PinEntry));
            }
            Entry->SetArrayField(TEXT("pins"), Pins);
            Nodes.Add(MakeShared<FJsonValueObject>(Entry));
        }
        Result->SetStringField(TEXT("blueprint_path"), Path);
        Result->SetStringField(TEXT("event_name"), EventName);
        Result->SetBoolField(TEXT("compiled"), Blueprint->Status == BS_UpToDate ||
            Blueprint->Status == BS_UpToDateWithWarnings);
        Result->SetArrayField(TEXT("nodes"), Nodes);
        return true;
    }

    bool CreateBlueprintLogic(const TSharedPtr<FJsonObject>& Request,
                              const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        FString Path, EventName;
        const TArray<TSharedPtr<FJsonValue>>* StepsJson = nullptr;
        if (!Request->TryGetStringField(TEXT("blueprint_path"), Path) ||
            !UEMasterBridge::IsWritableAsset(Path) ||
            !Request->TryGetStringField(TEXT("event_name"), EventName) ||
            !UEMasterBridge::IsIdentifier(EventName) ||
            !Request->TryGetArrayField(TEXT("steps"), StepsJson) || !StepsJson ||
            StepsJson->IsEmpty() || StepsJson->Num() > 12 ||
            Request->Values.Num() != 4 + (Request->HasField(TEXT("id")) ? 1 : 0) +
                (Request->HasField(TEXT("condition")) ? 1 : 0))
        {
            Error = TEXT("Informe blueprint_path, event_name e steps (1 a 12).");
            return false;
        }
        UBlueprint* Blueprint = LoadObject<UBlueprint>(nullptr, *UEMasterBridge::ObjectPath(Path));
        if (!Blueprint || !Blueprint->ParentClass ||
            !Blueprint->ParentClass->IsChildOf(AActor::StaticClass()) ||
            !Blueprint->GeneratedClass ||
            (Blueprint->Status != BS_UpToDate && Blueprint->Status != BS_UpToDateWithWarnings) ||
            Blueprint->GetOutermost()->IsDirty())
        {
            Error = TEXT("Salve e compile um Blueprint Actor valido antes de criar o grafo: ") + Path;
            return false;
        }
        if (FBlueprintEditorUtils::FindCustomEventNode(Blueprint, FName(*EventName)) ||
            !FBlueprintEditorUtils::IsGraphNameUnique(Blueprint, FName(*EventName)) ||
            Blueprint->GeneratedClass->FindFunctionByName(FName(*EventName)) ||
            Blueprint->ParentClass->FindFunctionByName(FName(*EventName)))
        {
            Error = TEXT("Nome de evento ja usado no Blueprint: ") + EventName;
            return false;
        }

        FString ConditionVariable;
        bool bConditionEquals = false;
        if (Request->HasField(TEXT("condition")))
        {
            const TSharedPtr<FJsonObject>* Condition = nullptr;
            if (!Request->TryGetObjectField(TEXT("condition"), Condition) || !Condition ||
                !(*Condition).IsValid() || (*Condition)->Values.Num() != 2 ||
                !(*Condition)->TryGetStringField(TEXT("variable"), ConditionVariable) ||
                !UEMasterBridge::IsIdentifier(ConditionVariable) ||
                !(*Condition)->TryGetBoolField(TEXT("equals"), bConditionEquals) ||
                !Blueprint->NewVariables.ContainsByPredicate(
                    [&ConditionVariable](const FBPVariableDescription& Item) {
                        return Item.VarName == FName(*ConditionVariable);
                    }) ||
                !CastField<FBoolProperty>(Blueprint->GeneratedClass->FindPropertyByName(
                    FName(*ConditionVariable))))
            {
                Error = TEXT("condition requer variable bool local e equals booleano.");
                return false;
            }
        }

        TArray<FGraphLogicStep> Steps;
        for (const TSharedPtr<FJsonValue>& Value : *StepsJson)
        {
            const TSharedPtr<FJsonObject> Item = Value.IsValid() && Value->Type == EJson::Object
                ? Value->AsObject() : nullptr;
            FGraphLogicStep Step;
            if (!Item.IsValid() || !Item->TryGetStringField(TEXT("kind"), Step.Kind))
            { Error = TEXT("Cada step precisa de kind."); return false; }
            if (Step.Kind == TEXT("set_variable"))
            {
                if (Item->Values.Num() != 3 ||
                    !Item->TryGetStringField(TEXT("name"), Step.Variable) ||
                    !Item->HasField(TEXT("value")))
                { Error = TEXT("set_variable requer name e value."); return false; }
                if (!ReadGraphVariable(Blueprint, Item, Step.Variable, Step.DefaultValue, Error))
                    return false;
            }
            else if (Step.Kind == TEXT("print_string"))
            {
                if (Item->Values.Num() != 2 ||
                    !Item->TryGetStringField(TEXT("message"), Step.Message) ||
                    Step.Message.Len() > 256)
                { Error = TEXT("print_string requer message de ate 256 caracteres."); return false; }
            }
            else
            { Error = TEXT("kind permite set_variable ou print_string."); return false; }
            Steps.Add(MoveTemp(Step));
        }

        FScopedTransaction Transaction(FText::FromString(TEXT("UE Master Bridge: criar logica Blueprint")));
        Blueprint->Modify();
        UEdGraph* Graph = FBlueprintEditorUtils::FindEventGraph(Blueprint);
        const bool bCreatedGraph = Graph == nullptr;
        if (!Graph)
        {
            Graph = FBlueprintEditorUtils::CreateNewGraph(Blueprint,
                UEdGraphSchema_K2::GN_EventGraph, UEdGraph::StaticClass(),
                UEdGraphSchema_K2::StaticClass());
            if (!Graph)
            { Error = TEXT("Falha ao criar EventGraph em ") + Path; Transaction.Cancel(); return false; }
            FBlueprintEditorUtils::AddUbergraphPage(Blueprint, Graph);
        }
        Graph->Modify();
        const UEdGraphSchema* Schema = Graph->GetSchema();
        TArray<UEdGraphNode*> Added;
        auto Rollback = [&]() {
            if (bCreatedGraph)
                FBlueprintEditorUtils::RemoveGraph(Blueprint, Graph,
                    static_cast<EGraphRemoveFlags::Type>(0));
            else
                for (UEdGraphNode* Node : Added)
                    if (IsValid(Node)) Node->DestroyNode();
            FBlueprintEditorUtils::MarkBlueprintAsStructurallyModified(Blueprint);
            FKismetEditorUtilities::CompileBlueprint(Blueprint);
            Transaction.Cancel();
        };
        if (!Schema)
        { Error = TEXT("EventGraph sem schema em ") + Path; Rollback(); return false; }

        FGraphNodeCreator<UK2Node_CustomEvent> EventCreator(*Graph);
        UK2Node_CustomEvent* Event = EventCreator.CreateNode(false, UK2Node_CustomEvent::StaticClass());
        Event->CustomFunctionName = FName(*EventName);
        Event->NodePosX = 0;
        Event->NodePosY = Graph->Nodes.Num() * 160;
        EventCreator.Finalize();
        Added.Add(Event);
        if (Event->GetFunctionName() != FName(*EventName))
        {
            Error = TEXT("O Engine alterou o nome solicitado para o evento: ") + EventName;
            Rollback();
            return false;
        }
        UEdGraphPin* Previous = Event->GetThenPin();

        auto Connect = [&](UEdGraphPin* Output, UEdGraphPin* Input,
                           const FString& Context) -> bool {
            if (Output && Input && Schema->TryCreateConnection(Output, Input)) return true;
            Error = TEXT("Falha ao conectar pins em ") + Path + TEXT(": ") + Context;
            return false;
        };

        if (!ConditionVariable.IsEmpty())
        {
            FGraphNodeCreator<UK2Node_VariableGet> GetCreator(*Graph);
            UK2Node_VariableGet* Get = GetCreator.CreateNode(false, UK2Node_VariableGet::StaticClass());
            Get->VariableReference.SetSelfMember(FName(*ConditionVariable));
            Get->NodePosX = 220;
            Get->NodePosY = Event->NodePosY + 200;
            GetCreator.Finalize();
            Added.Add(Get);

            FGraphNodeCreator<UK2Node_IfThenElse> BranchCreator(*Graph);
            UK2Node_IfThenElse* Branch = BranchCreator.CreateNode(false, UK2Node_IfThenElse::StaticClass());
            Branch->NodePosX = 440;
            Branch->NodePosY = Event->NodePosY;
            BranchCreator.Finalize();
            Added.Add(Branch);
            if (!Connect(Previous, Branch->GetExecPin(), TEXT("evento > condicao")) ||
                !Connect(Get->FindPin(FName(*ConditionVariable), EGPD_Output),
                    Branch->GetConditionPin(), TEXT("bool > condicao")))
            { Rollback(); return false; }
            Previous = bConditionEquals ? Branch->GetThenPin() : Branch->GetElsePin();
        }

        const UFunction* PrintFunction = UKismetSystemLibrary::StaticClass()->FindFunctionByName(
            GET_FUNCTION_NAME_CHECKED(UKismetSystemLibrary, PrintString));
        for (int32 Index = 0; Index < Steps.Num(); ++Index)
        {
            const FGraphLogicStep& Step = Steps[Index];
            const int32 X = (ConditionVariable.IsEmpty() ? 280 : 720) + Index * 340;
            if (Step.Kind == TEXT("set_variable"))
            {
                FGraphNodeCreator<UK2Node_VariableSet> Creator(*Graph);
                UK2Node_VariableSet* Node = Creator.CreateNode(false, UK2Node_VariableSet::StaticClass());
                Node->VariableReference.SetSelfMember(FName(*Step.Variable));
                Node->NodePosX = X;
                Node->NodePosY = Event->NodePosY;
                Creator.Finalize();
                Added.Add(Node);
                UEdGraphPin* Input = Node->FindPin(FName(*Step.Variable), EGPD_Input);
                if (!Input || !Connect(Previous, Node->GetExecPin(), Step.Variable))
                { Rollback(); return false; }
                Schema->TrySetDefaultValue(*Input, Step.DefaultValue, false);
                Previous = Node->GetThenPin();
            }
            else
            {
                if (!PrintFunction)
                { Error = TEXT("PrintString indisponivel no Engine."); Rollback(); return false; }
                FGraphNodeCreator<UK2Node_CallFunction> Creator(*Graph);
                UK2Node_CallFunction* Node = Creator.CreateNode(false, UK2Node_CallFunction::StaticClass());
                Node->SetFromFunction(PrintFunction);
                Node->NodePosX = X;
                Node->NodePosY = Event->NodePosY;
                Creator.Finalize();
                Added.Add(Node);
                UEdGraphPin* Message = Node->FindPin(TEXT("InString"), EGPD_Input);
                if (!Message || !Connect(Previous, Node->GetExecPin(), TEXT("print_string")))
                { Rollback(); return false; }
                Schema->TrySetDefaultValue(*Message, Step.Message, false);
                Previous = Node->GetThenPin();
            }
        }
        FBlueprintEditorUtils::MarkBlueprintAsStructurallyModified(Blueprint);
        FCompilerResultsLog CompileLog(false);
        FKismetEditorUtilities::CompileBlueprint(Blueprint, EBlueprintCompileOptions::None, &CompileLog);
        if (CompileLog.NumErrors > 0 ||
            (Blueprint->Status != BS_UpToDate && Blueprint->Status != BS_UpToDateWithWarnings))
        {
            Error = FString::Printf(TEXT("Evento %s falhou na compilacao (%d erros); nenhuma mudanca salva."),
                *EventName, CompileLog.NumErrors);
            Rollback();
            return false;
        }
        if (!UEMasterBridge::SaveAsset(Blueprint, Error))
        { Error += TEXT(" Blueprint alterado em memoria: ") + Path; return false; }
        Result->SetStringField(TEXT("blueprint_path"), Path);
        Result->SetStringField(TEXT("event_name"), EventName);
        Result->SetNumberField(TEXT("created_nodes"), Added.Num());
        Result->SetNumberField(TEXT("warnings"), CompileLog.NumWarnings);
        return true;
    }

    bool AddThirdPersonCamera(const TSharedPtr<FJsonObject>& Request,
                              const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        FString AssetPath;
        if (!Request->TryGetStringField(TEXT("blueprint_path"), AssetPath) ||
            !UEMasterBridge::IsProjectContentPath(AssetPath))
        {
            Error = TEXT("Informe blueprint_path, por exemplo /Game/Blueprints/BP_Player.");
            return false;
        }
        const FString ObjectPath = AssetPath + TEXT(".") + FPackageName::GetShortName(AssetPath);
        UBlueprint* Blueprint = LoadObject<UBlueprint>(nullptr, *ObjectPath);
        if (!Blueprint)
        {
            Error = TEXT("Blueprint nao encontrado: ") + AssetPath;
            return false;
        }
        if (!Blueprint->ParentClass || !Blueprint->ParentClass->IsChildOf(APawn::StaticClass()))
        {
            Error = TEXT("A camera de terceira pessoa requer um Blueprint de Pawn ou Character.");
            return false;
        }
        USimpleConstructionScript* SCS = Blueprint->SimpleConstructionScript;
        if (!SCS)
        {
            Error = TEXT("O Blueprint nao possui Simple Construction Script.");
            return false;
        }
        const FName BoomName(TEXT("UEMasterCameraBoom"));
        const FName CameraName(TEXT("UEMasterFollowCamera"));
        if (SCS->FindSCSNode(BoomName) || SCS->FindSCSNode(CameraName))
        {
            Error = TEXT("O Blueprint ja possui componentes UEMasterCameraBoom ou UEMasterFollowCamera.");
            return false;
        }

        Blueprint->Modify();
        SCS->Modify();
        USCS_Node* Boom = SCS->CreateNode(USpringArmComponent::StaticClass(), BoomName);
        USCS_Node* Camera = SCS->CreateNode(UCameraComponent::StaticClass(), CameraName);
        if (!Boom || !Camera)
        {
            Error = TEXT("Falha ao criar os componentes da camera.");
            return false;
        }
        USpringArmComponent* BoomTemplate = CastChecked<USpringArmComponent>(Boom->ComponentTemplate);
        UCameraComponent* CameraTemplate = CastChecked<UCameraComponent>(Camera->ComponentTemplate);
        BoomTemplate->TargetArmLength = 300.0f;
        BoomTemplate->bUsePawnControlRotation = true;
        BoomTemplate->SetRelativeLocation(FVector(0.0, 0.0, 60.0));
        CameraTemplate->bUsePawnControlRotation = false;
        CameraTemplate->SetAutoActivate(true);
        Camera->AttachToName = USpringArmComponent::SocketName;

        // Root SCS nodes attach to a native root (e.g. Character capsule) automatically.
        // For a Blueprint-owned root, place the boom beneath it.
        if (SCS->GetRootNodes().Num() > 0)
            SCS->GetRootNodes()[0]->AddChildNode(Boom, true);
        else
            SCS->AddNode(Boom);
        Boom->AddChildNode(Camera, true);
        FBlueprintEditorUtils::MarkBlueprintAsStructurallyModified(Blueprint);

        FCompilerResultsLog CompileLog(false);
        FKismetEditorUtilities::CompileBlueprint(Blueprint, EBlueprintCompileOptions::None, &CompileLog);
        if (CompileLog.NumErrors > 0 || Blueprint->Status == BS_Error)
        {
            Error = FString::Printf(TEXT("Componentes adicionados a %s, mas a compilacao falhou (%d erros)."),
                *AssetPath, CompileLog.NumErrors);
            return false;
        }
        if (!UEMasterBridge::SaveAsset(Blueprint, Error)) return false;
        Result->SetStringField(TEXT("blueprint_path"), AssetPath);
        Result->SetStringField(TEXT("spring_arm"), BoomName.ToString());
        Result->SetStringField(TEXT("camera"), CameraName.ToString());
        Result->SetNumberField(TEXT("warnings"), CompileLog.NumWarnings);
        return true;
    }

    bool CompileChangedBlueprints(const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        // Dirty loaded Blueprints are the ones edited in this Editor session.
        TArray<TStrongObjectPtr<UBlueprint>> Changed;
        for (TObjectIterator<UBlueprint> It; It; ++It)
        {
            UBlueprint* Blueprint = *It;
            if (!Blueprint->HasAnyFlags(RF_ClassDefaultObject | RF_Transient) &&
                Blueprint->GetOutermost()->GetName().StartsWith(TEXT("/Game/")) &&
                (Blueprint->GetOutermost()->IsDirty() || Blueprint->Status == BS_Dirty))
                Changed.Emplace(Blueprint);
        }

        int32 TotalErrors = 0;
        int32 TotalWarnings = 0;
        int32 TotalFailed = 0;
        TArray<FString> FailedNames;
        for (const TStrongObjectPtr<UBlueprint>& Item : Changed)
        {
            FCompilerResultsLog CompileLog(false);
            FKismetEditorUtilities::CompileBlueprint(Item.Get(), EBlueprintCompileOptions::None, &CompileLog);
            TotalWarnings += CompileLog.NumWarnings;
            TotalErrors += CompileLog.NumErrors;
            if (Item->Status == BS_Error || CompileLog.NumErrors > 0)
            {
                ++TotalFailed;
                if (FailedNames.Num() < 8) FailedNames.Add(Item->GetPathName());
                if (CompileLog.NumErrors == 0) ++TotalErrors;
            }
        }
        Result->SetNumberField(TEXT("compiled"), Changed.Num());
        Result->SetNumberField(TEXT("warnings"), TotalWarnings);
        Result->SetNumberField(TEXT("errors"), TotalErrors);
        if (TotalFailed > 0)
        {
            Error = FString::Printf(TEXT("Falha ao compilar %d Blueprint(s): %s"),
                TotalFailed, *FString::Join(FailedNames, TEXT(", ")));
            return false;
        }
        return true;
    }

    bool ImportAsset(const TSharedPtr<FJsonObject>& Request,
                     const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        const TArray<TSharedPtr<FJsonValue>>* Files = nullptr;
        if (!Request->TryGetArrayField(TEXT("files"), Files) ||
            Files->Num() == 0 || Files->Num() > 16)
        {
            Error = TEXT("Informe uma lista files com 1 a 16 caminhos de arquivos.");
            return false;
        }
        FString Destination;
        if (!Request->TryGetStringField(TEXT("destination"), Destination) ||
            !UEMasterBridge::IsProjectContentPath(Destination))
        {
            Error = TEXT("Destino invalido. Use um caminho em /Game, como /Game/Imported.");
            return false;
        }

        for (const TSharedPtr<FJsonValue>& Value : *Files)
        {
            if (!Value.IsValid() || Value->Type != EJson::String ||
                FPaths::IsRelative(Value->AsString()) ||
                !IFileManager::Get().FileExists(*Value->AsString()))
            {
                Error = TEXT("Arquivo inexistente ou caminho invalido: ") +
                    (Value.IsValid() ? Value->AsString() : TEXT("(vazio)"));
                return false;
            }
        }

        int32 Imported = 0;
        TArray<FString> Failed;
        TArray<TSharedPtr<FJsonValue>> Paths;
        for (const TSharedPtr<FJsonValue>& Value : *Files)
        {
            TStrongObjectPtr<UAssetImportTask> Task(NewObject<UAssetImportTask>());
            Task->Filename = Value->AsString();
            Task->DestinationPath = Destination;
            Task->bAutomated = true;
            Task->bAsync = false;
            Task->bReplaceExisting = false;
            Task->bSave = true;
            TArray<UAssetImportTask*> ImportTasks;
            ImportTasks.Add(Task.Get());
            FAssetToolsModule::GetModule().Get().ImportAssetTasks(ImportTasks);
            if (Task->GetObjects().Num() == 0)
            {
                Failed.Add(Value->AsString());
            }
            else
            {
                Imported += Task->GetObjects().Num();
                for (UObject* Object : Task->GetObjects())
                {
                    if (Paths.Num() < 32 && Object)
                        Paths.Add(MakeShared<FJsonValueString>(Object->GetPathName()));
                }
            }
        }
        Result->SetNumberField(TEXT("imported"), Imported);
        Result->SetNumberField(TEXT("failed_files"), Failed.Num());
        Result->SetArrayField(TEXT("asset_paths"), Paths);
        if (Failed.Num() > 0)
        {
            Error = FString::Printf(TEXT("%d arquivo(s) nao importados: %s. Verifique o importador no Output Log."),
                Failed.Num(), *FString::Join(Failed, TEXT(", ")));
            return false;
        }
        return true;
    }

    bool ListBlueprints(const TSharedPtr<FJsonObject>& Request,
                        const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        FString Search;
        Request->TryGetStringField(TEXT("search"), Search);
        Search.TrimStartAndEndInline();
        if (Search.Len() > 100)
        {
            Error = TEXT("A busca deve ter no maximo 100 caracteres.");
            return false;
        }

        FARFilter Filter;
        Filter.PackagePaths.Add(FName(TEXT("/Game")));
        Filter.bRecursivePaths = true;
        TArray<FAssetData> Assets;
        UAssetRegistryHelpers::GetBlueprintAssets(Filter, Assets);
        TArray<TSharedPtr<FJsonValue>> Entries;
        int32 TotalMatches = 0;
        int32 ReplyBytes = 0;
        for (const FAssetData& Data : Assets)
        {
            const FString Name = Data.AssetName.ToString();
            const FString PackageName = Data.PackageName.ToString();
            if (!Search.IsEmpty() && !Name.Contains(Search, ESearchCase::IgnoreCase) &&
                !PackageName.Contains(Search, ESearchCase::IgnoreCase)) continue;
            ++TotalMatches;
            const int32 EntryBytes = FTCHARToUTF8(*Name).Length() +
                FTCHARToUTF8(*PackageName).Length() + 192;
            if (Entries.Num() >= 120 || ReplyBytes + EntryBytes > 32 * 1024) continue;
            ReplyBytes += EntryBytes;

            const TSharedRef<FJsonObject> Entry = MakeShared<FJsonObject>();
            Entry->SetStringField(TEXT("name"), Name);
            Entry->SetStringField(TEXT("path"), PackageName);
            Entry->SetStringField(TEXT("kind"), Data.AssetClassPath.GetAssetName().ToString());
            Entries.Add(MakeShared<FJsonValueObject>(Entry));
        }
        Result->SetNumberField(TEXT("total"), TotalMatches);
        Result->SetArrayField(TEXT("assets"), Entries);
        return true;
    }

    bool ListSkeletalMeshes(const TSharedPtr<FJsonObject>& Request,
                            const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        FString Search;
        if ((Request->HasField(TEXT("search")) &&
             !Request->TryGetStringField(TEXT("search"), Search)) || Search.Len() > 100)
        {
            Error = TEXT("search deve ser texto com ate 100 caracteres.");
            return false;
        }
        Search.TrimStartAndEndInline();

        FARFilter Filter;
        Filter.ClassPaths.Add(USkeletalMesh::StaticClass()->GetClassPathName());
        Filter.PackagePaths.Add(FName(TEXT("/Game")));
        Filter.PackagePaths.Add(FName(TEXT("/Engine")));
        Filter.bRecursivePaths = true;
        TArray<FAssetData> Assets;
        if (!FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"))
                 .Get().GetAssets(Filter, Assets, false))
        {
            Error = TEXT("Nao foi possivel consultar as Skeletal Meshes no Asset Registry.");
            return false;
        }

        TArray<TSharedPtr<FJsonValue>> Entries;
        int32 TotalMatches = 0;
        int32 ReplyBytes = 0;
        for (const FAssetData& Data : Assets)
        {
            const FString Name = Data.AssetName.ToString();
            const FString PackageName = Data.PackageName.ToString();
            if (!Search.IsEmpty() && !Name.Contains(Search, ESearchCase::IgnoreCase) &&
                !PackageName.Contains(Search, ESearchCase::IgnoreCase)) continue;
            ++TotalMatches;
            const int32 EntryBytes = FTCHARToUTF8(*PackageName).Length() +
                FTCHARToUTF8(*Name).Length() + 128;
            if (Entries.Num() >= 120 || ReplyBytes + EntryBytes > 32 * 1024) continue;
            ReplyBytes += EntryBytes;

            const TSharedRef<FJsonObject> Entry = MakeShared<FJsonObject>();
            Entry->SetStringField(TEXT("name"), Name);
            Entry->SetStringField(TEXT("path"), PackageName);
            Entry->SetStringField(TEXT("object_path"), PackageName + TEXT(".") + Name);
            Entries.Add(MakeShared<FJsonValueObject>(Entry));
        }
        Result->SetNumberField(TEXT("total"), TotalMatches);
        Result->SetArrayField(TEXT("assets"), Entries);
        return true;
    }

    bool ListLevel(const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        UWorld* World = GEditor ? GEditor->GetEditorWorldContext().World() : nullptr;
        if (!World)
        {
            Error = TEXT("Nenhum nivel esta aberto no Unreal Editor.");
            return false;
        }
        Result->SetStringField(TEXT("map"), World->GetOutermost()->GetName());
        TArray<TSharedPtr<FJsonValue>> Entries;
        int32 ActorCount = 0;
        int32 ReplyBytes = 0;
        for (TActorIterator<AActor> It(World); It; ++It)
        {
            AActor* Actor = *It;
            ++ActorCount;
            const FString Label = Actor->GetActorLabel().Left(200);
            const FString ClassName = Actor->GetClass()->GetName();
            const int32 EntryBytes = FTCHARToUTF8(*Label).Length() +
                FTCHARToUTF8(*ClassName).Length() + 128;
            if (Entries.Num() >= 120 || ReplyBytes + EntryBytes > 32 * 1024) continue;
            ReplyBytes += EntryBytes;
            const TSharedRef<FJsonObject> Entry = MakeShared<FJsonObject>();
            Entry->SetStringField(TEXT("name"), Label);
            Entry->SetStringField(TEXT("class"), ClassName);
            Entries.Add(MakeShared<FJsonValueObject>(Entry));
        }
        Result->SetNumberField(TEXT("total"), ActorCount);
        Result->SetArrayField(TEXT("actors"), Entries);
        return true;
    }

    bool SceneSnapshot(const TSharedPtr<FJsonObject>& Request,
                       const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        UWorld* World = GEditor ? GEditor->GetEditorWorldContext().World() : nullptr;
        if (!World)
        {
            Error = TEXT("Nenhum nivel esta aberto no Unreal Editor.");
            return false;
        }
        double RawOffset = 0;
        if (Request->HasField(TEXT("offset")) &&
            !Request->TryGetNumberField(TEXT("offset"), RawOffset))
        {
            Error = TEXT("offset deve ser um inteiro entre 0 e 1000000.");
            return false;
        }
        if (!FMath::IsFinite(RawOffset) || RawOffset < 0 || RawOffset > 1000000 ||
            FMath::FloorToInt(RawOffset) != RawOffset)
        {
            Error = TEXT("offset deve ser um inteiro entre 0 e 1000000.");
            return false;
        }
        const int32 Offset = static_cast<int32>(RawOffset);
        constexpr int32 Limit = 20;
        int32 Total = 0;
        int32 NextOffset = Offset;
        int32 ReplyBytes = 512;
        bool bPageFull = false;
        TArray<TSharedPtr<FJsonValue>> Actors;
        for (TActorIterator<AActor> It(World); It; ++It)
        {
            if (Total >= Offset && Actors.Num() < Limit && !bPageFull)
            {
                const TSharedRef<FJsonObject> Actor = UEMasterBridge::ActorSummary(*It);
                const int32 EntryBytes = UEMasterBridge::JsonBytes(Actor) + 16;
                if (EntryBytes > 40 * 1024)
                {
                    Error = TEXT("Dados de um Actor excedem o limite de resposta da ponte.");
                    return false;
                }
                if (ReplyBytes + EntryBytes > 40 * 1024) bPageFull = true;
                else
                {
                    Actors.Add(MakeShared<FJsonValueObject>(Actor));
                    ReplyBytes += EntryBytes;
                    ++NextOffset;
                }
            }
            ++Total;
        }
        Result->SetStringField(TEXT("map"), World->GetOutermost()->GetName());
        Result->SetNumberField(TEXT("total"), Total);
        Result->SetNumberField(TEXT("offset"), Offset);
        Result->SetNumberField(TEXT("next_offset"), FMath::Min(NextOffset, Total));
        Result->SetBoolField(TEXT("has_more"), NextOffset < Total);
        Result->SetArrayField(TEXT("actors"), Actors);
        return true;
    }

    bool ActorDetails(const TSharedPtr<FJsonObject>& Request,
                      const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        FString Path;
        if (!Request->TryGetStringField(TEXT("actor_path"), Path) ||
            Path.IsEmpty() || Path.Len() > 1024)
        {
            Error = TEXT("Informe actor_path da resposta get_scene_snapshot (ate 1024 caracteres).");
            return false;
        }
        UWorld* World = GEditor ? GEditor->GetEditorWorldContext().World() : nullptr;
        if (!World)
        {
            Error = TEXT("Nenhum nivel esta aberto no Unreal Editor.");
            return false;
        }
        AActor* Found = nullptr;
        for (TActorIterator<AActor> It(World); It; ++It)
        {
            if (It->GetPathName() == Path)
            {
                Found = *It;
                break;
            }
        }
        if (!Found)
        {
            Error = TEXT("Actor nao encontrado no nivel aberto. Atualize a lista.");
            return false;
        }

        const TSharedRef<FJsonObject> Summary = UEMasterBridge::ActorSummary(Found);
        Result->SetStringField(TEXT("map"), World->GetOutermost()->GetName());
        Result->SetStringField(TEXT("path"), Path);
        Result->SetStringField(TEXT("label"), Found->GetActorLabel().Left(200));
        Result->SetStringField(TEXT("class"), Found->GetClass()->GetName());
        Result->SetObjectField(TEXT("transform"), Summary->GetObjectField(TEXT("transform")));
        Result->SetBoolField(TEXT("collision_enabled"), Found->GetActorEnableCollision());
        Result->SetStringField(TEXT("folder"), Found->GetFolderPath().ToString());
        Result->SetStringField(TEXT("parent_path"),
            Found->GetAttachParentActor() ? Found->GetAttachParentActor()->GetPathName() : TEXT(""));
        TArray<TSharedPtr<FJsonValue>> ActorTags;
        for (const FName& Tag : Found->Tags)
            if (ActorTags.Num() < 16)
                ActorTags.Add(MakeShared<FJsonValueString>(Tag.ToString().Left(64)));
        Result->SetArrayField(TEXT("tags"), ActorTags);
        if (const USceneComponent* Root = Found->GetRootComponent())
        {
            Result->SetStringField(TEXT("mobility"),
                Root->GetMobility() == EComponentMobility::Static ? TEXT("Static") :
                Root->GetMobility() == EComponentMobility::Stationary ? TEXT("Stationary") : TEXT("Movable"));
            if (const UPrimitiveComponent* Primitive = Cast<UPrimitiveComponent>(Root))
                Result->SetBoolField(TEXT("simulate_physics"), Primitive->IsSimulatingPhysics());
        }
        if (const UPointLightComponent* Light = Found->FindComponentByClass<UPointLightComponent>())
        {
            Result->SetNumberField(TEXT("light_intensity"), Light->Intensity);
            Result->SetNumberField(TEXT("attenuation_radius"), Light->AttenuationRadius);
        }
        FVector BoundsOrigin, BoundsExtent;
        Found->GetActorBounds(false, BoundsOrigin, BoundsExtent);
        const TSharedRef<FJsonObject> Bounds = MakeShared<FJsonObject>();
        Bounds->SetObjectField(TEXT("origin"), UEMasterBridge::VectorJson(BoundsOrigin));
        Bounds->SetObjectField(TEXT("extent"), UEMasterBridge::VectorJson(BoundsExtent));
        Result->SetObjectField(TEXT("bounds"), Bounds);

        TArray<TSharedPtr<FJsonValue>> Components;
        int32 TotalComponents = 0;
        int32 ReplyBytes = 2048;
        for (UActorComponent* Component : Found->GetComponents())
        {
            if (!Component) continue;
            ++TotalComponents;
            if (Components.Num() >= 16) continue;
            const TSharedRef<FJsonObject> Data = MakeShared<FJsonObject>();
            Data->SetStringField(TEXT("name"), Component->GetName().Left(160));
            Data->SetStringField(TEXT("class"), Component->GetClass()->GetName().Left(160));
            if (const UStaticMeshComponent* Static = Cast<UStaticMeshComponent>(Component))
                if (const UStaticMesh* Mesh = Static->GetStaticMesh())
                    Data->SetStringField(TEXT("mesh"), Mesh->GetPathName().Left(512));
            if (const USkeletalMeshComponent* Skeletal = Cast<USkeletalMeshComponent>(Component))
                if (const USkeletalMesh* Mesh = Skeletal->GetSkeletalMeshAsset())
                    Data->SetStringField(TEXT("mesh"), Mesh->GetPathName().Left(512));
            if (const UMeshComponent* MeshComponent = Cast<UMeshComponent>(Component))
            {
                TArray<TSharedPtr<FJsonValue>> Materials;
                for (int32 Index = 0; Index < FMath::Min(MeshComponent->GetNumMaterials(), 4); ++Index)
                    if (const UMaterialInterface* Material = MeshComponent->GetMaterial(Index))
                        Materials.Add(MakeShared<FJsonValueString>(Material->GetPathName().Left(512)));
                Data->SetArrayField(TEXT("materials"), Materials);
            }
            const int32 EntryBytes = UEMasterBridge::JsonBytes(Data) + 16;
            if (ReplyBytes + EntryBytes > 40 * 1024) continue;
            ReplyBytes += EntryBytes;
            Components.Add(MakeShared<FJsonValueObject>(Data));
        }
        Result->SetNumberField(TEXT("total_components"), TotalComponents);
        Result->SetArrayField(TEXT("components"), Components);
        return true;
    }

    bool CaptureView(const TSharedRef<FJsonObject>& Result, FString& Error)
    {
        UWorld* World = GEditor ? GEditor->GetEditorWorldContext().World() : nullptr;
        UUnrealEditorSubsystem* EditorSubsystem = GEditor
            ? GEditor->GetEditorSubsystem<UUnrealEditorSubsystem>() : nullptr;
        if (!World || !EditorSubsystem)
        {
            Error = TEXT("Nivel ou camera do Editor indisponivel.");
            return false;
        }
        FVector Location;
        FRotator Rotation;
        if (!EditorSubsystem->GetLevelViewportCameraInfo(Location, Rotation))
        {
            Error = TEXT("Abra um viewport de Level no Editor para definir a camera da captura.");
            return false;
        }

        constexpr int32 Width = 960;
        constexpr int32 Height = 540;
        UTextureRenderTarget2D* Target = NewObject<UTextureRenderTarget2D>(GetTransientPackage());
        Target->InitCustomFormat(Width, Height, PF_B8G8R8A8, false);
        USceneCaptureComponent2D* Capture = NewObject<USceneCaptureComponent2D>(GetTransientPackage());
        Capture->TextureTarget = Target;
        Capture->bCaptureEveryFrame = false;
        Capture->bCaptureOnMovement = false;
        Capture->CaptureSource = ESceneCaptureSource::SCS_FinalColorLDR;
        Capture->RegisterComponentWithWorld(World);
        if (!Capture->IsRegistered())
        {
            Error = TEXT("Nao foi possivel inicializar a captura de cena.");
            return false;
        }
        Capture->SetWorldLocationAndRotation(Location, Rotation);
        Capture->CaptureScene();

        TArray<FColor> Pixels;
        FTextureRenderTargetResource* Resource = Target->GameThread_GetRenderTargetResource();
        const bool bRead = Resource && Resource->ReadPixels(Pixels, FReadSurfaceDataFlags(),
            FIntRect(0, 0, Width, Height)) && Pixels.Num() == Width * Height;
        Capture->UnregisterComponent();
        if (!bRead)
        {
            Error = TEXT("Nao foi possivel ler os pixels da cena. Confira o renderizador do Editor.");
            return false;
        }

        TArray<uint8> Png;
        FImageUtils::CompressImageArray(Width, Height, Pixels, Png);
        if (Png.IsEmpty())
        {
            Error = TEXT("Nao foi possivel gerar o PNG da cena.");
            return false;
        }
        const FString Path = FPaths::ConvertRelativePathToFull(
            FPaths::ProjectSavedDir() / TEXT("UEMasterBridge") / TEXT("scene_latest.png"));
        IFileManager::Get().MakeDirectory(*FPaths::GetPath(Path), true);
        if (!FFileHelper::SaveArrayToFile(Png, *Path))
        {
            Error = TEXT("Falha ao salvar a captura em Saved/UEMasterBridge.");
            return false;
        }
        Result->SetStringField(TEXT("path"), Path);
        Result->SetStringField(TEXT("map"), World->GetOutermost()->GetName());
        Result->SetNumberField(TEXT("width"), Width);
        Result->SetNumberField(TEXT("height"), Height);
        Result->SetObjectField(TEXT("camera_location"), UEMasterBridge::VectorJson(Location));
        Result->SetStringField(TEXT("captured_at_utc"), FDateTime::UtcNow().ToIso8601());
        return true;
    }

    bool Tick(float DeltaTime)
    {
        (void)DeltaTime;

        if (!ClientSocket)
        {
            bool bPendingConnection = false;
            if (ListenSocket && ListenSocket->HasPendingConnection(bPendingConnection) && bPendingConnection)
            {
                ClientSocket = ListenSocket->Accept(TEXT("UE Master Controller"));
                if (ClientSocket && !ClientSocket->SetNonBlocking(true))
                {
                    CloseClient();
                }
                else if (ClientSocket)
                {
                    UE_LOG(LogUEMasterBridge, Display, TEXT("Controller connected on port %u."),
                        UEMasterBridge::Port);
                }
            }
        }

        if (!ClientSocket)
        {
            return true;
        }

        // The accepted socket is nonblocking. Read it directly: a TCP connection
        // alone does not mean the client has delivered a complete request yet.
        int32 Processed = 0;
        ProcessIncomingRequests(Processed);
        for (int32 ChunkIndex = 0;
             ClientSocket && Processed < UEMasterBridge::MaxRequestsPerTick &&
             ChunkIndex < UEMasterBridge::MaxReadChunksPerTick;
             ++ChunkIndex)
        {
            uint8 Chunk[8192];
            int32 Read = 0;
            if (!ClientSocket->Recv(Chunk, static_cast<int32>(sizeof(Chunk)), Read))
            {
                const ESocketErrors Error = SocketSubsystem->GetLastErrorCode();
                if (Error != SE_EWOULDBLOCK)
                {
                    UE_LOG(LogUEMasterBridge, Warning, TEXT("Receive failed (socket error %d)."),
                        static_cast<int32>(Error));
                    CloseClient();
                }
                break;
            }
            if (Read == 0)
            {
                if (ClientSocket->GetConnectionState() != SCS_Connected)
                {
                    CloseClient();
                }
                break;
            }

            Incoming.Append(Chunk, Read);
            ProcessIncomingRequests(Processed);
        }

        if (ClientSocket)
        {
            FlushOutput();
        }

        // Send the JSON acknowledgement before starting PIE. Creating a Play
        // session may occupy the editor's game thread for several seconds.
        if (bPlayQueuedByBridge && (!ClientSocket || Outgoing.Num() == 0))
        {
            bPlayQueuedByBridge = false;
            if (GEditor && !GEditor->PlayWorld && !GEditor->IsPlaySessionRequestQueued())
            {
                FRequestPlaySessionParams PlayParams;
                PlayParams.WorldType = EPlaySessionWorldType::PlayInEditor;
                PlayParams.SessionDestination = EPlaySessionDestinationType::InProcess;
                UE_LOG(LogUEMasterBridge, Display, TEXT("Starting the requested Play in Editor session."));
                GEditor->RequestPlaySession(PlayParams);
            }
        }
        return true;
    }

    void ProcessIncomingRequests(int32& Processed)
    {
        int32 Newline = INDEX_NONE;
        while (ClientSocket && Processed < UEMasterBridge::MaxRequestsPerTick &&
               (Newline = Incoming.Find(static_cast<uint8>('\n'))) != INDEX_NONE)
        {
            if (Newline > UEMasterBridge::MaxRequestBytes)
            {
                CloseClient();
                break;
            }

            const FUTF8ToTCHAR Utf16(reinterpret_cast<const ANSICHAR*>(Incoming.GetData()), Newline);
            const FString Request(Utf16.Length(), Utf16.Get());
            Incoming.RemoveAt(0, Newline + 1, EAllowShrinking::No);
            ProcessRequest(Request);
            ++Processed;
        }

        if (ClientSocket && Incoming.Num() > UEMasterBridge::MaxRequestBytes)
        {
            UE_LOG(LogUEMasterBridge, Warning, TEXT("Request exceeds 64 KiB; closing the client."));
            CloseClient();
        }
    }

    void ProcessRequest(const FString& Line)
    {
        const TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(Line);
        TSharedPtr<FJsonObject> Request;

        const TSharedRef<FJsonObject> Response = MakeShared<FJsonObject>();
        if (!FJsonSerializer::Deserialize(Reader, Request) || !Request.IsValid())
        {
            Response->SetBoolField(TEXT("ok"), false);
            Response->SetStringField(TEXT("error"), TEXT("Invalid JSON object"));
            QueueResponse(Response);
            return;
        }

        FString RequestId;
        if (Request->TryGetStringField(TEXT("id"), RequestId))
        {
            Response->SetStringField(TEXT("id"), RequestId);
        }

        FString Command;
        if (!Request->TryGetStringField(TEXT("command"), Command))
        {
            Response->SetBoolField(TEXT("ok"), false);
            Response->SetStringField(TEXT("error"), TEXT("Missing string field: command"));
            QueueResponse(Response);
            return;
        }

        const TSharedRef<FJsonObject> Result = MakeShared<FJsonObject>();
        bool bStartPlayAfterReply = false;
        if (Command == TEXT("ping"))
        {
            Result->SetStringField(TEXT("message"), TEXT("pong"));
        }
        else if (Command == TEXT("status"))
        {
            Result->SetStringField(TEXT("project_name"), FApp::GetProjectName());
            Result->SetStringField(TEXT("project_directory"),
                FPaths::ConvertRelativePathToFull(FPaths::ProjectDir()));
            Result->SetStringField(TEXT("engine_directory"),
                FPaths::ConvertRelativePathToFull(FPaths::EngineDir()));
            Result->SetStringField(TEXT("engine_version"), FEngineVersion::Current().ToString());
            Result->SetNumberField(TEXT("protocol_version"), 1);
            Result->SetStringField(TEXT("bridge_version"), TEXT("0.10.0"));
            Result->SetBoolField(TEXT("supports_play"), true);
            Result->SetBoolField(TEXT("supports_actions"), true);
            Result->SetBoolField(TEXT("supports_browsing"), true);
            Result->SetBoolField(TEXT("supports_vision"), true);
            Result->SetBoolField(TEXT("supports_scene_edit"), true);
            Result->SetBoolField(TEXT("supports_scene_authoring"), true);
            Result->SetBoolField(TEXT("supports_object_builder"), true);
            Result->SetBoolField(TEXT("supports_blueprint_graph"), true);
            Result->SetBoolField(TEXT("supports_character_builder"), true);
            Result->SetBoolField(TEXT("supports_skeletal_mesh_listing"), true);
            Result->SetBoolField(TEXT("is_playing"), GEditor && GEditor->PlayWorld != nullptr);
            Result->SetBoolField(TEXT("play_request_pending"),
                bPlayQueuedByBridge || (GEditor && GEditor->IsPlaySessionRequestQueued()));
        }
        else if (Command == TEXT("play"))
        {
            UE_LOG(LogUEMasterBridge, Display, TEXT("Received Play command from the controller."));
            if (!GEditor)
            {
                Response->SetBoolField(TEXT("ok"), false);
                Response->SetStringField(TEXT("error"), TEXT("Unreal Editor is not available"));
                QueueResponse(Response);
                return;
            }

            if (GEditor->PlayWorld != nullptr)
            {
                Result->SetStringField(TEXT("state"), TEXT("already_playing"));
                Result->SetStringField(TEXT("message"), TEXT("Play in Editor is already running"));
            }
            else if (bPlayQueuedByBridge || GEditor->IsPlaySessionRequestQueued())
            {
                Result->SetStringField(TEXT("state"), TEXT("already_requested"));
                Result->SetStringField(TEXT("message"), TEXT("A Play in Editor request is already pending"));
            }
            else
            {
                Result->SetStringField(TEXT("state"), TEXT("requested"));
                Result->SetStringField(TEXT("message"), TEXT("Play in Editor requested"));
                // RequestPlaySession is invoked only after the reply is flushed.
                bPlayQueuedByBridge = true;
                bStartPlayAfterReply = true;
            }
        }
        else if (Command == TEXT("list_blueprints") || Command == TEXT("list_skeletal_meshes") ||
                 Command == TEXT("list_level") ||
                 Command == TEXT("get_scene_snapshot") || Command == TEXT("get_actor_details") ||
                 Command == TEXT("capture_view") || Command == TEXT("get_object_details") ||
                 Command == TEXT("get_blueprint_logic") ||
                 Command == TEXT("get_character_details"))
        {
            FString Error;
            bool bOk = false;
            if (Command == TEXT("list_blueprints")) bOk = ListBlueprints(Request, Result, Error);
            else if (Command == TEXT("list_skeletal_meshes")) bOk = ListSkeletalMeshes(Request, Result, Error);
            else if (Command == TEXT("list_level")) bOk = ListLevel(Result, Error);
            else if (Command == TEXT("get_scene_snapshot")) bOk = SceneSnapshot(Request, Result, Error);
            else if (Command == TEXT("get_actor_details")) bOk = ActorDetails(Request, Result, Error);
            else if (Command == TEXT("get_object_details")) bOk = ObjectDetails(Request, Result, Error);
            else if (Command == TEXT("get_blueprint_logic")) bOk = GetBlueprintLogic(Request, Result, Error);
            else if (Command == TEXT("get_character_details")) bOk = CharacterDetails(Request, Result, Error);
            else bOk = CaptureView(Result, Error);
            Response->SetBoolField(TEXT("ok"), bOk);
            if (bOk) Response->SetObjectField(TEXT("result"), Result);
            else Response->SetStringField(TEXT("error"), Error);
            QueueResponse(Response);
            return;
        }
        else if (Command == TEXT("create_blueprint") ||
                 Command == TEXT("create_object") ||
                 Command == TEXT("create_blueprint_logic") ||
                 Command == TEXT("create_character") ||
                 Command == TEXT("add_third_person_camera") ||
                 Command == TEXT("compile_blueprints") ||
                 Command == TEXT("import_asset") ||
                 Command == TEXT("create_level") ||
                 Command == TEXT("open_level") ||
                 Command == TEXT("save_level") ||
                 Command == TEXT("spawn_actor") ||
                 Command == TEXT("set_actor_transform") ||
                 Command == TEXT("set_actor_mesh") ||
                 Command == TEXT("set_actor_material") ||
                 Command == TEXT("delete_actor") ||
                 Command == TEXT("duplicate_actor") ||
                 Command == TEXT("rename_actor") ||
                 Command == TEXT("attach_actor") ||
                 Command == TEXT("detach_actor") ||
                 Command == TEXT("set_actor_properties") ||
                 Command == TEXT("add_component") ||
                 Command == TEXT("remove_component") ||
                 Command == TEXT("create_content_folder") ||
                 Command == TEXT("move_asset") ||
                 Command == TEXT("duplicate_asset") ||
                 Command == TEXT("compose_scene") ||
                 Command == TEXT("frame_actor") ||
                 Command == TEXT("undo") ||
                 Command == TEXT("redo") ||
                 Command == TEXT("create_demo_room"))
        {
            if (!GEditor || GEditor->PlayWorld || GEditor->IsPlaySessionRequestQueued() ||
                bPlayQueuedByBridge)
            {
                Response->SetBoolField(TEXT("ok"), false);
                Response->SetStringField(TEXT("error"),
                    TEXT("O Editor deve estar aberto e fora do Play para editar o projeto."));
                QueueResponse(Response);
                return;
            }

            FString Error;
            bool bOk = false;
            if (Command == TEXT("create_blueprint"))
                bOk = CreateBlueprint(Request, Result, Error);
            else if (Command == TEXT("create_object"))
                bOk = CreateObject(Request, Result, Error);
            else if (Command == TEXT("create_blueprint_logic"))
                bOk = CreateBlueprintLogic(Request, Result, Error);
            else if (Command == TEXT("create_character"))
                bOk = CreateCharacter(Request, Result, Error);
            else if (Command == TEXT("add_third_person_camera"))
                bOk = AddThirdPersonCamera(Request, Result, Error);
            else if (Command == TEXT("compile_blueprints"))
                bOk = CompileChangedBlueprints(Result, Error);
            else if (Command == TEXT("import_asset"))
                bOk = ImportAsset(Request, Result, Error);
            else if (Command == TEXT("create_level"))
                bOk = CreateLevel(Request, Result, Error);
            else if (Command == TEXT("open_level"))
                bOk = OpenLevel(Request, Result, Error);
            else if (Command == TEXT("save_level"))
                bOk = SaveLevel(Result, Error);
            else if (Command == TEXT("spawn_actor"))
                bOk = SpawnActor(Request, Result, Error);
            else if (Command == TEXT("set_actor_transform"))
                bOk = SetActorTransform(Request, Result, Error);
            else if (Command == TEXT("set_actor_mesh"))
                bOk = SetActorMesh(Request, Result, Error);
            else if (Command == TEXT("set_actor_material"))
                bOk = SetActorMaterial(Request, Result, Error);
            else if (Command == TEXT("delete_actor"))
                bOk = DeleteActor(Request, Result, Error);
            else if (Command == TEXT("duplicate_actor"))
                bOk = DuplicateActor(Request, Result, Error);
            else if (Command == TEXT("rename_actor"))
                bOk = RenameActor(Request, Result, Error);
            else if (Command == TEXT("attach_actor"))
                bOk = AttachActor(Request, Result, Error, false);
            else if (Command == TEXT("detach_actor"))
                bOk = AttachActor(Request, Result, Error, true);
            else if (Command == TEXT("set_actor_properties"))
                bOk = SetActorProperties(Request, Result, Error);
            else if (Command == TEXT("add_component"))
                bOk = EditComponent(Request, Result, Error, false);
            else if (Command == TEXT("remove_component"))
                bOk = EditComponent(Request, Result, Error, true);
            else if (Command == TEXT("create_content_folder"))
                bOk = CreateContentFolder(Request, Result, Error);
            else if (Command == TEXT("move_asset"))
                bOk = EditAsset(Request, Result, Error, false);
            else if (Command == TEXT("duplicate_asset"))
                bOk = EditAsset(Request, Result, Error, true);
            else if (Command == TEXT("compose_scene"))
                bOk = ComposeScene(Request, Result, Error);
            else if (Command == TEXT("frame_actor"))
                bOk = FrameActor(Request, Result, Error);
            else if (Command == TEXT("undo") || Command == TEXT("redo"))
            {
                bOk = Command == TEXT("undo") ? GEditor->UndoTransaction(true) : GEditor->RedoTransaction();
                if (!bOk) Error = TEXT("Nao ha transacao disponivel ou o Editor bloqueou Undo/Redo.");
            }
            else if (Command == TEXT("create_demo_room"))
                bOk = CreateDemoRoom(Request, Result, Error);

            Response->SetBoolField(TEXT("ok"), bOk);
            Response->SetObjectField(TEXT("result"), Result);
            if (!bOk) Response->SetStringField(TEXT("error"), Error);
            QueueResponse(Response);
            return;
        }
        else
        {
            Response->SetBoolField(TEXT("ok"), false);
            Response->SetStringField(TEXT("error"), TEXT("Unknown command: ") + Command);
            QueueResponse(Response);
            return;
        }

        Response->SetBoolField(TEXT("ok"), true);
        Response->SetObjectField(TEXT("result"), Result);
        if (!QueueResponse(Response) && bStartPlayAfterReply)
        {
            bPlayQueuedByBridge = false;
        }
    }

    bool QueueResponse(const TSharedRef<FJsonObject>& Response)
    {
        FString Json;
        const TSharedRef<TJsonWriter<TCHAR, TCondensedJsonPrintPolicy<TCHAR>>> Writer =
            TJsonWriterFactory<TCHAR, TCondensedJsonPrintPolicy<TCHAR>>::Create(&Json);
        if (!FJsonSerializer::Serialize(Response, Writer))
        {
            CloseClient();
            return false;
        }

        const FTCHARToUTF8 Utf8(*Json);
        if (Outgoing.Num() - SentOffset + Utf8.Length() + 1 > UEMasterBridge::MaxQueuedBytes)
        {
            CloseClient();
            return false;
        }

        if (SentOffset > 0)
        {
            Outgoing.RemoveAt(0, SentOffset, EAllowShrinking::No);
            SentOffset = 0;
        }

        Outgoing.Append(reinterpret_cast<const uint8*>(Utf8.Get()), Utf8.Length());
        Outgoing.Add(static_cast<uint8>('\n'));
        return true;
    }

    void FlushOutput()
    {
        if (SentOffset >= Outgoing.Num())
        {
            Outgoing.Reset();
            SentOffset = 0;
            return;
        }

        int32 SentNow = 0;
        if (!ClientSocket->Send(Outgoing.GetData() + SentOffset, Outgoing.Num() - SentOffset, SentNow))
        {
            const ESocketErrors Error = SocketSubsystem->GetLastErrorCode();
            if (Error == SE_EWOULDBLOCK)
            {
                return;
            }
            UE_LOG(LogUEMasterBridge, Warning, TEXT("Send failed (socket error %d)."),
                static_cast<int32>(Error));
            CloseClient();
            return;
        }

        SentOffset += SentNow;
        if (SentOffset == Outgoing.Num())
        {
            Outgoing.Reset();
            SentOffset = 0;
        }
    }

    void CloseClient()
    {
        CloseSocket(ClientSocket);
        Incoming.Reset();
        Outgoing.Reset();
        SentOffset = 0;
    }

    void CloseSocket(FSocket*& Socket)
    {
        if (Socket)
        {
            Socket->Close();
            if (SocketSubsystem)
            {
                SocketSubsystem->DestroySocket(Socket);
            }
            Socket = nullptr;
        }
    }

    ISocketSubsystem* SocketSubsystem = nullptr;
    FSocket* ListenSocket = nullptr;
    FSocket* ClientSocket = nullptr;
    FTSTicker::FDelegateHandle TickHandle;
    TArray<uint8> Incoming;
    TArray<uint8> Outgoing;
    int32 SentOffset = 0;
    bool bPlayQueuedByBridge = false;
};

IMPLEMENT_MODULE(FUEMasterBridgeModule, UEMasterBridge)
