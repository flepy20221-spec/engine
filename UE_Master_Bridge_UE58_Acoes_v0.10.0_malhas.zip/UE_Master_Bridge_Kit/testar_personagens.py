"""Teste da fase 5 com o Unreal Editor 5.8 aberto.

python testar_personagens.py                         # status, sem alterações
python testar_personagens.py --write                 # Character com câmera e sem modelo
python testar_personagens.py --list-meshes --search Manny  # encontre a malha real do projeto
python testar_personagens.py --write --mesh /Game/Caminho/MalhaExistente
python testar_personagens.py --inspect /Game/Characters/BP_CharacterTest_XXXX
Feche o Controller: apenas um cliente TCP pode conectar ao Editor por vez.
"""

import argparse
import json
import uuid

from testar_autoria import Bridge, transform


def mesh_package_path(reference):
    reference = reference.strip()
    prefix = "SkeletalMesh'"
    if reference.startswith(prefix) and reference.endswith("'"):
        reference = reference[len(prefix):-1]
    return reference.split(".", 1)[0]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write", action="store_true",
                        help="Cria e salva um Character Blueprint e um mapa de teste")
    parser.add_argument("--mesh", metavar="SKELETAL_MESH_PATH",
                        help="Skeletal Mesh existente em /Game/; use com --write")
    parser.add_argument("--list-meshes", action="store_true",
                        help="Lista as Skeletal Meshes do projeto sem criar assets")
    parser.add_argument("--search", metavar="TEXTO",
                        help="Filtra --list-meshes por nome ou caminho (ex.: Manny)")
    parser.add_argument("--inspect", metavar="CHARACTER_PATH",
                        help="Consulta o Character salvo sem modificar o projeto")
    args = parser.parse_args()
    if sum(bool(value) for value in (args.write, args.inspect, args.list_meshes)) > 1:
        parser.error("Use apenas --write, --inspect ou --list-meshes.")
    if args.mesh and not args.write:
        parser.error("--mesh só pode ser usado com --write.")
    if args.search and not args.list_meshes:
        parser.error("--search só pode ser usado com --list-meshes.")

    bridge = Bridge()
    try:
        status = bridge.call("status")
        if status.get("bridge_version") != "0.10.0" or not status.get("supports_character_builder"):
            raise RuntimeError("Instale a ponte 0.10.0 e reinicie o Editor; feche o Controller.")
        print("Editor:", status["project_name"], status["engine_version"])
        if (args.list_meshes or args.mesh) and not status.get("supports_skeletal_mesh_listing"):
            raise RuntimeError("Instale a ponte 0.10.0 corrigida (consulta de malhas), reinicie o Editor e feche o Controller.")
        if args.list_meshes:
            meshes = bridge.call("list_skeletal_meshes", search=args.search or "")
            for item in meshes["assets"]:
                print(item["path"])
            print("Skeletal Meshes encontradas:", meshes["total"])
            if meshes["total"] > len(meshes["assets"]):
                print("Lista limitada; use --search para encontrar a malha desejada.")
            return
        if args.inspect:
            details = bridge.call("get_character_details", character_path=args.inspect)
            print(json.dumps(details, ensure_ascii=False, indent=2))
            return
        if not args.write:
            print("Conexão OK. Use --write em um projeto de teste com o mapa atual salvo.")
            return

        selected_mesh = None
        if args.mesh:
            package_path = mesh_package_path(args.mesh)
            search = package_path.rsplit("/", 1)[-1]
            meshes = bridge.call("list_skeletal_meshes", search=search)
            selected_mesh = next((item for item in meshes["assets"]
                                  if item["path"] == package_path), None)
            if selected_mesh is None:
                suggestions = ", ".join(item["path"] for item in meshes["assets"][:5])
                raise RuntimeError(
                    f"Skeletal Mesh não encontrada: {args.mesh}. "
                    + (f"Encontradas com nome parecido: {suggestions}. " if suggestions else "")
                    + "Execute --list-meshes para consultar os caminhos reais do projeto.")

        suffix = uuid.uuid4().hex[:8]
        name = "BP_CharacterTest_" + suffix
        path = "/Game/Characters/" + name
        invalid = "BP_InvalidCharacter_" + suffix
        rejected = bridge.call("create_character", should_succeed=False,
                               name=invalid, camera=True,
                               skeletal_mesh_path="/Game/MeshInexistente_" + suffix)
        assert "skeletal_mesh_path" in rejected, rejected
        bridge.call("get_character_details", should_succeed=False,
                    character_path="/Game/Characters/" + invalid)

        payload = {"name": name, "camera": True}
        if selected_mesh:
            payload["skeletal_mesh_path"] = selected_mesh["object_path"]
            payload["mesh_location"] = {"x": 0, "y": 0, "z": -90}
        created = bridge.call("create_character", **payload)
        assert created["asset_path"] == path, created
        print("Character salvo:", path)
        details = bridge.call("get_character_details", character_path=path)
        assert details["compiled"] and details["has_third_person_camera"], (path, details)
        assert details["parent_class"] == "Character", (path, details)
        assert details["capsule_radius"] > 0 and details["capsule_half_height"] > 0, (path, details)
        assert details["max_walk_speed"] > 0 and details["jump_z_velocity"] >= 0, (path, details)
        if selected_mesh:
            assert details["skeletal_mesh_path"] == selected_mesh["object_path"], (path, details)
            assert details["mesh_location"]["z"] == -90, (path, details)
        else:
            assert details["skeletal_mesh_path"] == "", (path, details)
        rejected = bridge.call("create_character", should_succeed=False, **payload)
        assert "Ja existe" in rejected, (path, rejected)

        level = bridge.call("create_level", name="L_CharacterTest_" + suffix)["map"]
        actor = bridge.call("spawn_actor", kind="Blueprint", blueprint_path=path,
                            label="Character_" + suffix, transform=transform(0, 0, 120),
                            auto_possess_player=True)["actor"]["path"]
        instance = bridge.call("get_actor_details", actor_path=actor)
        assert any(item["class"] == "CapsuleComponent" for item in instance["components"]), (path, instance)
        assert any(item["class"] == "SkeletalMeshComponent" for item in instance["components"]), (path, instance)
        if selected_mesh:
            assert any(item.get("mesh", "") == selected_mesh["object_path"]
                       for item in instance["components"]), (path, instance)
        bridge.call("save_level")
        print("Integração da fase 5 OK. Character:", path)
        print("Mapa salvo:", level)
        if not selected_mesh:
            print("Character sem malha visual. Use --write --mesh CAMINHO para validar uma Skeletal Mesh.")
    finally:
        bridge.close()


if __name__ == "__main__":
    main()
