@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0testar_conexao.ps1" -Vision
set "TEST_EXIT=%ERRORLEVEL%"
echo.
if "%TEST_EXIT%"=="0" (
    echo SUCCESS: scene data and PNG capture were returned by the Editor.
) else (
    echo Vision test failed. Keep a Level viewport open and inspect the Unreal Output Log.
)
pause
exit /b %TEST_EXIT%
