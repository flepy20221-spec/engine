using UnrealBuildTool;

public class UEMasterBridge : ModuleRules
{
    public UEMasterBridge(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

        PrivateDependencyModuleNames.AddRange(new string[]
        {
            "AssetTools",
            "AssetRegistry",
            "BlueprintEditorLibrary",
            "BlueprintGraph",
            "Core",
            "CoreUObject",
            "Engine",
            "Json",
            "Networking",
            "Sockets",
            "UnrealEd"
        });
    }
}
