param(
    [switch]$Play,
    [switch]$Compile,
    [switch]$Browse,
    [switch]$Vision
)

$ErrorActionPreference = 'Stop'
$client = $null
$reader = $null
$writer = $null
$exitCode = 0

try {
    $client = [System.Net.Sockets.TcpClient]::new()
    $connecting = $client.ConnectAsync('127.0.0.1', 17777)
    if (-not $connecting.Wait(3000)) {
        throw 'Timeout connecting to 127.0.0.1:17777.'
    }

    $stream = $client.GetStream()
    $stream.ReadTimeout = $(if ($Compile) { 600000 } elseif ($Vision) { 30000 } else { 10000 })
    $stream.WriteTimeout = 3000
    $reader = [System.IO.StreamReader]::new($stream, [System.Text.Encoding]::UTF8)
    $writer = [System.IO.StreamWriter]::new($stream, [System.Text.UTF8Encoding]::new($false))
    $writer.AutoFlush = $true

    $commands = @('ping', 'status')
    if ($Compile) { $commands += 'compile_blueprints' }
    if ($Browse) { $commands += 'list_blueprints'; $commands += 'list_level' }
    if ($Vision) { $commands += 'get_scene_snapshot'; $commands += 'capture_view' }
    if ($Play) { $commands += 'play' }

    foreach ($command in $commands) {
        $request = @{ id = $command; command = $command } | ConvertTo-Json -Compress
        $writer.WriteLine($request)
        $line = $reader.ReadLine()
        if ($null -eq $line) { throw 'The Editor closed the connection.' }
        $response = $line | ConvertFrom-Json
        if ($response.ok -ne $true) { throw "Bridge error: $line" }
        if ($command -eq 'status' -and -not [System.IO.Path]::IsPathRooted($response.result.project_directory)) {
            throw "project_directory is still relative: $($response.result.project_directory)"
        }
        if ($command -eq 'status' -and
            ($response.result.bridge_version -ne '0.10.0' -or
             $response.result.supports_play -ne $true -or
             $response.result.supports_actions -ne $true -or
             $response.result.supports_browsing -ne $true -or
             $response.result.supports_vision -ne $true -or
             $response.result.supports_scene_edit -ne $true -or
             $response.result.supports_scene_authoring -ne $true -or
             $response.result.supports_object_builder -ne $true -or
             $response.result.supports_blueprint_graph -ne $true -or
             $response.result.supports_character_builder -ne $true -or
             -not [System.IO.Path]::IsPathRooted($response.result.engine_directory))) {
            throw "The Editor is using an old bridge. Reinstall version 0.10.0 and restart the Editor: $line"
        }
        if ($command -eq 'play' -and $response.result.state -notin @('requested', 'already_requested', 'already_playing')) {
            throw "Unexpected Play response: $line"
        }
        if ($command -eq 'compile_blueprints' -and $null -eq $response.result.compiled) {
            throw "Unexpected compile response: $line"
        }
        if ($command -eq 'list_blueprints' -and ($null -eq $response.result.assets -or $null -eq $response.result.total)) {
            throw "Unexpected Blueprints response: $line"
        }
        if ($command -eq 'list_level' -and ($null -eq $response.result.actors -or $null -eq $response.result.map)) {
            throw "Unexpected Level response: $line"
        }
        if ($command -eq 'get_scene_snapshot' -and
            ($null -eq $response.result.actors -or $null -eq $response.result.total -or
             $null -eq $response.result.map)) {
            throw "Unexpected scene snapshot: $line"
        }
        if ($command -eq 'capture_view' -and
            (-not [System.IO.Path]::IsPathRooted($response.result.path) -or
             -not (Test-Path -LiteralPath $response.result.path -PathType Leaf) -or
             (Get-Item -LiteralPath $response.result.path).Length -lt 256)) {
            throw "Viewport PNG was not saved correctly: $line"
        }
        Write-Host ("{0}: {1}" -f $command, $line)
        if ($command -eq 'get_scene_snapshot' -and @($response.result.actors).Count -gt 0) {
            $actorPath = $response.result.actors[0].path
            $actorRequest = @{ id = 'actor_details'; command = 'get_actor_details'; actor_path = $actorPath } | ConvertTo-Json -Compress
            $writer.WriteLine($actorRequest)
            $actorLine = $reader.ReadLine()
            if ($null -eq $actorLine) { throw 'The Editor closed the actor details connection.' }
            $actorResponse = $actorLine | ConvertFrom-Json
            if ($actorResponse.ok -ne $true -or $actorResponse.result.path -ne $actorPath -or
                $null -eq $actorResponse.result.components) {
                throw "Unexpected actor details: $actorLine"
            }
            Write-Host ("actor_details: {0}" -f $actorLine)
        }
    }
}
catch {
    [Console]::Error.WriteLine($_.ToString())
    $exitCode = 1
}
finally {
    if ($writer) { $writer.Dispose() }
    if ($reader) { $reader.Dispose() }
    if ($client) { $client.Dispose() }
}

exit $exitCode
