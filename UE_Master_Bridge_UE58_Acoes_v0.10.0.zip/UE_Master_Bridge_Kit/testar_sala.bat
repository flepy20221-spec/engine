@echo off
setlocal
cd /d "%~dp0"
echo Feche o UE Master Controller antes deste teste e salve o mapa atual.
echo O teste cria um mapa novo em /Game/UE_Master_Maps e inicia o Play.
pause
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0testar_sala.ps1" -Play
set "test_result=%errorlevel%"
if errorlevel 1 (
    echo ERRO: veja a mensagem acima e o Output Log do Unreal Editor.
) else (
    echo SUCESSO: sala criada, inspecionada, alterada, salva e Play solicitado.
)
pause
endlocal & exit /b %test_result%
