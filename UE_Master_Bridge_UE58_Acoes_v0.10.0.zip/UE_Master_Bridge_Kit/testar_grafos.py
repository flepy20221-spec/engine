"""Teste da fase 4 do UE Master Bridge no Editor 5.8 aberto.

python testar_grafos.py                  # status apenas
python testar_grafos.py --write          # cria e salva um Blueprint exclusivo
python testar_grafos.py --inspect /Game/Objects/BP_GraphTest_XXXX  # leitura
Feche o Controller antes: somente um cliente TCP pode conectar ao Editor.
"""

import argparse
import json
import uuid

from testar_autoria import Bridge


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write", action="store_true",
                        help="Cria um Blueprint de teste e seu evento OpenChest")
    parser.add_argument("--inspect", metavar="BLUEPRINT_PATH",
                        help="Inspeciona OpenChest sem alterar o projeto")
    args = parser.parse_args()
    if args.write and args.inspect:
        parser.error("Use apenas --write ou --inspect.")

    bridge = Bridge()
    try:
        status = bridge.call("status")
        if status.get("bridge_version") != "0.10.0" or not status.get("supports_blueprint_graph"):
            raise RuntimeError("Instale a ponte 0.10.0 e reinicie o Editor; feche o Controller.")
        print("Editor:", status["project_name"], status["engine_version"])
        if args.inspect:
            details = bridge.call("get_blueprint_logic", blueprint_path=args.inspect,
                                  event_name="OpenChest")
            print(json.dumps(details, ensure_ascii=False, indent=2))
            return
        if not args.write:
            print("Conexão OK. Use --write em um projeto de teste para criar o grafo.")
            return

        suffix = uuid.uuid4().hex[:8]
        name = "BP_GraphTest_" + suffix
        path = bridge.call("create_object", name=name,
                           components=[{"name": "InteractionPoint", "kind": "ScenePoint"}],
                           variables=[
                               {"name": "IsOpen", "type": "bool", "default": False},
                               {"name": "LootAmount", "type": "int", "default": 3},
                               {"name": "InteractionDistance", "type": "float", "default": 180},
                               {"name": "DisplayName", "type": "string", "default": "Treasure chest"},
                           ])["asset_path"]
        print("Blueprint salvo:", path)

        invalid = bridge.call("create_blueprint_logic", should_succeed=False,
                              blueprint_path=path, event_name="OpenChest",
                              condition={"variable": "LootAmount", "equals": False},
                              steps=[{"kind": "print_string", "message": "invalid"}])
        assert "condition" in invalid, invalid
        bridge.call("get_blueprint_logic", should_succeed=False,
                    blueprint_path=path, event_name="OpenChest")

        created = bridge.call("create_blueprint_logic", blueprint_path=path,
                              event_name="OpenChest",
                              condition={"variable": "IsOpen", "equals": False},
                              steps=[
                                  {"kind": "set_variable", "name": "IsOpen", "value": True},
                                  {"kind": "set_variable", "name": "LootAmount", "value": 5},
                                  {"kind": "set_variable", "name": "InteractionDistance", "value": 250},
                                  {"kind": "set_variable", "name": "DisplayName", "value": "Opened"},
                                  {"kind": "print_string", "message": "Chest opened"},
                              ])
        assert created["created_nodes"] == 8, (path, created)
        details = bridge.call("get_blueprint_logic", blueprint_path=path,
                              event_name="OpenChest")
        assert details["compiled"] and len(details["nodes"]) == 8, (path, details)
        nodes = details["nodes"]
        kinds = [node["kind"] for node in nodes]
        for kind, expected in {"K2Node_CustomEvent": 1, "K2Node_VariableGet": 1,
                               "K2Node_IfThenElse": 1, "K2Node_VariableSet": 4,
                               "K2Node_CallFunction": 1}.items():
            assert kinds.count(kind) == expected, (path, kinds)

        def pin(node, name, direction):
            return next(item for item in node["pins"]
                        if item["name"].lower() == name.lower() and
                        item["direction"] == direction)

        event = next(node for node in nodes if node["kind"] == "K2Node_CustomEvent")
        branch = next(node for node in nodes if node["kind"] == "K2Node_IfThenElse")
        getter = next(node for node in nodes if node["kind"] == "K2Node_VariableGet")
        assert any(link["node"] == branch["id"]
                   for item in event["pins"] for link in item["links"]), (path, nodes)
        assert any(link["node"] == branch["id"] for link in
                   pin(getter, "IsOpen", "output")["links"]), (path, nodes)
        setters = [node for node in nodes if node["kind"] == "K2Node_VariableSet"]
        assert {node["variable"] for node in setters} == {
            "IsOpen", "LootAmount", "InteractionDistance", "DisplayName"}, (path, nodes)
        for node in setters:
            expected = {"IsOpen": "true", "LootAmount": "5",
                        "InteractionDistance": "250", "DisplayName": "Opened"}[node["variable"]]
            actual = pin(node, node["variable"], "input")["default"]
            assert (float(actual) == float(expected) if node["variable"] ==
                    "InteractionDistance" else actual.lower() == expected.lower()), (path, node)
        assert any(link["node"] == next(node for node in setters
                                        if node["variable"] == "IsOpen")["id"]
                   for link in pin(branch, "else", "output")["links"]), (path, nodes)
        assert all(any(item["type"] == "exec" and item["links"]
                       for item in node["pins"])
                   for node in setters), (path, nodes)

        duplicate = bridge.call("create_blueprint_logic", should_succeed=False,
                                blueprint_path=path, event_name="OpenChest",
                                steps=[{"kind": "print_string", "message": "duplicate"}])
        assert "Nome de evento" in duplicate, duplicate
        assert len(bridge.call("get_blueprint_logic", blueprint_path=path,
                               event_name="OpenChest")["nodes"]) == 8
        values = {item["name"]: item["default"] for item in
                  bridge.call("get_object_details", object_path=path)["variables"]}
        assert values["IsOpen"] == "false" and values["LootAmount"] == "3", (path, values)
        assert float(values["InteractionDistance"]) == 180, (path, values)
        assert values["DisplayName"] == "Treasure chest", (path, values)
        print("Integração da fase 4 OK. Evento OpenChest compilado em:", path)
        print("O teste deixa o Blueprint salvo no projeto para inspeção.")
    finally:
        bridge.close()


if __name__ == "__main__":
    main()
