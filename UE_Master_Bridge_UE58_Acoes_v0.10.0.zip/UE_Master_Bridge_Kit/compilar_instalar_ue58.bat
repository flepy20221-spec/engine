@echo off
setlocal EnableExtensions DisableDelayedExpansion

rem Override UE_ENGINE_ROOT if UE 5.8 is installed elsewhere.
set "ENGINE_ROOT=C:\Program Files\Epic Games\UE_5.8"
if defined UE_ENGINE_ROOT set "ENGINE_ROOT=%UE_ENGINE_ROOT%"

set "KIT_DIR=%~dp0"
set "PLUGIN_SOURCE=%KIT_DIR%UE_Master_Bridge"
set "PLUGIN_FILE=%PLUGIN_SOURCE%\UE_Master_Bridge.uplugin"
set "UAT=%ENGINE_ROOT%\Engine\Build\BatchFiles\RunUAT.bat"
set "PACKAGE_DIR=%KIT_DIR%Build\UE_Master_Bridge"
set "INSTALL_DIR=%ENGINE_ROOT%\Engine\Plugins\Marketplace\UE_Master_Bridge"

echo.
echo === UE Master Bridge - UE 5.8 / Win64 ===
echo Engine: "%ENGINE_ROOT%"
echo.

if not exist "%UAT%" goto missing_engine
if not exist "%PLUGIN_FILE%" goto missing_plugin

echo Close Unreal Editor before continuing.
pause
echo.

if exist "%PACKAGE_DIR%" rmdir /s /q "%PACKAGE_DIR%"
if exist "%PACKAGE_DIR%" goto cannot_clean

echo Compiling and packaging the plugin...
call "%UAT%" BuildPlugin -Plugin="%PLUGIN_FILE%" -Package="%PACKAGE_DIR%" -TargetPlatforms=Win64
if errorlevel 1 goto build_failed
if not exist "%PACKAGE_DIR%\UE_Master_Bridge.uplugin" goto build_failed

echo.
echo Installing into "%INSTALL_DIR%"...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
if not exist "%INSTALL_DIR%" goto install_failed
robocopy "%PACKAGE_DIR%" "%INSTALL_DIR%" /E /R:1 /W:1 /NFL /NDL /NP
if errorlevel 8 goto install_failed
if not exist "%INSTALL_DIR%\UE_Master_Bridge.uplugin" goto install_failed

echo.
echo SUCCESS. Open the project, enable "UE Master Bridge" in Edit ^> Plugins,
echo restart the Editor and run testar_conexao.bat.
pause
exit /b 0

:missing_engine
echo ERROR: RunUAT.bat was not found in "%ENGINE_ROOT%".
echo Set UE_ENGINE_ROOT if your installation is in another folder.
goto failed

:missing_plugin
echo ERROR: Missing "%PLUGIN_FILE%".
echo Extract the entire ZIP before running this BAT.
goto failed

:cannot_clean
echo ERROR: Could not remove the generated package in "%PACKAGE_DIR%".
goto failed

:build_failed
echo ERROR: BuildPlugin failed. Check the error above for the C++ compiler output.
goto failed

:install_failed
echo ERROR: Could not install into "%INSTALL_DIR%".
echo If Windows denied access, run this BAT as administrator.

:failed
pause
exit /b 1
