"""Teste da fase 5 com o Unreal Editor 5.8 aberto.

python testar_personagens.py                         # status, sem alterações
python testar_personagens.py --write                 # Character com câmera e sem modelo
python testar_personagens.py --write --mesh /Game/Characters/Mannequins/Meshes/SKM_Manny
python testar_personagens.py --inspect /Game/Characters/BP_CharacterTest_XXXX
Feche o Controller: apenas um cliente TCP pode conectar ao Editor por vez.
"""

import argparse
import json
import uuid

from testar_autoria import Bridge, transform


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write", action="store_true",
                        help="Cria e salva um Character Blueprint e um mapa de teste")
    parser.add_argument("--mesh", metavar="SKELETAL_MESH_PATH",
                        help="Skeletal Mesh existente em /Game/; use com --write")
    parser.add_argument("--inspect", metavar="CHARACTER_PATH",
                        help="Consulta o Character salvo sem modificar o projeto")
    args = parser.parse_args()
    if args.write and args.inspect:
        parser.error("Use apenas --write ou --inspect.")
    if args.mesh and not args.write:
        parser.error("--mesh só pode ser usado com --write.")

    bridge = Bridge()
    try:
        status = bridge.call("status")
        if status.get("bridge_version") != "0.10.0" or not status.get("supports_character_builder"):
            raise RuntimeError("Instale a ponte 0.10.0 e reinicie o Editor; feche o Controller.")
        print("Editor:", status["project_name"], status["engine_version"])
        if args.inspect:
            details = bridge.call("get_character_details", character_path=args.inspect)
            print(json.dumps(details, ensure_ascii=False, indent=2))
            return
        if not args.write:
            print("Conexão OK. Use --write em um projeto de teste com o mapa atual salvo.")
            return

        suffix = uuid.uuid4().hex[:8]
        name = "BP_CharacterTest_" + suffix
        path = "/Game/Characters/" + name
        invalid = "BP_InvalidCharacter_" + suffix
        rejected = bridge.call("create_character", should_succeed=False,
                               name=invalid, camera=True,
                               skeletal_mesh_path="/Game/MeshInexistente_" + suffix)
        assert "skeletal_mesh_path" in rejected, rejected
        bridge.call("get_character_details", should_succeed=False,
                    character_path="/Game/Characters/" + invalid)

        payload = {"name": name, "camera": True}
        if args.mesh:
            payload["skeletal_mesh_path"] = args.mesh
            payload["mesh_location"] = {"x": 0, "y": 0, "z": -90}
        created = bridge.call("create_character", **payload)
        assert created["asset_path"] == path, created
        print("Character salvo:", path)
        details = bridge.call("get_character_details", character_path=path)
        assert details["compiled"] and details["has_third_person_camera"], (path, details)
        assert details["parent_class"] == "Character", (path, details)
        assert details["capsule_radius"] > 0 and details["capsule_half_height"] > 0, (path, details)
        assert details["max_walk_speed"] > 0 and details["jump_z_velocity"] >= 0, (path, details)
        if args.mesh:
            assert details["skeletal_mesh_path"].startswith(args.mesh.split(".")[0] + "."), (path, details)
            assert details["mesh_location"]["z"] == -90, (path, details)
        else:
            assert details["skeletal_mesh_path"] == "", (path, details)
        rejected = bridge.call("create_character", should_succeed=False, **payload)
        assert "Ja existe" in rejected, (path, rejected)

        level = bridge.call("create_level", name="L_CharacterTest_" + suffix)["map"]
        actor = bridge.call("spawn_actor", kind="Blueprint", blueprint_path=path,
                            label="Character_" + suffix, transform=transform(0, 0, 120),
                            auto_possess_player=True)["actor"]["path"]
        instance = bridge.call("get_actor_details", actor_path=actor)
        assert any(item["class"] == "CapsuleComponent" for item in instance["components"]), (path, instance)
        assert any(item["class"] == "SkeletalMeshComponent" for item in instance["components"]), (path, instance)
        if args.mesh:
            assert any(item.get("mesh", "").startswith(args.mesh.split(".")[0] + ".")
                       for item in instance["components"]), (path, instance)
        bridge.call("save_level")
        print("Integração da fase 5 OK. Character:", path)
        print("Mapa salvo:", level)
        if not args.mesh:
            print("Character sem malha visual. Use --write --mesh CAMINHO para validar uma Skeletal Mesh.")
    finally:
        bridge.close()


if __name__ == "__main__":
    main()
