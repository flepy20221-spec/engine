@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0testar_conexao.ps1" -Play
set "TEST_EXIT=%ERRORLEVEL%"
echo.
if "%TEST_EXIT%"=="0" (
    echo SUCCESS: the bridge accepted the Play command.
) else (
    echo Play test failed. Check Edit ^> Plugins and the Output Log.
)
pause
exit /b %TEST_EXIT%
