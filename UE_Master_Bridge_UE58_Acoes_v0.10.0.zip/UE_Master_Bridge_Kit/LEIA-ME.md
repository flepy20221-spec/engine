# UE Master Bridge para Unreal Engine 5.8

Plugin C++ de Editor com ponte TCP local para o UE Master Controller. Fornece conexão, identificação do projeto, **Play**, criação e compilação de Blueprints, câmera de terceira pessoa, importação de assets, consultas de cena e captura PNG do nível.

Versão 0.10.0: `status` informa `bridge_version`, `supports_play`, `supports_actions`, `supports_browsing`, `supports_vision`, `supports_scene_edit`, `supports_scene_authoring`, `supports_object_builder`, `supports_blueprint_graph`, `supports_character_builder` e `engine_directory` absoluto. A ponte lê mensagens no socket sem bloqueio e envia a resposta JSON antes de solicitar Play in Editor. Os comandos de edição e consulta são executados na thread do Editor.

## Instalação no Windows

1. Extraia o ZIP inteiro em uma pasta gravável, por exemplo `C:\UE_Master_Bridge_Kit`.
2. Feche todas as janelas do Unreal Editor 5.8.
3. Execute `compilar_instalar_ue58.bat`. Ele chama `RunUAT.bat BuildPlugin`, compila para Win64 e copia o plugin compilado para `C:\Program Files\Epic Games\UE_5.8\Engine\Plugins\Marketplace\UE_Master_Bridge`.
4. Se a cópia para `Program Files` falhar por falta de acesso, execute o mesmo BAT como administrador. É preciso ter o compilador C++ e o Visual Studio configurados para a sua instalação do Unreal.
5. Abra seu projeto no Unreal, vá a **Edit > Plugins**, procure **UE Master Bridge**, ative o plugin e reinicie o Editor.
6. Com o Editor aberto, **feche o UE Master Controller antes dos testes BAT**: o plugin permite um cliente TCP por vez. Execute `testar_conexao.bat`. Ele envia `ping` e `status` e mostra as respostas.
7. Para testar também a execução do jogo, execute `testar_play.bat` ainda com o aplicativo Qt fechado. Esse teste envia `play` e realmente solicita o Play in Editor.

Para testar a compilação dos Blueprints alterados sem abrir o Qt, use `powershell -NoProfile -ExecutionPolicy Bypass -File testar_conexao.ps1 -Compile` com o aplicativo fechado e o Editor fora do Play.

Para testar as listas sem abrir o Qt, execute `powershell -NoProfile -ExecutionPolicy Bypass -File testar_conexao.ps1 -Browse` com o Editor aberto e o aplicativo fechado. O teste pede `list_blueprints` e `list_level`.

Para testar a nova visão, feche o Qt, mantenha um viewport de Level aberto no Unreal e execute `testar_visao.bat`. Ele consulta os Actors, verifica um Actor em detalhe e valida o PNG salvo pela ponte. A captura não inclui painéis nem gizmos; usa uma captura de cena fora da tela na posição da câmera do viewport. Requer renderização funcionando no Editor.

Para testar a edição real sem o Qt, salve o mapa aberto, feche o aplicativo Qt, saia do Play e execute `testar_sala.bat`. Ele cria um mapa de nome único em `/Game/UE_Master_Maps`, inspeciona os Actors, altera o piso, salva `.umap` e solicita Play. **O teste cria um mapa de verdade no seu projeto.** Para testar sem iniciar Play, execute `powershell -NoProfile -ExecutionPolicy Bypass -File testar_sala.ps1`.

Para verificar as fases 1 e 2: com o Editor aberto e o Qt fechado, execute `python testar_autoria.py` para consultar a conexão sem mudar o projeto. Em **um projeto de teste**, execute `python testar_autoria.py --write` para criar um mapa e assets identificados por sufixo único. Para a fase 3, execute `python testar_objetos.py` e depois `python testar_objetos.py --write`; este último cria um objeto e um mapa de nomes únicos. Para a fase 4, execute `python testar_grafos.py` e depois `python testar_grafos.py --write`. Para a fase 5, execute `python testar_personagens.py --write`, com `--mesh /Game/Caminho/SkeletalMesh` quando houver uma malha no projeto. Salve o mapa aberto antes de executar testes com `--write`.

Se o Engine estiver em outra pasta, defina `UE_ENGINE_ROOT` antes de executar o BAT. Exemplo em `cmd.exe`:

```bat
set "UE_ENGINE_ROOT=D:\Epic Games\UE_5.8"
compilar_instalar_ue58.bat
```

Se o plugin estiver ativo, o **Output Log** contém `LogUEMasterBridge: Listening on 127.0.0.1:17777`. Ao conectar, ele registra `Controller connected`; ao pedir Play, registra `Received Play command` e `Starting the requested Play in Editor session`. Se a porta já estiver ocupada, feche a outra instância do Editor que usa essa ponte e reinicie o projeto.

## Protocolo para o aplicativo Qt

- Transporte: TCP, **127.0.0.1:17777**. Não é WebSocket.
- Codificação: UTF-8.
- Uma mensagem JSON por linha, terminada em `\n`.
- `id` é uma string opcional repetida na resposta. `command` é obrigatório.
- No máximo um cliente por Editor. Mensagens acima de 64 KiB encerram a conexão.

Pedido:

```json
{"id":"1","command":"ping"}
```

Resposta:

```json
{"id":"1","ok":true,"result":{"message":"pong"}}
```

Outro pedido:

```json
{"id":"2","command":"status"}
```

A resposta inclui `project_name`, `project_directory`, `engine_directory` (caminhos absolutos), `engine_version`, `protocol_version: 1`, `bridge_version: "0.10.0"`, `supports_play: true`, `supports_actions: true`, `supports_browsing: true`, `supports_vision: true`, `supports_scene_edit: true`, `supports_scene_authoring: true`, `supports_object_builder: true`, `supports_blueprint_graph: true` e `supports_character_builder: true`. O script de teste verifica a versão e os caminhos. O Qt envia cada JSON acrescido de `\n` e lê até `\n`. Comandos desconhecidos recebem `{"ok":false,"error":"Unknown command: ..."}`.

Comando Play:

```json
{"id":"play","command":"play"}
```

Quando aceito, o plugin envia a confirmação ao aplicativo antes de solicitar Play in Editor com `FRequestPlaySessionParams` na game thread e retorna um destes estados:

- `requested`: a solicitação de Play in Editor foi enfileirada;
- `already_requested`: já havia uma solicitação aguardando início;
- `already_playing`: o projeto já está em Play.

Exemplo:

```json
{"id":"play","ok":true,"result":{"state":"requested","message":"Play in Editor requested"}}
```

Se o Unreal Editor não estiver disponível, a resposta usa `ok:false`. O pedido apenas inicia o Play; ele não encerra uma sessão já em execução.

## Comandos de edição

Todos exigem o Editor aberto e fora de Play. `id` pode ser qualquer string exclusiva por pedido. Os resultados trazem `ok:true` apenas se a ação solicitada foi concluída. Falhas retornam `ok:false` e `error` explicativo. Para importação parcial, `result.imported` indica o número efetivamente importado.

```json
{"id":"1","command":"create_blueprint","name":"BP_Player","parent_class":"Character"}
{"id":"2","command":"add_third_person_camera","blueprint_path":"/Game/Blueprints/BP_Player"}
{"id":"3","command":"compile_blueprints"}
{"id":"4","command":"import_asset","files":["C:/Assets/personagem.fbx"],"destination":"/Game/Imported"}
```

- `create_blueprint`: classes pai `Actor`, `Pawn` ou `Character`; cria em `/Game/Blueprints`, compila e salva.
- `add_third_person_camera`: requer Blueprint Pawn ou Character; adiciona Spring Arm (distância 300, rotação pelo controlador) e Camera no soquete do braço; compila e salva. Não cria um GameMode nem altera qual Pawn o jogo usa.
- `compile_blueprints`: compila os Blueprints do projeto já carregados com package sujo ou status `BS_Dirty`. Retorna `compiled`, `warnings` e `errors`. Não percorre Blueprints ainda não carregados.
- `import_asset`: aceita 1 a 16 arquivos locais absolutos; não sobrescreve assets existentes e salva após importar. Os importadores dos formatos escolhidos precisam estar disponíveis no Editor. Retorna `imported`, `failed_files` e `asset_paths`.

## Criar e editar a cena

Os comandos abaixo exigem o Editor fora do Play. Criar ou abrir outro mapa é recusado enquanto houver mapas com alterações não salvas: salve o mapa atual primeiro. `create_level` e `create_demo_room` criam em `/Game/UE_Master_Maps/` e recusam nomes existentes. Os mapas e as mudanças feitas pelo aplicativo são arquivos reais do projeto; revise antes de usar no mapa principal.

```json
{"id":"1","command":"create_level","name":"L_NovoMapa"}
{"id":"2","command":"create_demo_room","name":"L_SalaTeste"}
{"id":"3","command":"open_level","map":"/Game/UE_Master_Maps/L_SalaTeste"}
{"id":"4","command":"save_level"}
{"id":"5","command":"spawn_actor","kind":"StaticMesh","label":"Bloco","mesh_path":"/Engine/BasicShapes/Cube","transform":{"location":{"x":0,"y":0,"z":150},"rotation":{"pitch":0,"yaw":0,"roll":0},"scale":{"x":2,"y":2,"z":1}}}
{"id":"6","command":"set_actor_transform","actor_path":"<path recebido no snapshot>","transform":{"location":{"x":100,"y":0,"z":150},"rotation":{"pitch":0,"yaw":45,"roll":0},"scale":{"x":2,"y":2,"z":1}}}
{"id":"7","command":"set_actor_mesh","actor_path":"<path recebido no snapshot>","mesh_path":"/Engine/BasicShapes/Cube"}
{"id":"8","command":"set_actor_material","actor_path":"<path recebido no snapshot>","material_path":"/Game/Materials/M_Parede","slot":0}
```

- `create_level`: abre um mundo vazio e salva um novo `.umap`, retornando `result.map`.
- `create_demo_room`: cria piso, quatro paredes, luz e um DefaultPawn com `auto_possess_player` configurado para Player 0; salva o mapa e devolve a lista de sete Actors. A câmera do viewport do Editor pode precisar ser reposicionada para enxergar a sala. O GameMode do seu projeto pode afetar qual Pawn será usado no Play.
- `open_level`: abre um `.umap` existente do projeto por pacote `/Game/...`; `save_level` salva o mapa aberto se ele já tiver nome em `/Game/`.
- `spawn_actor`: aceita `StaticMesh`, `SkeletalMesh`, `PointLight`, `SpotLight`, `DirectionalLight`, `Camera`, `TriggerBox`, `Character`, `DefaultPawn`, `PlayerStart` ou `Blueprint` (`blueprint_path` em `/Game/`). Envie `transform` completo. Para StaticMesh, `mesh_path` é opcional e usa o cubo do Engine por padrão; SkeletalMesh exige `skeletal_mesh_path` válido. `auto_possess_player` só é aceito para Pawn.
- `set_actor_transform`, `set_actor_mesh`, `set_actor_material`: usam o `actor_path` devolvido por `get_scene_snapshot`. A mesh requer `StaticMeshActor`; material usa o primeiro MeshComponent e um slot existente (0 a 7). Aceitam assets de `/Game/` e `/Engine/`. As edições individuais entram no histórico Desfazer do Editor; **clique Salvar mapa** após editar.

As posições estão em centímetros, rotações em graus, e a escala deve ser maior ou igual a 0,001. Em caso de falha após abrir um mapa novo, o Editor pode deixar o nível parcialmente construído e ainda não salvo; examine o Output Log antes de mudar de mapa.

### Autoria de Actors, assets e cenas — introduzida na 0.7.0

Os comandos de Actor usam `actor_path` recebido em `get_scene_snapshot`. Após exclusão, duplicação, renomeação ou Undo/Redo, atualize o snapshot: um caminho antigo pode deixar de existir.

| Comando | Campos adicionais | Efeito |
| --- | --- | --- |
| `delete_actor` | nenhum | Exclui Actor do mapa; exige salvar o mapa depois. |
| `duplicate_actor` | `offset: {x,y,z}` opcional (padrão 100,0,0) | Duplica com deslocamento em cm. |
| `rename_actor` | `label` | Troca o nome visível no Outliner. |
| `attach_actor` / `detach_actor` | `parent_path` só para anexar | Vincula ou separa preservando transform do mundo; recusa ciclos. |
| `set_actor_properties` | `collision_enabled`, `simulate_physics`, `mobility`, `folder`, `tags`, `light_intensity`, `attenuation_radius` | Edita somente propriedades tipadas e validadas. Física exige mesh raiz móvel. |
| `add_component` | `component_name` com prefixo `Bridge_`, `component_kind` (`BoxCollision`, `PointLight`, `StaticMesh`), `mesh_path` para StaticMesh | Adiciona componente de instância ao Actor. |
| `remove_component` | `component_name` | Remove apenas componentes de instância marcados como criados pela ponte. |
| `frame_actor` | nenhum | Enquadra o Actor na câmera do viewport; não salva nem altera o mapa. |
| `undo` / `redo` | nenhum | Aciona o histórico de transações do próprio Editor; pode afetar alterações manuais recentes. |

Pasta e asset usam caminhos de pacote sem sufixo `.Objeto`; mapas não podem ser movidos por `move_asset`.

| Comando | Campos | Efeito |
| --- | --- | --- |
| `create_content_folder` | `folder: "/Game/Cenarios"` | Cria pasta, sem substituir conteúdo existente. |
| `duplicate_asset` | `source`, `destination` em `/Game/` | Duplica e salva asset; recusa destino ocupado. |
| `move_asset` | `source`, `destination` em `/Game/` | Move/renomeia com API do Editor; pode criar redirector na origem. |

`compose_scene` recebe `actors` com 1 a 32 entradas iguais aos parâmetros de `spawn_actor` (sem `id` ou `command` por entrada). Valida todas as entradas e carrega as meshes antes de começar; insere Actors como uma operação de Undo. Retorna `total` e `actors` (até 12 resumos; leia o snapshot para os demais). Não salva automaticamente o mapa.

```json
{"id":"cena","command":"compose_scene","actors":[
  {"kind":"StaticMesh","label":"Piso","mesh_path":"/Engine/BasicShapes/Cube",
   "transform":{"location":{"x":0,"y":0,"z":-50},"rotation":{"pitch":0,"yaw":0,"roll":0},
                "scale":{"x":8,"y":8,"z":1}}},
  {"kind":"PointLight","label":"Luz",
   "transform":{"location":{"x":0,"y":0,"z":300},"rotation":{"pitch":0,"yaw":0,"roll":0},
                "scale":{"x":1,"y":1,"z":1}}}
]}
```

Se uma inserção falhar após começar o lote, a ponte tenta remover os Actors desse lote e devolve erro; inspecione a cena antes de salvar. Recursos externos, materiais e regras de gameplay não são gerados por esse comando.

## Object Builder — fase 3, versão 0.8.2

`create_object` cria um Blueprint reutilizável de Actor em `/Game/Objects/<name>`, com raiz `SceneRoot`, componentes filhos, variáveis com valores iniciais e opção de edição por instância. Se o Blueprint novo já vier com uma raiz de cena, ela é reutilizada e renomeada; a ponte não cria uma segunda raiz. A ponte valida toda a estrutura e carrega as meshes antes de criar o asset; recusa nomes de destino já usados. Depois de compilar, grava e confere os valores iniciais na classe gerada antes de salvar. `get_object_details` consulta componentes e variáveis do Blueprint salvo, inclusive enquanto o Editor está em Play. Cada componente inclui `is_root` para conferir a hierarquia. O campo `default` da variável vem da classe compilada quando `default_source` é `class_default`; para tipos fora de bool/int/float/string, o retorno conserva a descrição textual com `default_source: "description"`. Os caminhos de objeto são nomes de pacote sem `.uasset`.

```json
{"id":"chest","command":"create_object","name":"BP_Chest","components":[
  {"name":"StaticMesh_Chest","kind":"StaticMesh","mesh_path":"/Engine/BasicShapes/Cube"},
  {"name":"BoxCollision","kind":"BoxCollision","box_extent":{"x":60,"y":60,"z":60}},
  {"name":"InteractionPoint","kind":"ScenePoint","location":{"x":0,"y":0,"z":90}}
],"variables":[
  {"name":"IsOpen","type":"bool","default":false},
  {"name":"LootAmount","type":"int","default":3},
  {"name":"InteractionDistance","type":"float","default":180,"instance_editable":true}
]}
{"id":"inspect","command":"get_object_details","object_path":"/Game/Objects/BP_Chest"}
```

`components` aceita entre 1 e 12 entradas: `StaticMesh` exige `mesh_path` existente; `BoxCollision` permite `box_extent` positivo e usa o perfil Trigger; `ScenePoint` cria marcador `SceneComponent`; `PointLight` permite `intensity` entre 0 e 1.000.000. Qualquer componente pode receber `location:{x,y,z}` relativa à raiz, em centímetros. `variables` aceita de 0 a 16 entradas de tipo `bool`, `int`, `float` e `string` com `default` do tipo correspondente; `instance_editable` é opcional e tem valor padrão `true`. Nomes devem começar por letra e conter apenas letras ASCII, números e `_`, sem repetição entre componentes e variáveis. O retorno da criação inclui `asset_path`, `warnings`, `total_components` e `total_variables`.

Use `spawn_actor` com `kind:"Blueprint"`, `blueprint_path:"/Game/Objects/BP_Chest"` e `transform` para instanciar no mapa; depois use `save_level`. `get_object_details` permite conferir a estrutura antes da instanciação. As variáveis e o volume de colisão são dados de configuração: abrir o baú, gerar loot e detectar interação exigem um grafo de gameplay em uma fase posterior. Se ocorrer falha do Engine durante criação/compilação, o asset pode permanecer carregado sem ter sido salvo: confira `/Game/Objects` no Editor antes de repetir com o mesmo nome.

Na 0.8.0, o teste parava na raiz do Blueprint; a 0.8.1 corrigiu a raiz, mas o teste falhou na comparação dos valores iniciais. A 0.8.2 verifica esses valores na classe compilada e esclarece no erro o caminho e os defaults retornados. Para rever um Blueprint já criado após reiniciar o Editor, execute `python testar_objetos.py --inspect /Game/Objects/NOME_DO_BLUEPRINT` (somente leitura). O teste com `--write` usa um sufixo novo a cada execução e deixa o asset no projeto; verifique o Content Browser antes de apagar qualquer tentativa antiga.

## Blueprint Graph — fase 4, versão 0.9.0

`create_blueprint_logic` acrescenta um **evento personalizado novo** ao EventGraph de um Blueprint Actor existente em `/Game/`, sem substituir eventos existentes. Opcionalmente, conecta uma condição `bool` de uma variável local a um nó Branch e executa a sequência quando a variável é igual a `equals`. `steps` contém de 1 a 12 passos `set_variable` (valor tipado de uma variável local `bool`, `int`, `float` ou `string`) ou `print_string` (mensagem de até 256 caracteres). A ponte conecta os pins pela regra do Engine, compila e salva o Blueprint; um nome de evento duplicado é recusado. O Blueprint deve estar compilado e sem alterações não salvas. Falhas de ligação ou compilação tentam remover somente os nós criados neste pedido e não salvam o Blueprint; confira o asset no Editor se o Engine reportar erro.

```json
{"id":"logic","command":"create_blueprint_logic",
 "blueprint_path":"/Game/Objects/BP_Chest","event_name":"OpenChest",
 "condition":{"variable":"IsOpen","equals":false},
 "steps":[
   {"kind":"set_variable","name":"IsOpen","value":true},
   {"kind":"print_string","message":"Chest opened"}
 ]}
{"id":"view","command":"get_blueprint_logic",
 "blueprint_path":"/Game/Objects/BP_Chest","event_name":"OpenChest"}
```

`get_blueprint_logic` é somente leitura e retorna `compiled` e os nós conectados a esse evento (até 24), cada um com identificador, tipo, pins, valores de entrada e links; pode ser usado fora de Play ou durante Play. O evento só executa quando outra lógica do jogo o chama: criá-lo não conecta automaticamente o volume de colisão do baú nem gera loot. No Controller, escolha **Blueprint > Grafo > Criar evento e lógica** para editar o JSON do exemplo, ou **Inspecionar evento** para consultar o resultado. O teste `python testar_grafos.py --write` cria um Blueprint de nome exclusivo e confere o Branch, os setters, a mensagem, as conexões e os defaults originais. Depois de reiniciar o Editor, use `python testar_grafos.py --inspect /Game/Objects/BP_GraphTest_SUFIXO` para verificar o asset salvo sem modificá-lo.

## Personagens — fase 5, versão 0.10.0

`create_character` cria um Blueprint derivado de `Character` em `/Game/Characters/<name>`, sem sobrescrever um asset existente. O personagem mantém os componentes nativos do Unreal (cápsula, Skeletal Mesh e CharacterMovement). `skeletal_mesh_path` é opcional: quando presente, deve apontar para um **asset Skeletal Mesh existente** em `/Game/` ou `/Engine/`. `mesh_location` opcional ajusta a posição relativa do modelo em centímetros e exige `skeletal_mesh_path`. `camera` (padrão `true`) adiciona Spring Arm e Camera de terceira pessoa. O plugin valida a malha e os campos antes de criar o asset; compila, confere os componentes, grava a malha na classe compilada e salva.

```json
{"id":"hero","command":"create_character","name":"BP_Hero",
 "camera":true,
 "skeletal_mesh_path":"/Game/Characters/Mannequins/Meshes/SKM_Manny",
 "mesh_location":{"x":0,"y":0,"z":-90}}
{"id":"view","command":"get_character_details",
 "character_path":"/Game/Characters/BP_Hero"}
```

O exemplo de Skeletal Mesh depende dos assets do projeto. Ajuste o caminho ou remova `skeletal_mesh_path` e `mesh_location` para criar um Character sem modelo visual. `get_character_details` consulta qualquer Blueprint Character salvo em `/Game/` e informa compilação, malha, deslocamento, tamanho da cápsula, valores atuais de movimento e presença da câmera. `spawn_actor` com `kind:"Blueprint"` e `blueprint_path:"/Game/Characters/BP_Hero"` coloca uma instância no mapa; `auto_possess_player:true` é opcional. Depois use `save_level`.

No Controller, use **Blueprint > Personagem** para criar ou inspecionar. Em um projeto de teste, feche o Controller e execute `python testar_personagens.py --write`; para validar também um modelo use `python testar_personagens.py --write --mesh /Game/Caminho/Malha`. Depois de reiniciar o Editor, consulte o Blueprint salvo com `python testar_personagens.py --inspect /Game/Characters/BP_CharacterTest_SUFIXO`. A malha importada precisa ser **esquelética**; este comando não cria esqueleto, Animation Blueprint, entrada de movimento ou GameMode. Se o Engine falhar após iniciar a criação, o asset pode permanecer carregado e ainda não salvo; inspecione o Content Browser antes de repetir o mesmo nome.

## Consultas para as páginas Blueprint e Level

Esses comandos podem ser usados durante o Play: consultam o Editor sem alterar o projeto. A resposta inclui `total` e até 120 entradas, limitadas também pelo tamanho da mensagem TCP (64 KiB).

```json
{"id":"blueprints","command":"list_blueprints","search":"BP_"}
{"id":"level","command":"list_level"}
```

`list_blueprints` percorre Blueprints registrados em `/Game` via Asset Registry e retorna `assets` com `name`, `path` (por exemplo `/Game/Blueprints/BP_Player`) e `kind`. A busca opcional `search` compara nome e caminho sem diferenciar maiúsculas, com limite de 100 caracteres. `list_level` retorna `map`, `total` e `actors` com nome visível e classe dos Actors carregados no mundo do Editor; pode mostrar menos entradas que `total` se o nível for grande. Assets e mapas salvos em disco são lidos pelo Qt na pasta Content.

## Visão e inspeção da cena

```json
{"id":"scene_snapshot","command":"get_scene_snapshot","offset":0}
{"id":"actor_details","command":"get_actor_details","actor_path":"<path de get_scene_snapshot>"}
{"id":"capture_view","command":"capture_view"}
```

- `get_scene_snapshot`: devolve `map`, `total`, `offset`, `next_offset`, `has_more` e até 20 `actors` com `path` completo, `label`, `class`, `guid` e `transform` (posição, rotação e escala). Para ler o próximo grupo, envie `offset` igual ao `next_offset` anterior. Atualize desde 0 se o número de Actors mudar durante a leitura.
- `get_actor_details`: devolve transform, posição/extensão dos limites, colisão, pasta, tags, vínculo pai, mobilidade, física e, para PointLight, intensidade/alcance; lista até 16 componentes, incluindo Static Mesh ou Skeletal Mesh e até quatro materiais por componente. `total_components` informa a contagem completa. Não modifica o mapa.
- `capture_view`: captura 960 × 540 da cena do mundo de edição, a partir da câmera do viewport do Level, e salva um PNG em `Saved/UEMasterBridge/scene_latest.png`. A resposta inclui `path` absoluto, `map`, `width`, `height`, `camera_location` e `captured_at_utc`. O próximo pedido substitui esse arquivo. A imagem não trafega no JSON de 64 KiB; o Qt lê o PNG no disco local. Durante PIE, a câmera usada continua sendo a do nível de edição.

Um erro de câmera indica que é necessário abrir um viewport de Level no Editor. Se o Editor estiver minimizado e pausar a renderização, restaure sua janela e repita a captura. A leitura da cena funciona mesmo sem captura visual. Estes comandos fornecem observação; não escolhem ações nem implementam um modelo de IA.

Os botões **Build Windows** e **Build Android** são implementados no aplicativo Qt: chamam `Engine/Build/BatchFiles/RunUAT.bat` da instalação informada por `status` e mostram a saída do processo. Para Android, configure SDK/NDK no Unreal. O plugin não executa packaging dentro do Editor.

O servidor escuta apenas no próprio computador. Ele roda no Editor e não entra nos executáveis dos jogos empacotados. Para testar, o Editor precisa permanecer aberto, mesmo que sua janela esteja minimizada.

## Arquivos

```text
UE_Master_Bridge_Kit/
  compilar_instalar_ue58.bat
  testar_conexao.bat
  testar_conexao.ps1
  testar_play.bat
  testar_visao.bat
  testar_sala.bat
  testar_sala.ps1
  testar_autoria.py
  testar_objetos.py
  testar_grafos.py
  testar_personagens.py
  UE_Master_Bridge/
    UE_Master_Bridge.uplugin
    Source/UEMasterBridge/UEMasterBridge.Build.cs
    Source/UEMasterBridge/Private/UEMasterBridge.cpp
```
