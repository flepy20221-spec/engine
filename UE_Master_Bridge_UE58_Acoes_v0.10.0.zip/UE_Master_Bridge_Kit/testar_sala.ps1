param(
    [string]$MapName = ('L_Bridge_Sala_' + (Get-Date -Format 'yyyyMMdd_HHmmss')),
    [switch]$Play
)

$ErrorActionPreference = 'Stop'
if ($MapName -cnotmatch '^[A-Za-z][A-Za-z0-9_]{0,63}$') {
    throw 'MapName deve usar apenas letras, digitos e underscore.'
}

$client = [System.Net.Sockets.TcpClient]::new()
try {
    $connecting = $client.ConnectAsync('127.0.0.1', 17777)
    if (-not $connecting.Wait(3000)) { throw 'Ponte indisponivel em 127.0.0.1:17777.' }
    $stream = $client.GetStream()
    $stream.ReadTimeout = 600000
    $stream.WriteTimeout = 3000
    $reader = [System.IO.StreamReader]::new($stream, [System.Text.Encoding]::UTF8)
    $writer = [System.IO.StreamWriter]::new($stream, [System.Text.UTF8Encoding]::new($false))
    $writer.AutoFlush = $true

    function Send-Bridge([hashtable]$request) {
        $writer.WriteLine(($request | ConvertTo-Json -Depth 12 -Compress))
        $line = $reader.ReadLine()
        if ($null -eq $line) { throw 'Conexao encerrada pelo Unreal Editor.' }
        $response = $line | ConvertFrom-Json
        if ($response.ok -ne $true) { throw "Comando $($request.command) falhou: $line" }
        return $response.result
    }

    $status = Send-Bridge @{ id = 'status'; command = 'status' }
    if ($status.bridge_version -ne '0.10.0' -or $status.supports_scene_edit -ne $true) {
        throw 'Recompile e instale a ponte 0.10.0 antes deste teste.'
    }

    $created = Send-Bridge @{ id = 'create'; command = 'create_demo_room'; name = $MapName }
    $expected = "/Game/UE_Master_Maps/$MapName"
    if ($created.map -ne $expected -or $created.total -ne 7) {
        throw 'A sala nao retornou o mapa e os sete Actors esperados.'
    }
    $snapshot = Send-Bridge @{ id = 'snapshot'; command = 'get_scene_snapshot'; offset = 0 }
    $floor = @($snapshot.actors | Where-Object { $_.label -eq 'Piso' })
    $pawn = @($snapshot.actors | Where-Object { $_.label -eq 'Jogador_Sala' })
    if ($snapshot.map -ne $expected -or $floor.Count -ne 1 -or $pawn.Count -ne 1) {
        throw 'A consulta ao nivel nao encontrou piso e jogador da sala.'
    }
    $details = Send-Bridge @{ id = 'details'; command = 'get_actor_details'; actor_path = $floor[0].path }
    if ($details.path -ne $floor[0].path -or $details.total_components -lt 1) {
        throw 'Nao foi possivel inspecionar o piso criado.'
    }

    $transform = @{
        location = @{ x = 0; y = 0; z = -50 }
        rotation = @{ pitch = 0; yaw = 0; roll = 0 }
        scale = @{ x = 11; y = 10; z = 1 }
    }
    $changed = Send-Bridge @{ id = 'move'; command = 'set_actor_transform';
                              actor_path = $floor[0].path; transform = $transform }
    if ($changed.actor.transform.scale.x -ne 11) { throw 'A nova escala do piso nao foi aplicada.' }
    $saved = Send-Bridge @{ id = 'save'; command = 'save_level' }
    $file = Join-Path $status.project_directory "Content\UE_Master_Maps\$MapName.umap"
    if ($saved.map -ne $expected -or -not (Test-Path -LiteralPath $file -PathType Leaf)) {
        throw 'O mapa nao foi salvo em Content/UE_Master_Maps.'
    }

    Write-Host "OK: $expected salvo com piso, paredes, luz e Pawn."
    Write-Host "Arquivo: $file"
    if ($Play) {
        $started = Send-Bridge @{ id = 'play'; command = 'play' }
        if ($started.state -notin @('requested', 'already_requested', 'already_playing')) {
            throw 'O Editor nao aceitou o comando Play.'
        }
        Write-Host "Play: $($started.state)"
    }
}
finally {
    if ($writer) { $writer.Dispose() }
    if ($reader) { $reader.Dispose() }
    $client.Dispose()
}
