"""Teste da fase 3 do UE Master Bridge no Unreal Editor 5.8 aberto.

python testar_objetos.py          # somente status e mapa atual
python testar_objetos.py --write  # cria objeto e mapa de teste com nomes únicos
python testar_objetos.py --inspect /Game/Objects/BP_Chest_...  # somente leitura
Feche o Controller: a ponte aceita apenas uma conexão por vez.
"""

import argparse
import json
import uuid

from testar_autoria import Bridge, transform


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write", action="store_true",
                        help="Cria Blueprint de objeto e mapa exclusivos no projeto de teste")
    parser.add_argument("--inspect", metavar="OBJECT_PATH",
                        help="Consulta um Blueprint existente após reabrir o Editor, sem gravar")
    args = parser.parse_args()
    if args.write and args.inspect:
        parser.error("Use --write ou --inspect, um de cada vez.")
    bridge = Bridge()
    try:
        status = bridge.call("status")
        if status.get("bridge_version") != "0.10.0" or not status.get("supports_object_builder"):
            raise RuntimeError("Instale a ponte 0.10.0, reinicie o Editor e feche o Controller.")
        snapshot = bridge.call("get_scene_snapshot", offset=0)
        print("Editor:", status["project_name"], status["engine_version"])
        print("Mapa atual:", snapshot["map"], "| Actors:", snapshot["total"])
        if args.inspect:
            details = bridge.call("get_object_details", object_path=args.inspect)
            print(json.dumps(details, ensure_ascii=False, indent=2))
            return
        if not args.write:
            print("Consultas OK. Use --write em um projeto de teste com o mapa atual salvo.")
            return

        suffix = uuid.uuid4().hex[:8]
        name = "BP_Chest_" + suffix
        invalid = "BP_Invalid_" + suffix
        error = bridge.call("create_object", should_succeed=False, name=invalid,
                            components=[{"name": "Mesh", "kind": "StaticMesh",
                                         "mesh_path": "/Game/MeshQueNaoExiste_" + suffix}],
                            variables=[])
        assert "mesh_path" in error
        bridge.call("get_object_details", should_succeed=False,
                    object_path="/Game/Objects/" + invalid)

        components = [
            {"name": "StaticMesh_Chest", "kind": "StaticMesh",
             "mesh_path": "/Engine/BasicShapes/Cube"},
            {"name": "BoxCollision", "kind": "BoxCollision",
             "box_extent": {"x": 60, "y": 60, "z": 60}},
            {"name": "InteractionPoint", "kind": "ScenePoint",
             "location": {"x": 0, "y": 0, "z": 90}},
        ]
        variables = [
            {"name": "IsOpen", "type": "bool", "default": False},
            {"name": "LootAmount", "type": "int", "default": 3},
            {"name": "InteractionDistance", "type": "float", "default": 180.0},
            {"name": "DisplayName", "type": "string", "default": "Treasure chest",
             "instance_editable": False},
        ]
        created = bridge.call("create_object", name=name, components=components,
                              variables=variables)
        path = created["asset_path"]
        print("Blueprint salvo:", path)
        assert path == "/Game/Objects/" + name
        assert created["total_components"] == 4 and created["total_variables"] == 4, created
        details = bridge.call("get_object_details", object_path=path)
        assert details["compiled"]
        names = {item["name"] for item in details["components"]}
        assert names == {"SceneRoot", "StaticMesh_Chest", "BoxCollision", "InteractionPoint"}
        assert [item["name"] for item in details["components"] if item["is_root"]] == ["SceneRoot"]
        mesh = next(item for item in details["components"] if item["name"] == "StaticMesh_Chest")
        assert mesh["mesh_path"].startswith("/Engine/BasicShapes/Cube.")
        assert {item["name"] for item in details["variables"]} == {
            "IsOpen", "LootAmount", "InteractionDistance", "DisplayName"}, details
        assert {item["name"]: item["instance_editable"] for item in details["variables"]} == {
            "IsOpen": True, "LootAmount": True, "InteractionDistance": True,
            "DisplayName": False}, details["variables"]
        defaults = {item["name"]: item["default"] for item in details["variables"]}
        assert all(item["default_source"] == "class_default"
                   for item in details["variables"]), (path, details["variables"])
        assert defaults["IsOpen"].lower() == "false" and defaults["LootAmount"] == "3", (path, defaults)
        assert float(defaults["InteractionDistance"]) == 180, (path, defaults)
        assert defaults["DisplayName"] == "Treasure chest", (path, defaults)
        bridge.call("create_object", should_succeed=False, name=name,
                    components=components, variables=variables)

        level = bridge.call("create_level", name="L_ObjectTest_" + suffix)["map"]
        actor = bridge.call("spawn_actor", kind="Blueprint", blueprint_path=path,
                            label="Chest_" + suffix, transform=transform(0, 0, 100))
        instance = bridge.call("get_actor_details", actor_path=actor["actor"]["path"])
        instance_names = {item["name"] for item in instance["components"]}
        assert names <= instance_names, (names, instance_names)
        bridge.call("save_level")
        print("Integração da fase 3 OK. Objeto:", path)
        print("Mapa salvo:", level)
        print("O teste deixa o Blueprint e o mapa no projeto para inspeção.")
    finally:
        bridge.close()


if __name__ == "__main__":
    main()
