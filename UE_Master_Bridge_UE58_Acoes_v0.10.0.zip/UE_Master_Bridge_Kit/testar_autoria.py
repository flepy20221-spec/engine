"""Teste de integração real do UE Master Bridge 0.10.0 com o Unreal Editor aberto.

python testar_autoria.py          # consultas apenas
python testar_autoria.py --write  # cria mapa e assets de teste no projeto aberto
Feche o Controller antes: a ponte aceita um cliente de cada vez.
"""

import argparse
import json
import socket
import uuid


class Bridge:
    def __init__(self):
        self.socket = socket.create_connection(("127.0.0.1", 17777), timeout=10)
        self.socket.settimeout(120)
        self.reader = self.socket.makefile("r", encoding="utf-8", newline="\n")
        self.writer = self.socket.makefile("w", encoding="utf-8", newline="\n")
        self.serial = 0

    def call(self, command, *, should_succeed=True, **fields):
        self.serial += 1
        request = {"id": str(self.serial), "command": command, **fields}
        self.writer.write(json.dumps(request, ensure_ascii=False, separators=(",", ":")) + "\n")
        self.writer.flush()
        line = self.reader.readline()
        if not line:
            raise RuntimeError(f"Conexão encerrada durante {command}")
        response = json.loads(line)
        if response.get("id") != request["id"] or response.get("ok") is not should_succeed:
            raise RuntimeError(f"Resposta inesperada em {command}: {response}")
        return response.get("result", {}) if should_succeed else response.get("error", "")

    def close(self):
        self.writer.close()
        self.reader.close()
        self.socket.close()


def transform(x, y, z, sx=1, sy=1, sz=1):
    return {
        "location": {"x": x, "y": y, "z": z},
        "rotation": {"pitch": 0, "yaw": 0, "roll": 0},
        "scale": {"x": sx, "y": sy, "z": sz},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--write", action="store_true",
                        help="Cria mapa, Blueprint e assets de teste no projeto aberto")
    args = parser.parse_args()
    bridge = Bridge()
    try:
        status = bridge.call("status")
        if status.get("bridge_version") != "0.10.0" or not status.get("supports_scene_authoring") or not status.get("supports_object_builder"):
            raise RuntimeError("Instale a ponte 0.10.0, reinicie o Editor e feche o Controller.")
        print("Editor:", status["project_name"], status["engine_version"])
        snapshot = bridge.call("get_scene_snapshot", offset=0)
        print("Mapa atual:", snapshot["map"], "| Actors:", snapshot["total"])
        if not args.write:
            print("Consultas OK. Use --write somente em um projeto de teste.")
            return

        suffix = uuid.uuid4().hex[:8]
        name = "L_BridgeTest_" + suffix
        created = bridge.call("create_level", name=name)
        assert created["map"].endswith("/" + name)
        before = bridge.call("get_scene_snapshot", offset=0)["total"]
        bridge.call("compose_scene", should_succeed=False, actors=[{
            "kind": "StaticMesh", "mesh_path": "/Game/Inexistente_Neste_Teste",
            "transform": transform(0, 0, 0),
        }])
        assert bridge.call("get_scene_snapshot", offset=0)["total"] == before
        scene = bridge.call("compose_scene", actors=[
            {"kind": "StaticMesh", "label": "Piso_" + suffix,
             "mesh_path": "/Engine/BasicShapes/Cube",
             "transform": transform(0, 0, -50, 6, 6, 1)},
            {"kind": "PointLight", "label": "Luz_" + suffix,
             "transform": transform(0, 0, 300)},
        ])
        assert scene["total"] == 2
        floor = scene["actors"][0]["path"]
        light = scene["actors"][1]["path"]
        bridge.call("get_actor_details", actor_path=floor)
        bridge.call("set_actor_properties", actor_path=floor,
                    collision_enabled=True, folder="BridgeTest", tags=["Teste"])
        bridge.call("add_component", actor_path=floor, component_name="Bridge_Box",
                    component_kind="BoxCollision")
        details = bridge.call("get_actor_details", actor_path=floor)
        assert any(c["name"] == "Bridge_Box" for c in details["components"])
        bridge.call("remove_component", actor_path=floor, component_name="Bridge_Box")
        duplicate = bridge.call("duplicate_actor", actor_path=floor,
                                offset={"x": 200, "y": 0, "z": 0})
        copy_path = duplicate["actor"]["path"]
        bridge.call("rename_actor", actor_path=copy_path, label="Copia_" + suffix)
        # Rename may change an Actor's internal path. Resolve the new path from its response.
        renamed = bridge.call("get_scene_snapshot", offset=0)
        copy_path = next(a["path"] for a in renamed["actors"]
                         if a["label"] == "Copia_" + suffix)
        bridge.call("attach_actor", actor_path=copy_path, parent_path=floor)
        bridge.call("detach_actor", actor_path=copy_path)
        bridge.call("frame_actor", actor_path=light)
        bridge.call("delete_actor", actor_path=copy_path)
        bridge.call("save_level")

        asset_name = "BP_BridgeTest_" + suffix
        asset = bridge.call("create_blueprint", name=asset_name, parent_class="Actor")["asset_path"]
        folder = "/Game/BridgeTests_" + suffix
        bridge.call("create_content_folder", folder=folder)
        copied = bridge.call("duplicate_asset", source=asset,
                             destination=folder + "/" + asset_name + "_Copy")["destination"]
        bridge.call("move_asset", source=copied,
                    destination=folder + "/" + asset_name + "_Moved")
        total = bridge.call("get_scene_snapshot", offset=0)["total"]
        assert total >= before + 2
        print("Integração OK. Mapa salvo:", created["map"])
        print("Assets criados:", asset, folder)
        print("O teste deixa o mapa e os assets no projeto para inspeção.")
    finally:
        bridge.close()


if __name__ == "__main__":
    main()
